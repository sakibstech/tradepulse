from typing import List, Optional
from pydantic import BaseModel, Field

class CandleSchema(BaseModel):
    time: int = Field(..., description="Unix timestamp in seconds")
    open: float = Field(..., description="Open price")
    high: float = Field(..., description="High price")
    low: float = Field(..., description="Low price")
    close: float = Field(..., description="Close price")
    volume: float = Field(..., description="Volume traded")
    rsi: Optional[float] = Field(None, description="Relative Strength Index (14)")
    ema20: Optional[float] = Field(None, description="Exponential Moving Average (20)")
    ema50: Optional[float] = Field(None, description="Exponential Moving Average (50)")
    sma20: Optional[float] = Field(None, description="Simple Moving Average (20)")
    macd: Optional[float] = Field(None, description="MACD line")
    macd_signal: Optional[float] = Field(None, description="MACD signal line")
    macd_hist: Optional[float] = Field(None, description="MACD histogram")
    bb_upper: Optional[float] = Field(None, description="Bollinger Bands Upper")
    bb_middle: Optional[float] = Field(None, description="Bollinger Bands Middle")
    bb_lower: Optional[float] = Field(None, description="Bollinger Bands Lower")

class HistoryResponse(BaseModel):
    symbol: str
    interval: str
    candles: List[CandleSchema]

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import yfinance as yf
import pandas as pd
try:
    import pandas_ta as ta
except ImportError:
    ta = None

from services.indicator_engine import compute_technical_indicators
from schemas.chart_schema import HistoryResponse

app = FastAPI(
    title="TradePulse API",
    version="1.0",
    description="High-speed financial market data and indicator service for TradePulse Web"
)

# Enable CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health_check():
    return {"status": "ok", "service": "TradePulse API", "version": "1.0"}

@app.get("/api/v1/history", response_model=HistoryResponse)
def get_chart_history(
    symbol: str = Query("XAUUSD=X", description="Ticker symbol (e.g. XAUUSD=X, EURUSD=X, BTC-USD, AAPL)"),
    interval: str = Query("1d", description="Timeframe: 1m, 5m, 15m, 1h, 1d, 1wk"),
    period: str = Query("1y", description="Data range: e.g. 1mo, 6mo, 1y, 2y")
):
    """
    Fetches historical candlestick OHLCV data and calculates technical indicators
    using yfinance and pandas-ta for TradingView Lightweight Charts rendering.
    """
    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=period, interval=interval)
        
        if df.empty:
            raise HTTPException(status_code=404, detail=f"No market data returned for symbol '{symbol}'")

        # Compute technical indicators using pandas-ta
        df = compute_technical_indicators(df)
        df = df.reset_index()

        # Standardize timestamp for TradingView Lightweight Charts (UTC seconds)
        time_col = 'Date' if 'Date' in df.columns else 'Datetime'
        df['time'] = df[time_col].astype('int64') // 10**9

        candles = []
        for _, row in df.iterrows():
            candles.append({
                "time": int(row['time']),
                "open": round(float(row['Open']), 5),
                "high": round(float(row['High']), 5),
                "low": round(float(row['Low']), 5),
                "close": round(float(row['Close']), 5),
                "volume": float(row['Volume']) if 'Volume' in row else 0.0,
                "rsi": round(float(row['RSI']), 2) if 'RSI' in row and pd.notnull(row['RSI']) else None,
                "ema20": round(float(row['EMA_20']), 5) if 'EMA_20' in row and pd.notnull(row['EMA_20']) else None,
                "ema50": round(float(row['EMA_50']), 5) if 'EMA_50' in row and pd.notnull(row['EMA_50']) else None,
                "sma20": round(float(row['SMA_20']), 5) if 'SMA_20' in row and pd.notnull(row['SMA_20']) else None,
                "macd": round(float(row['MACD']), 5) if 'MACD' in row and pd.notnull(row['MACD']) else None,
                "macd_signal": round(float(row['MACD_SIGNAL']), 5) if 'MACD_SIGNAL' in row and pd.notnull(row['MACD_SIGNAL']) else None,
                "macd_hist": round(float(row['MACD_HIST']), 5) if 'MACD_HIST' in row and pd.notnull(row['MACD_HIST']) else None,
                "bb_upper": round(float(row['BB_UPPER']), 5) if 'BB_UPPER' in row and pd.notnull(row['BB_UPPER']) else None,
                "bb_middle": round(float(row['BB_MIDDLE']), 5) if 'BB_MIDDLE' in row and pd.notnull(row['BB_MIDDLE']) else None,
                "bb_lower": round(float(row['BB_LOWER']), 5) if 'BB_LOWER' in row and pd.notnull(row['BB_LOWER']) else None,
            })

        return {
            "symbol": symbol,
            "interval": interval,
            "candles": candles
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

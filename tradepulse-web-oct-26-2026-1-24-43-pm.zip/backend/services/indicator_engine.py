import pandas as pd
try:
    import pandas_ta as ta
except ImportError:
    ta = None

def compute_technical_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Computes SMA, EMA, RSI, MACD, and Bollinger Bands using pandas-ta.
    """
    if df.empty:
        return df

    # RSI (14)
    try:
        df['RSI'] = df.ta.rsi(length=14)
    except Exception:
        df['RSI'] = None

    # EMA (20 & 50)
    try:
        df['EMA_20'] = df.ta.ema(length=20)
        df['EMA_50'] = df.ta.ema(length=50)
    except Exception:
        df['EMA_20'] = None
        df['EMA_50'] = None

    # SMA (20)
    try:
        df['SMA_20'] = df.ta.sma(length=20)
    except Exception:
        df['SMA_20'] = None

    # MACD (12, 26, 9)
    try:
        macd_df = df.ta.macd(fast=12, slow=26, signal=9)
        if macd_df is not None and not macd_df.empty:
            cols = macd_df.columns
            df['MACD'] = macd_df[cols[0]]
            df['MACD_HIST'] = macd_df[cols[1]]
            df['MACD_SIGNAL'] = macd_df[cols[2]]
        else:
            df['MACD'] = None
            df['MACD_HIST'] = None
            df['MACD_SIGNAL'] = None
    except Exception:
        df['MACD'] = None
        df['MACD_HIST'] = None
        df['MACD_SIGNAL'] = None

    # Bollinger Bands (20, 2)
    try:
        bb_df = df.ta.bbands(length=20, std=2)
        if bb_df is not None and not bb_df.empty:
            cols = bb_df.columns
            df['BB_LOWER'] = bb_df[cols[0]]
            df['BB_MIDDLE'] = bb_df[cols[1]]
            df['BB_UPPER'] = bb_df[cols[2]]
        else:
            df['BB_LOWER'] = None
            df['BB_MIDDLE'] = None
            df['BB_UPPER'] = None
    except Exception:
        df['BB_LOWER'] = None
        df['BB_MIDDLE'] = None
        df['BB_UPPER'] = None

    return df

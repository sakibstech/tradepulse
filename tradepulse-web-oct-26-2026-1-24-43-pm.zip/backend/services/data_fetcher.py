import yfinance as yf
import pandas as pd
from typing import Optional

def fetch_market_history(symbol: str, interval: str = "1d", period: str = "1y") -> pd.DataFrame:
    """
    Fetches historical OHLCV data using yfinance for stocks, crypto, forex, commodities.
    Handles interval conversions and index timestamps.
    """
    # Clean symbol mappings
    cleaned_symbol = symbol.strip()
    
    ticker = yf.Ticker(cleaned_symbol)
    df = ticker.history(period=period, interval=interval)
    
    if df.empty:
        # Retry with standard period
        df = ticker.history(period="6mo", interval=interval)
        
    return df

import { Candle, CustomPlotOutput, CustomPlotType, CustomPythonIndicator } from '../types/chart';

export interface PythonExecutionResult {
  success: boolean;
  plots: CustomPlotOutput[];
  overlay: boolean;
  logs: string[];
  executionTimeMs: number;
  error: string | null;
}

export interface PythonTemplate {
  id: string;
  name: string;
  description: string;
  overlay: boolean;
  code: string;
}

/**
 * Built-in Library of Professional Python Financial Indicator Templates
 */
export const PYTHON_INDICATOR_TEMPLATES: PythonTemplate[] = [
  {
    id: 'dual_ema_cross',
    name: 'Dual EMA Cross Ribbon',
    description: 'Fast EMA (9) & Slow EMA (21) trend crossover indicator on price chart',
    overlay: true,
    code: `# Python Custom Indicator: Dual EMA Cross Ribbon
# Calculates Fast and Slow exponential moving averages
fast_len = 9
slow_len = 21

fast_ema = ema(close, fast_len)
slow_ema = ema(close, slow_len)

# Log status in console
print(f"Calculated {len(close)} bars")
print(f"Latest Fast EMA: {fast_ema[-1]:.2f}")
print(f"Latest Slow EMA: {slow_ema[-1]:.2f}")

# Plot lines on price chart
plot(fast_ema, title="Fast EMA (9)", color="#38bdf8", width=2)
plot(slow_ema, title="Slow EMA (21)", color="#f97316", width=2)
`,
  },
  {
    id: 'custom_rsi_signal',
    name: 'RSI Momentum Oscillator + Signal',
    description: 'Custom RSI with 9-period smoothed signal line and overbought/oversold levels',
    overlay: false,
    code: `# Python Custom Indicator: RSI Momentum Oscillator
rsi_len = 14
signal_len = 9

rsi_val = rsi(close, rsi_len)
signal_line = sma(rsi_val, signal_len)

print(f"Latest RSI: {rsi_val[-1]:.2f}")
print(f"Signal Line: {signal_line[-1]:.2f}")

# Plots in oscillator sub-pane
plot(rsi_val, title="Custom RSI (14)", color="#a855f7", width=2)
plot(signal_line, title="Signal SMA (9)", color="#eab308", width=1)
plot_level(70, title="Overbought (70)", color="#ef4444")
plot_level(30, title="Oversold (30)", color="#22c55e")
`,
  },
  {
    id: 'donchian_breakout',
    name: 'Donchian Channel Breakout',
    description: '20-period highest high and lowest low channel with median basis',
    overlay: true,
    code: `# Python Custom Indicator: Donchian Channel Breakout
length = 20

upper = highest(high, length)
lower = lowest(low, length)

basis = []
for i in range(len(close)):
    if upper[i] is not None and lower[i] is not None:
        basis.append((upper[i] + lower[i]) / 2)
    else:
        basis.append(None)

print(f"Upper Channel: {upper[-1]:.2f}")
print(f"Lower Channel: {lower[-1]:.2f}")

plot(upper, title="Donchian Upper (20)", color="#10b981", width=2)
plot(basis, title="Donchian Basis", color="#94a3b8", width=1)
plot(lower, title="Donchian Lower (20)", color="#f43f5e", width=2)
`,
  },
  {
    id: 'vwap_bands',
    name: 'VWAP with StDev Volatility Bands',
    description: 'Volume Weighted Average Price with 1.5-sigma upper and lower bands',
    overlay: true,
    code: `# Python Custom Indicator: VWAP with Bands
vwap_line = vwap(high, low, close, volume)
std_line = std(close, 20)

upper_band = []
lower_band = []
for i in range(len(close)):
    if vwap_line[i] is not None and std_line[i] is not None:
        upper_band.append(vwap_line[i] + 1.5 * std_line[i])
        lower_band.append(vwap_line[i] - 1.5 * std_line[i])
    else:
        upper_band.append(None)
        lower_band.append(None)

print(f"Current VWAP: {vwap_line[-1]:.2f}")

plot(vwap_line, title="VWAP", color="#facc15", width=2)
plot(upper_band, title="VWAP Upper (+1.5σ)", color="#38bdf8", width=1)
plot(lower_band, title="VWAP Lower (-1.5σ)", color="#38bdf8", width=1)
`,
  },
  {
    id: 'custom_macd',
    name: 'Custom MACD Momentum Histogram',
    description: 'MACD line, signal line, and momentum histogram with zero line',
    overlay: false,
    code: `# Python Custom Indicator: MACD Momentum
macd_line, sig_line, hist = macd(close, 12, 26, 9)

print(f"MACD: {macd_line[-1]:.4f}, Signal: {sig_line[-1]:.4f}")

plot(macd_line, title="MACD (12, 26)", color="#3b82f6", width=2)
plot(sig_line, title="Signal (9)", color="#f97316", width=1)
plot_hist(hist, title="Histogram", color="#22c55e")
plot_level(0, title="Zero Line", color="#64748b")
`,
  },
  {
    id: 'bollinger_pct_b',
    name: 'Bollinger Band %B & Bandwidth',
    description: 'Measures price location relative to Bollinger Bands (0 to 100%)',
    overlay: false,
    code: `# Python Custom Indicator: Bollinger Band %B
upper, middle, lower = bollinger(close, 20, 2)

pct_b = []
for i in range(len(close)):
    if upper[i] is not None and lower[i] is not None and (upper[i] - lower[i]) > 0:
        val = (close[i] - lower[i]) / (upper[i] - lower[i]) * 100
        pct_b.append(val)
    else:
        pct_b.append(None)

print(f"Current %B: {pct_b[-1]:.1f}%")

plot(pct_b, title="Bollinger %B", color="#06b6d4", width=2)
plot_level(100, title="Upper Band (100)", color="#ef4444")
plot_level(50, title="Middle Band (50)", color="#64748b")
plot_level(0, title="Lower Band (0)", color="#22c55e")
`,
  },
  {
    id: 'supertrend_trailing',
    name: 'Supertrend ATR Trailing Stop',
    description: 'Average True Range volatility trailing stop and trend director',
    overlay: true,
    code: `# Python Custom Indicator: Supertrend ATR Trend Stop
st = supertrend(high, low, close, period=10, multiplier=3)

print(f"Current Supertrend Stop: {st[-1]:.2f}")
plot(st, title="Supertrend (10, 3)", color="#10b981", width=2)
`,
  },
  {
    id: 'roc_momentum',
    name: 'Rate of Change (ROC) Oscillator',
    description: 'Percentage momentum change over 14 bars with extreme bands',
    overlay: false,
    code: `# Python Custom Indicator: Rate of Change (ROC)
length = 14
roc_vals = roc(close, length)

print(f"14-period ROC: {roc_vals[-1]:.2f}%")

plot(roc_vals, title="ROC (14)", color="#ec4899", width=2)
plot_level(0, title="Zero Level", color="#64748b")
plot_level(3, title="+3% Overbought", color="#ef4444")
plot_level(-3, title="-3% Oversold", color="#22c55e")
`,
  },
];

// Helper to access array with Python-like negative indexing
export function pyGet(arr: any[], index: number): any {
  if (!arr || !Array.isArray(arr)) return null;
  const len = arr.length;
  if (index < 0) {
    const realIdx = len + index;
    return realIdx >= 0 && realIdx < len ? arr[realIdx] : null;
  }
  return index >= 0 && index < len ? arr[index] : null;
}

/**
 * Technical Math Library for Custom Python Indicators
 */
export function calcSMA(source: (number | null)[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  let sum = 0;
  for (let i = 0; i < source.length; i++) {
    const val = source[i];
    if (val === null || val === undefined || isNaN(val)) {
      result.push(null);
      sum = 0;
      continue;
    }
    sum += val;
    if (i >= period) {
      const prev = source[i - period];
      if (prev !== null && prev !== undefined) sum -= prev;
    }
    if (i >= period - 1) {
      result.push(sum / period);
    } else {
      result.push(null);
    }
  }
  return result;
}

export function calcEMA(source: (number | null)[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  const multiplier = 2 / (period + 1);
  let prevEMA: number | null = null;

  for (let i = 0; i < source.length; i++) {
    const val = source[i];
    if (val === null || val === undefined || isNaN(val)) {
      result.push(null);
      continue;
    }

    if (i < period - 1) {
      result.push(null);
      continue;
    }

    if (i === period - 1 || prevEMA === null) {
      let sum = 0;
      for (let j = 0; j < period; j++) {
        const v = source[i - j];
        if (v !== null && v !== undefined) sum += v;
      }
      prevEMA = sum / period;
      result.push(prevEMA);
    } else {
      prevEMA = (val - prevEMA) * multiplier + prevEMA;
      result.push(prevEMA);
    }
  }
  return result;
}

export function calcWMA(source: (number | null)[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  const denominator = (period * (period + 1)) / 2;

  for (let i = 0; i < source.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }
    let weightSum = 0;
    let isValid = true;
    for (let j = 0; j < period; j++) {
      const val = source[i - j];
      if (val === null || val === undefined) {
        isValid = false;
        break;
      }
      weightSum += val * (period - j);
    }
    result.push(isValid ? weightSum / denominator : null);
  }
  return result;
}

export function calcRSI(source: (number | null)[], period: number = 14): (number | null)[] {
  const result: (number | null)[] = [];
  if (source.length <= period) {
    return new Array(source.length).fill(null);
  }

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = (source[i] ?? 0) - (source[i - 1] ?? 0);
    if (diff >= 0) gains += diff;
    else losses += Math.abs(diff);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = 0; i < period; i++) result.push(null);

  let rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  result.push(100 - 100 / (1 + rs));

  for (let i = period + 1; i < source.length; i++) {
    const diff = (source[i] ?? 0) - (source[i - 1] ?? 0);
    const cGain = diff >= 0 ? diff : 0;
    const cLoss = diff < 0 ? Math.abs(diff) : 0;

    avgGain = (avgGain * (period - 1) + cGain) / period;
    avgLoss = (avgLoss * (period - 1) + cLoss) / period;

    if (avgLoss === 0) {
      result.push(100);
    } else {
      rs = avgGain / avgLoss;
      result.push(100 - 100 / (1 + rs));
    }
  }

  return result;
}

export function calcStd(source: (number | null)[], period: number): (number | null)[] {
  const sma = calcSMA(source, period);
  const result: (number | null)[] = [];

  for (let i = 0; i < source.length; i++) {
    if (i < period - 1 || sma[i] === null) {
      result.push(null);
      continue;
    }
    const mean = sma[i] as number;
    let sumSq = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const v = source[j] ?? 0;
      sumSq += (v - mean) * (v - mean);
    }
    result.push(Math.sqrt(sumSq / period));
  }
  return result;
}

export function calcHighest(source: (number | null)[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < source.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }
    let max = -Infinity;
    for (let j = i - period + 1; j <= i; j++) {
      const val = source[j];
      if (val !== null && val !== undefined && val > max) max = val;
    }
    result.push(max === -Infinity ? null : max);
  }
  return result;
}

export function calcLowest(source: (number | null)[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < source.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }
    let min = Infinity;
    for (let j = i - period + 1; j <= i; j++) {
      const val = source[j];
      if (val !== null && val !== undefined && val < min) min = val;
    }
    result.push(min === Infinity ? null : min);
  }
  return result;
}

export function calcMACD(
  source: (number | null)[],
  fast = 12,
  slow = 26,
  signal = 9
): [(number | null)[], (number | null)[], (number | null)[]] {
  const fastEMA = calcEMA(source, fast);
  const slowEMA = calcEMA(source, slow);
  const macdLine: (number | null)[] = [];

  for (let i = 0; i < source.length; i++) {
    if (fastEMA[i] !== null && slowEMA[i] !== null) {
      macdLine.push((fastEMA[i] as number) - (slowEMA[i] as number));
    } else {
      macdLine.push(null);
    }
  }

  const sigLine = calcEMA(macdLine, signal);
  const hist: (number | null)[] = [];

  for (let i = 0; i < source.length; i++) {
    if (macdLine[i] !== null && sigLine[i] !== null) {
      hist.push((macdLine[i] as number) - (sigLine[i] as number));
    } else {
      hist.push(null);
    }
  }

  return [macdLine, sigLine, hist];
}

export function calcBollinger(
  source: (number | null)[],
  period = 20,
  stdDev = 2
): [(number | null)[], (number | null)[], (number | null)[]] {
  const middle = calcSMA(source, period);
  const std = calcStd(source, period);
  const upper: (number | null)[] = [];
  const lower: (number | null)[] = [];

  for (let i = 0; i < source.length; i++) {
    if (middle[i] !== null && std[i] !== null) {
      const m = middle[i] as number;
      const s = std[i] as number;
      upper.push(m + stdDev * s);
      lower.push(m - stdDev * s);
    } else {
      upper.push(null);
      lower.push(null);
    }
  }

  return [upper, middle, lower];
}

export function calcATR(
  high: number[],
  low: number[],
  close: number[],
  period = 14
): (number | null)[] {
  const tr: number[] = [];
  for (let i = 0; i < high.length; i++) {
    if (i === 0) {
      tr.push(high[i] - low[i]);
    } else {
      const hl = high[i] - low[i];
      const hc = Math.abs(high[i] - close[i - 1]);
      const lc = Math.abs(low[i] - close[i - 1]);
      tr.push(Math.max(hl, hc, lc));
    }
  }

  return calcEMA(tr, period);
}

export function calcVWAP(
  high: number[],
  low: number[],
  close: number[],
  volume: number[]
): (number | null)[] {
  const result: (number | null)[] = [];
  let cumTPV = 0;
  let cumVol = 0;

  for (let i = 0; i < high.length; i++) {
    const tp = (high[i] + low[i] + close[i]) / 3;
    const vol = volume[i] && volume[i] > 0 ? volume[i] : 1;
    cumTPV += tp * vol;
    cumVol += vol;
    result.push(cumVol > 0 ? cumTPV / cumVol : tp);
  }

  return result;
}

export function calcSupertrend(
  high: number[],
  low: number[],
  close: number[],
  period = 10,
  multiplier = 3
): (number | null)[] {
  const atr = calcATR(high, low, close, period);
  const result: (number | null)[] = [];
  let prevSupertrend: number | null = null;
  let inUptrend = true;

  for (let i = 0; i < high.length; i++) {
    if (atr[i] === null) {
      result.push(null);
      continue;
    }

    const hl2 = (high[i] + low[i]) / 2;
    const atrVal = atr[i] as number;
    const basicUpper = hl2 + multiplier * atrVal;
    const basicLower = hl2 - multiplier * atrVal;

    if (prevSupertrend === null) {
      prevSupertrend = basicLower;
      result.push(prevSupertrend);
      continue;
    }

    if (inUptrend) {
      if (close[i] < prevSupertrend) {
        inUptrend = false;
        prevSupertrend = basicUpper;
      } else {
        prevSupertrend = Math.max(basicLower, prevSupertrend);
      }
    } else {
      if (close[i] > prevSupertrend) {
        inUptrend = true;
        prevSupertrend = basicLower;
      } else {
        prevSupertrend = Math.min(basicUpper, prevSupertrend);
      }
    }

    result.push(prevSupertrend);
  }

  return result;
}

export function calcROC(source: (number | null)[], period = 14): (number | null)[] {
  const result: (number | null)[] = [];
  for (let i = 0; i < source.length; i++) {
    if (i < period || source[i] === null || source[i - period] === null) {
      result.push(null);
      continue;
    }
    const cur = source[i] as number;
    const prev = source[i - period] as number;
    if (prev === 0) {
      result.push(0);
    } else {
      result.push(((cur - prev) / prev) * 100);
    }
  }
  return result;
}

/**
 * Python-to-JavaScript Transpiler & Evaluator
 * Supports Python syntax:
 * - Indentation blocks (if, elif, else, for, while, def)
 * - Python keywords (True, False, None, and, or, not)
 * - F-strings: f"Val: {x:.2f}" -> `Val: ${Number(x).toFixed(2)}`
 * - List comprehensions [expr for x in y if cond]
 * - Zip & range helpers
 * - Python-like slicing & negative indexing
 */
export function transpilePythonToJS(pythonCode: string): string {
  const lines = pythonCode.split('\n');
  const jsLines: string[] = [];
  const indentStack: number[] = [0];

  for (let lineIndex = 0; lineIndex < lines.length; lineIndex++) {
    let line = lines[lineIndex];

    // Check for comment or empty line
    const trimmed = line.trim();
    if (!trimmed) {
      continue;
    }

    // Determine indentation
    const indentMatch = line.match(/^(\s*)/);
    const currentIndent = indentMatch ? indentMatch[1].replace(/\t/g, '    ').length : 0;

    // Handle indentation dedents
    while (indentStack.length > 1 && currentIndent < indentStack[indentStack.length - 1]) {
      indentStack.pop();
      jsLines.push('  '.repeat(indentStack.length - 1) + '}');
    }

    // Process line content
    let content = trimmed;

    // Convert Python comments # -> //
    if (content.startsWith('#')) {
      jsLines.push('// ' + content.slice(1).trim());
      continue;
    }

    // Remove inline comment (be careful of strings)
    let inString: string | null = null;
    let commentIdx = -1;
    for (let i = 0; i < content.length; i++) {
      const ch = content[i];
      if ((ch === '"' || ch === "'") && (i === 0 || content[i - 1] !== '\\')) {
        if (!inString) inString = ch;
        else if (inString === ch) inString = null;
      } else if (ch === '#' && !inString) {
        commentIdx = i;
        break;
      }
    }
    if (commentIdx !== -1) {
      content = content.slice(0, commentIdx).trim();
    }

    // Transform Python f-strings: f"..." or f'...'
    content = content.replace(/f(["'])(.*?)\1/g, (_, quote, inner) => {
      // transform {expr:.2f} -> ${Number(expr).toFixed(2)}
      const transformedInner = inner.replace(/\{([^:}]+)(?::\.(\d+)f)?\}/g, (__: any, expr: string, decimals?: string) => {
        if (decimals) {
          return `\${(Number(${expr.trim()}) || 0).toFixed(${decimals})}`;
        }
        return `\${${expr.trim()}}`;
      });
      return '`' + transformedInner + '`';
    });

    // Replace Python literal keywords
    content = content
      .replace(/\bTrue\b/g, 'true')
      .replace(/\bFalse\b/g, 'false')
      .replace(/\bNone\b/g, 'null')
      .replace(/\bis not None\b/g, '!== null && $1 !== undefined')
      .replace(/\bis None\b/g, '=== null || $1 === undefined')
      .replace(/\bpass\b/g, '/* pass */');

    // Convert Python operators (carefully outside string tokens)
    content = content
      .replace(/\band\b/g, '&&')
      .replace(/\bor\b/g, '||')
      .replace(/\bnot\b/g, '!');

    // Convert list append: arr.append(x) -> arr.push(x)
    content = content.replace(/\.append\(/g, '.push(');

    // Convert list comprehension: [expr for x in iterable] or [expr for x, y in iterable]
    // e.g. [(u + l) / 2 for u, l in zip(upper, lower)]
    content = content.replace(
      /\[\s*(.+?)\s+for\s+([a-zA-Z0-9_,\s]+)\s+in\s+(.+?)(?:\s+if\s+(.+?))?\s*\]/g,
      (_, expr, vars, iter, cond) => {
        const varList = vars.split(',').map((v: string) => v.trim());
        if (varList.length > 1) {
          return `(${iter}).map(([${vars}]) => (${cond ? `(${cond}) ? (${expr}) : null` : expr}))`;
        }
        return `(${iter}).map((${vars}) => (${cond ? `(${cond}) ? (${expr}) : null` : expr}))`;
      }
    );

    // Python functions and control blocks:
    // def name(args):
    if (/^def\s+([a-zA-Z0-9_]+)\s*\((.*?)\)\s*:$/.test(content)) {
      content = content.replace(/^def\s+([a-zA-Z0-9_]+)\s*\((.*?)\)\s*:$/, 'function $1($2) {');
      indentStack.push(currentIndent + 4);
    }
    // elif cond:
    else if (/^elif\s+(.+)\s*:$/.test(content)) {
      // Dedent previous block if needed
      content = content.replace(/^elif\s+(.+)\s*:$/, '} else if ($1) {');
    }
    // if cond:
    else if (/^if\s+(.+)\s*:$/.test(content)) {
      content = content.replace(/^if\s+(.+)\s*:$/, 'if ($1) {');
      indentStack.push(currentIndent + 4);
    }
    // else:
    else if (/^else\s*:$/.test(content)) {
      content = '} else {';
    }
    // for i in range(len(arr)):
    else if (/^for\s+([a-zA-Z0-9_]+)\s+in\s+range\(\s*len\((.*?)\)\s*\)\s*:$/.test(content)) {
      content = content.replace(
        /^for\s+([a-zA-Z0-9_]+)\s+in\s+range\(\s*len\((.*?)\)\s*\)\s*:$/,
        'for (let $1 = 0; $1 < ($2).length; $1++) {'
      );
      indentStack.push(currentIndent + 4);
    }
    // for i in range(stop):
    else if (/^for\s+([a-zA-Z0-9_]+)\s+in\s+range\(\s*([^,]+?)\s*\)\s*:$/.test(content)) {
      content = content.replace(
        /^for\s+([a-zA-Z0-9_]+)\s+in\s+range\(\s*([^,]+?)\s*\)\s*:$/,
        'for (let $1 = 0; $1 < ($2); $1++) {'
      );
      indentStack.push(currentIndent + 4);
    }
    // for i in range(start, stop):
    else if (/^for\s+([a-zA-Z0-9_]+)\s+in\s+range\(\s*(.+?),\s*(.+?)\s*\)\s*:$/.test(content)) {
      content = content.replace(
        /^for\s+([a-zA-Z0-9_]+)\s+in\s+range\(\s*(.+?),\s*(.+?)\s*\)\s*:$/,
        'for (let $1 = ($2); $1 < ($3); $1++) {'
      );
      indentStack.push(currentIndent + 4);
    }
    // for item in arr:
    else if (/^for\s+([a-zA-Z0-9_]+)\s+in\s+(.+)\s*:$/.test(content)) {
      content = content.replace(
        /^for\s+([a-zA-Z0-9_]+)\s+in\s+(.+)\s*:$/,
        'for (const $1 of ($2)) {'
      );
      indentStack.push(currentIndent + 4);
    }
    // while cond:
    else if (/^while\s+(.+)\s*:$/.test(content)) {
      content = content.replace(/^while\s+(.+)\s*:$/, 'while ($1) {');
      indentStack.push(currentIndent + 4);
    } else {
      // Normal statement: support negative indexing e.g. arr[-1] -> pyGet(arr, -1)
      content = content.replace(/([a-zA-Z0-9_]+)\[(-[0-9]+)\]/g, 'pyGet($1, $2)');

      // Multi-assignment tuple unpack: a, b, c = macd(...)
      if (/^([a-zA-Z0-9_]+(?:\s*,\s*[a-zA-Z0-9_]+)+)\s*=\s*(.+)$/.test(content)) {
        content = 'let [' + content.replace(/\s*=\s*/, '] = ');
      }
      // Standard assignment: if variable doesn't have let/const/var, declare it
      else if (/^([a-zA-Z0-9_]+)\s*=\s*(.+)$/.test(content)) {
        const varName = content.match(/^([a-zA-Z0-9_]+)/)?.[1];
        if (varName && !['plot', 'plot_hist', 'plot_level', 'print'].includes(varName)) {
          content = 'let ' + content;
        }
      }

      if (!content.endsWith(';')) {
        content += ';';
      }
    }

    jsLines.push('  '.repeat(indentStack.length - 1) + content);
  }

  // Close remaining blocks
  while (indentStack.length > 1) {
    indentStack.pop();
    jsLines.push('  '.repeat(indentStack.length - 1) + '}');
  }

  return jsLines.join('\n');
}

/**
 * Execute Python Custom Indicator script against Candlestick dataset
 */
export function executePythonIndicator(
  code: string,
  candles: Candle[],
  defaultOverlay = true
): PythonExecutionResult {
  const startTime = performance.now();
  const logs: string[] = [];
  const rawPlots: {
    title: string;
    data: (number | null)[];
    color: string;
    width: number;
    type: CustomPlotType;
    overlay?: boolean;
    levelValue?: number;
  }[] = [];

  let scriptOverlay = defaultOverlay;

  if (!candles || candles.length === 0) {
    return {
      success: false,
      plots: [],
      overlay: defaultOverlay,
      logs: ['Error: No candle data available to compute indicator'],
      executionTimeMs: 0,
      error: 'No candle data available',
    };
  }

  try {
    // 1. Prepare Market Data Series arrays (matching Python pandas/numpy arrays)
    const open = candles.map((c) => c.open);
    const high = candles.map((c) => c.high);
    const low = candles.map((c) => c.low);
    const close = candles.map((c) => c.close);
    const volume = candles.map((c) => c.volume);
    const time = candles.map((c) => c.time);
    const bar_index = candles.map((_, i) => i);
    const n = candles.length;
    const price = close;

    // 2. Python standard print console sink
    const pyPrint = (...args: any[]) => {
      const msg = args
        .map((a) => {
          if (typeof a === 'object') {
            try {
              return JSON.stringify(a);
            } catch {
              return String(a);
            }
          }
          return String(a);
        })
        .join(' ');
      logs.push(msg);
    };

    // 3. Indicator Plotting API
    const pyPlot = (
      data: any,
      optionsOrTitle?: string | { title?: string; color?: string; width?: number; overlay?: boolean; style?: string },
      colorArg?: string,
      widthArg?: number
    ) => {
      let title = 'Plot ' + (rawPlots.length + 1);
      let color = '#38bdf8';
      let width = 2;
      let plotType: CustomPlotType = 'line';

      if (typeof optionsOrTitle === 'string') {
        title = optionsOrTitle;
        if (colorArg) color = colorArg;
        if (widthArg) width = widthArg;
      } else if (typeof optionsOrTitle === 'object' && optionsOrTitle !== null) {
        if (optionsOrTitle.title) title = optionsOrTitle.title;
        if (optionsOrTitle.color) color = optionsOrTitle.color;
        if (optionsOrTitle.width) width = optionsOrTitle.width;
        if (optionsOrTitle.overlay !== undefined) scriptOverlay = optionsOrTitle.overlay;
        if (optionsOrTitle.style === 'histogram') plotType = 'histogram';
      }

      const seriesData = Array.isArray(data) ? data : new Array(n).fill(Number(data) || null);
      rawPlots.push({
        title,
        data: seriesData,
        color,
        width,
        type: plotType,
        overlay: scriptOverlay,
      });
    };

    const pyPlotHist = (
      data: any,
      optionsOrTitle?: string | { title?: string; color?: string; width?: number },
      colorArg?: string
    ) => {
      let title = 'Histogram ' + (rawPlots.length + 1);
      let color = '#22c55e';
      if (typeof optionsOrTitle === 'string') {
        title = optionsOrTitle;
        if (colorArg) color = colorArg;
      } else if (typeof optionsOrTitle === 'object' && optionsOrTitle !== null) {
        if (optionsOrTitle.title) title = optionsOrTitle.title;
        if (optionsOrTitle.color) color = optionsOrTitle.color;
      }

      const seriesData = Array.isArray(data) ? data : new Array(n).fill(Number(data) || null);
      rawPlots.push({
        title,
        data: seriesData,
        color,
        width: 2,
        type: 'histogram',
        overlay: scriptOverlay,
      });
    };

    const pyPlotLevel = (
      levelValue: number,
      optionsOrTitle?: string | { title?: string; color?: string },
      colorArg?: string
    ) => {
      let title = 'Level ' + levelValue;
      let color = '#94a3b8';
      if (typeof optionsOrTitle === 'string') {
        title = optionsOrTitle;
        if (colorArg) color = colorArg;
      } else if (typeof optionsOrTitle === 'object' && optionsOrTitle !== null) {
        if (optionsOrTitle.title) title = optionsOrTitle.title;
        if (optionsOrTitle.color) color = optionsOrTitle.color;
      }

      // Flat series across all bars
      const seriesData = new Array(n).fill(levelValue);
      rawPlots.push({
        title,
        data: seriesData,
        color,
        width: 1,
        type: 'line',
        levelValue,
        overlay: scriptOverlay,
      });
    };

    // 4. Mathematical built-in functions
    const sma = (src: (number | null)[], period = 20) => calcSMA(src, period);
    const ema = (src: (number | null)[], period = 20) => calcEMA(src, period);
    const wma = (src: (number | null)[], period = 20) => calcWMA(src, period);
    const rsi = (src: (number | null)[], period = 14) => calcRSI(src, period);
    const std = (src: (number | null)[], period = 20) => calcStd(src, period);
    const highest = (src: (number | null)[], period = 20) => calcHighest(src, period);
    const lowest = (src: (number | null)[], period = 20) => calcLowest(src, period);
    const macd = (src: (number | null)[], f = 12, s = 26, sig = 9) => calcMACD(src, f, s, sig);
    const bollinger = (src: (number | null)[], p = 20, dev = 2) => calcBollinger(src, p, dev);
    const atr = (h = high, l = low, c = close, p = 14) => calcATR(h, l, c, p);
    const vwap = (h = high, l = low, c = close, v = volume) => calcVWAP(h, l, c, v);
    const supertrend = (h = high, l = low, c = close, p = 10, m = 3) => calcSupertrend(h, l, c, p, m);
    const roc = (src: (number | null)[], p = 14) => calcROC(src, p);

    // Python-like zip helper
    const zip = (...arrays: any[][]) => {
      const minLen = Math.min(...arrays.map((a) => a.length));
      const res: any[][] = [];
      for (let i = 0; i < minLen; i++) {
        res.push(arrays.map((a) => a[i]));
      }
      return res;
    };

    // Python math functions
    const pyMath = {
      ...Math,
      pi: Math.PI,
      e: Math.E,
    };

    // Numpy-like array utilities
    const np = {
      mean: (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length,
      std: (arr: number[]) => {
        const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
        return Math.sqrt(arr.reduce((s, x) => s + (x - avg) ** 2, 0) / arr.length);
      },
      zeros: (len: number) => new Array(len).fill(0),
      ones: (len: number) => new Array(len).fill(1),
      array: (arr: any[]) => arr,
    };

    // 5. Transpile Python to executable JavaScript
    const jsCode = transpilePythonToJS(code);

    // 6. Execute in isolated Function scope
    const evaluator = new Function(
      'open',
      'high',
      'low',
      'close',
      'volume',
      'time',
      'bar_index',
      'n',
      'price',
      'sma',
      'ema',
      'wma',
      'rsi',
      'std',
      'highest',
      'lowest',
      'macd',
      'bollinger',
      'atr',
      'vwap',
      'supertrend',
      'roc',
      'plot',
      'plot_hist',
      'plot_level',
      'hline',
      'print',
      'pyGet',
      'zip',
      'math',
      'np',
      `"use strict";
      const hline = plot_level;
      try {
        ${jsCode}
      } catch (err) {
        throw err;
      }`
    );

    evaluator(
      open,
      high,
      low,
      close,
      volume,
      time,
      bar_index,
      n,
      price,
      sma,
      ema,
      wma,
      rsi,
      std,
      highest,
      lowest,
      macd,
      bollinger,
      atr,
      vwap,
      supertrend,
      roc,
      pyPlot,
      pyPlotHist,
      pyPlotLevel,
      pyPlotLevel,
      pyPrint,
      pyGet,
      zip,
      pyMath,
      np
    );

    // 7. Map raw plots to CustomPlotOutput format with timestamps
    const finalPlots: CustomPlotOutput[] = rawPlots.map((rp, index) => {
      const dataPoints: { time: number; value: number }[] = [];
      for (let i = 0; i < candles.length; i++) {
        const val = rp.data[i];
        if (val !== null && val !== undefined && !isNaN(val)) {
          dataPoints.push({
            time: candles[i].time,
            value: Number(val),
          });
        }
      }

      return {
        id: `plot_${index}_${Date.now()}`,
        name: rp.title,
        color: rp.color,
        lineWidth: rp.width,
        type: rp.type,
        overlay: scriptOverlay,
        levelValue: rp.levelValue,
        data: dataPoints,
      };
    });

    const executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
    logs.push(`✓ Execution finished in ${executionTimeMs}ms with ${finalPlots.length} plot(s)`);

    return {
      success: true,
      plots: finalPlots,
      overlay: scriptOverlay,
      logs,
      executionTimeMs,
      error: null,
    };
  } catch (err: any) {
    const executionTimeMs = Math.round((performance.now() - startTime) * 100) / 100;
    const errorMsg = err?.message || String(err);
    logs.push(`✕ Script Error: ${errorMsg}`);

    return {
      success: false,
      plots: [],
      overlay: defaultOverlay,
      logs,
      executionTimeMs,
      error: errorMsg,
    };
  }
}

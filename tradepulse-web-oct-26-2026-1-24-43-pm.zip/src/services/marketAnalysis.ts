import { Candle, MarketAnalysisData, TechnicalSignal, Timeframe } from '../types/chart';
import { calculateEMA, calculateSMA, calculateRSI, calculateMACD } from './indicatorCalculator';

export function computeMarketAnalysis(candles: Candle[], priceDecimals: number): MarketAnalysisData | null {
  if (candles.length < 50) return null;

  const currentPrice = candles[candles.length - 1].close;
  const lastIndex = candles.length - 1;

  // 1. Oscillators
  const rsiArr = calculateRSI(candles, 14);
  const currentRSI = rsiArr[lastIndex] ?? 50;

  const macdData = calculateMACD(candles, 12, 26, 9);
  const currentMACD = macdData.macdLine[lastIndex] ?? 0;
  const currentSignal = macdData.signalLine[lastIndex] ?? 0;

  // Stochastic %K (14)
  let stochK = 50;
  if (candles.length >= 14) {
    const slice14 = candles.slice(-14);
    const highestHigh = Math.max(...slice14.map((c) => c.high));
    const lowestLow = Math.min(...slice14.map((c) => c.low));
    if (highestHigh !== lowestLow) {
      stochK = ((currentPrice - lowestLow) / (highestHigh - lowestLow)) * 100;
    }
  }

  // Commodity Channel Index (CCI 20)
  let cci = 0;
  if (candles.length >= 20) {
    const slice20 = candles.slice(-20);
    const typicalPrices = slice20.map((c) => (c.high + c.low + c.close) / 3);
    const tpMean = typicalPrices.reduce((a, b) => a + b, 0) / 20;
    const meanDev = typicalPrices.reduce((a, b) => a + Math.abs(b - tpMean), 0) / 20;
    const currentTP = (candles[lastIndex].high + candles[lastIndex].low + candles[lastIndex].close) / 3;
    cci = meanDev === 0 ? 0 : (currentTP - tpMean) / (0.015 * meanDev);
  }

  // Momentum (10)
  const mom10 = candles.length >= 11 ? currentPrice - candles[lastIndex - 10].close : 0;

  // Awesome Oscillator (AO)
  const sma5 = calculateSMA(candles, 5);
  const sma34 = calculateSMA(candles, 34);
  const ao = (sma5[lastIndex] ?? 0) - (sma34[lastIndex] ?? 0);

  const oscillatorList: { name: string; value: number | string; action: 'BUY' | 'NEUTRAL' | 'SELL' }[] = [
    {
      name: 'RSI (14)',
      value: currentRSI.toFixed(1),
      action: currentRSI < 30 ? 'BUY' : currentRSI > 70 ? 'SELL' : 'NEUTRAL',
    },
    {
      name: 'Stochastic %K (14, 3, 3)',
      value: stochK.toFixed(1),
      action: stochK < 20 ? 'BUY' : stochK > 80 ? 'SELL' : 'NEUTRAL',
    },
    {
      name: 'MACD Level (12, 26)',
      value: currentMACD.toFixed(priceDecimals),
      action: currentMACD > currentSignal ? 'BUY' : currentMACD < currentSignal ? 'SELL' : 'NEUTRAL',
    },
    {
      name: 'CCI (20)',
      value: cci.toFixed(1),
      action: cci < -100 ? 'BUY' : cci > 100 ? 'SELL' : 'NEUTRAL',
    },
    {
      name: 'Awesome Oscillator (AO)',
      value: ao.toFixed(priceDecimals),
      action: ao > 0 ? 'BUY' : ao < 0 ? 'SELL' : 'NEUTRAL',
    },
    {
      name: 'Momentum (10)',
      value: mom10.toFixed(priceDecimals),
      action: mom10 > 0 ? 'BUY' : mom10 < 0 ? 'SELL' : 'NEUTRAL',
    },
  ];

  let oscBuy = 0;
  let oscNeutral = 0;
  let oscSell = 0;
  oscillatorList.forEach((o) => {
    if (o.action === 'BUY') oscBuy++;
    else if (o.action === 'SELL') oscSell++;
    else oscNeutral++;
  });

  const oscSignal: TechnicalSignal =
    oscBuy >= 4 ? 'BUY' : oscSell >= 4 ? 'SELL' : 'NEUTRAL';

  // 2. Moving Averages (EMA 10, 20, 30, 50, 100, 200 & SMA 10, 20, 30, 50, 100, 200)
  const maPeriods = [10, 20, 30, 50, 100, 200];
  const maList: { name: string; value: number; action: 'BUY' | 'NEUTRAL' | 'SELL' }[] = [];

  maPeriods.forEach((period) => {
    if (candles.length >= period) {
      const emaVal = calculateEMA(candles, period)[lastIndex];
      if (emaVal !== null) {
        maList.push({
          name: `EMA (${period})`,
          value: Number(emaVal.toFixed(priceDecimals)),
          action: currentPrice > emaVal ? 'BUY' : 'SELL',
        });
      }
      const smaVal = calculateSMA(candles, period)[lastIndex];
      if (smaVal !== null) {
        maList.push({
          name: `SMA (${period})`,
          value: Number(smaVal.toFixed(priceDecimals)),
          action: currentPrice > smaVal ? 'BUY' : 'SELL',
        });
      }
    }
  });

  let maBuy = 0;
  let maNeutral = 0;
  let maSell = 0;
  maList.forEach((m) => {
    if (m.action === 'BUY') maBuy++;
    else if (m.action === 'SELL') maSell++;
    else maNeutral++;
  });

  const maSignal: TechnicalSignal =
    maBuy > maSell + 4 ? 'STRONG_BUY' : maBuy > maSell ? 'BUY' : maSell > maBuy + 4 ? 'STRONG_SELL' : 'SELL';

  // 3. Overall Summary
  const totalBuy = oscBuy + maBuy;
  const totalNeutral = oscNeutral + maNeutral;
  const totalSell = oscSell + maSell;

  let overallSignal: TechnicalSignal = 'NEUTRAL';
  if (totalBuy >= totalSell + 6) overallSignal = 'STRONG_BUY';
  else if (totalBuy > totalSell + 2) overallSignal = 'BUY';
  else if (totalSell >= totalBuy + 6) overallSignal = 'STRONG_SELL';
  else if (totalSell > totalBuy + 2) overallSignal = 'SELL';

  // 4. Pivot Points (Classic)
  const prevBar = candles[lastIndex - 1];
  const p = (prevBar.high + prevBar.low + prevBar.close) / 3;
  const r1 = 2 * p - prevBar.low;
  const s1 = 2 * p - prevBar.high;
  const r2 = p + (prevBar.high - prevBar.low);
  const s2 = p - (prevBar.high - prevBar.low);
  const r3 = prevBar.high + 2 * (p - prevBar.low);
  const s3 = prevBar.low - 2 * (prevBar.high - p);

  // 5. Performance Percentages
  const getPerf = (barsAgo: number) => {
    const idx = Math.max(0, lastIndex - barsAgo);
    const startPrice = candles[idx].close;
    return Number((((currentPrice - startPrice) / startPrice) * 100).toFixed(2));
  };

  const performance = {
    week1: getPerf(7),
    month1: getPerf(30),
    month3: getPerf(90),
    month6: getPerf(180),
    year1: getPerf(340),
    ytd: getPerf(Math.floor(candles.length * 0.4)),
  };

  // 6. 52-Week Range & Volatility / ATR
  const highs = candles.map((c) => c.high);
  const lows = candles.map((c) => c.low);
  const high52w = Math.max(...highs);
  const low52w = Math.min(...lows);

  // ATR (14)
  let trSum = 0;
  for (let i = lastIndex - 13; i <= lastIndex; i++) {
    if (i <= 0) continue;
    const c = candles[i];
    const prevC = candles[i - 1].close;
    const tr = Math.max(c.high - c.low, Math.abs(c.high - prevC), Math.abs(c.low - prevC));
    trSum += tr;
  }
  const atr = trSum / 14;
  const volatility = Number(((atr / currentPrice) * 100).toFixed(2));

  // 7. Multi-Timeframe Trend Matrix
  const mtfConfigs: { tf: Timeframe; label: string; lookback: number }[] = [
    { tf: '1m', label: '1m Scalp', lookback: 10 },
    { tf: '5m', label: '5m Intraday', lookback: 25 },
    { tf: '15m', label: '15m Momentum', lookback: 45 },
    { tf: '1H', label: '1H Trend', lookback: 75 },
    { tf: '4H', label: '4H Swing', lookback: 120 },
    { tf: '1D', label: '1D Daily Bias', lookback: 200 },
    { tf: '1W', label: '1W Macro', lookback: 280 },
    { tf: '6M', label: '6M Macro Trend', lookback: 330 },
    { tf: '1Y', label: '1Y Secular', lookback: 345 },
  ];

  const multiTimeframe = mtfConfigs.map((cfg) => {
    const startIdx = Math.max(0, lastIndex - cfg.lookback);
    const subset = candles.slice(startIdx);
    const subRsiArr = calculateRSI(subset, 14);
    const subRsi = subRsiArr[subRsiArr.length - 1] ?? 50;
    const subEma = calculateEMA(subset, 20)[subset.length - 1] ?? currentPrice;
    const isAboveEma = currentPrice > subEma;

    let signal: TechnicalSignal = 'NEUTRAL';
    let trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS' = 'SIDEWAYS';

    if (isAboveEma && subRsi > 55) {
      signal = subRsi > 65 ? 'STRONG_BUY' : 'BUY';
      trend = 'BULLISH';
    } else if (!isAboveEma && subRsi < 45) {
      signal = subRsi < 35 ? 'STRONG_SELL' : 'SELL';
      trend = 'BEARISH';
    }

    return {
      timeframe: cfg.tf,
      label: cfg.label,
      signal,
      rsi: Number(subRsi.toFixed(1)),
      trend,
    };
  });

  return {
    overallSignal,
    summary: {
      buy: totalBuy,
      neutral: totalNeutral,
      sell: totalSell,
    },
    oscillators: {
      signal: oscSignal,
      buy: oscBuy,
      neutral: oscNeutral,
      sell: oscSell,
      indicators: oscillatorList,
    },
    movingAverages: {
      signal: maSignal,
      buy: maBuy,
      neutral: maNeutral,
      sell: maSell,
      indicators: maList,
    },
    pivotPoints: {
      type: 'Classic',
      p: Number(p.toFixed(priceDecimals)),
      r1: Number(r1.toFixed(priceDecimals)),
      r2: Number(r2.toFixed(priceDecimals)),
      r3: Number(r3.toFixed(priceDecimals)),
      s1: Number(s1.toFixed(priceDecimals)),
      s2: Number(s2.toFixed(priceDecimals)),
      s3: Number(s3.toFixed(priceDecimals)),
    },
    performance,
    stats: {
      high52w: Number(high52w.toFixed(priceDecimals)),
      low52w: Number(low52w.toFixed(priceDecimals)),
      atr: Number(atr.toFixed(priceDecimals)),
      volatility,
    },
    multiTimeframe,
  };
}

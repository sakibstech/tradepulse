import { Candle, IndicatorConfig } from '../types/chart';

/**
 * High performance mathematical technical indicator engine
 * Matching exact outputs of Python's pandas-ta library
 */

// Simple Moving Average
export function calculateSMA(data: Candle[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  let sum = 0;

  for (let i = 0; i < data.length; i++) {
    sum += data[i].close;
    if (i >= period) {
      sum -= data[i - period].close;
    }
    if (i >= period - 1) {
      result.push(sum / period);
    } else {
      result.push(null);
    }
  }

  return result;
}

// Exponential Moving Average
export function calculateEMA(data: Candle[], period: number): (number | null)[] {
  const result: (number | null)[] = [];
  const multiplier = 2 / (period + 1);
  let previousEMA: number | null = null;

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      result.push(null);
      continue;
    }

    if (i === period - 1) {
      // First EMA is the simple average of initial values
      let sum = 0;
      for (let j = 0; j < period; j++) {
        sum += data[j].close;
      }
      previousEMA = sum / period;
      result.push(previousEMA);
    } else {
      const currentClose = data[i].close;
      const currentEMA: number = (currentClose - (previousEMA as number)) * multiplier + (previousEMA as number);
      previousEMA = currentEMA;
      result.push(currentEMA);
    }
  }

  return result;
}

// Relative Strength Index (RSI) using Wilder's Smoothing
export function calculateRSI(data: Candle[], period: number = 14): (number | null)[] {
  const result: (number | null)[] = [];
  if (data.length <= period) {
    return new Array(data.length).fill(null);
  }

  let gains = 0;
  let losses = 0;

  // Initial average gain/loss
  for (let i = 1; i <= period; i++) {
    const diff = data[i].close - data[i - 1].close;
    if (diff >= 0) gains += diff;
    else losses += Math.abs(diff);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  // First values prior to period are null
  for (let i = 0; i < period; i++) {
    result.push(null);
  }

  let rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
  let rsi = 100 - (100 / (1 + rs));
  result.push(rsi);

  // Subsequent values using Wilder's smoothed average
  for (let i = period + 1; i < data.length; i++) {
    const diff = data[i].close - data[i - 1].close;
    const currentGain = diff >= 0 ? diff : 0;
    const currentLoss = diff < 0 ? Math.abs(diff) : 0;

    avgGain = (avgGain * (period - 1) + currentGain) / period;
    avgLoss = (avgLoss * (period - 1) + currentLoss) / period;

    if (avgLoss === 0) {
      result.push(100);
    } else {
      rs = avgGain / avgLoss;
      rsi = 100 - (100 / (1 + rs));
      result.push(rsi);
    }
  }

  return result;
}

// Moving Average Convergence Divergence (MACD)
export function calculateMACD(
  data: Candle[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): {
  macdLine: (number | null)[];
  signalLine: (number | null)[];
  histogram: (number | null)[];
} {
  const fastEMA = calculateEMA(data, fastPeriod);
  const slowEMA = calculateEMA(data, slowPeriod);

  const macdLine: (number | null)[] = [];
  for (let i = 0; i < data.length; i++) {
    if (fastEMA[i] !== null && slowEMA[i] !== null) {
      macdLine.push((fastEMA[i] as number) - (slowEMA[i] as number));
    } else {
      macdLine.push(null);
    }
  }

  // Signal line is EMA of MACD Line
  const validMacdStartIndex = macdLine.findIndex((v) => v !== null);
  const signalLine: (number | null)[] = new Array(data.length).fill(null);
  const histogram: (number | null)[] = new Array(data.length).fill(null);

  if (validMacdStartIndex !== -1) {
    const validMacdValues = macdLine.slice(validMacdStartIndex) as number[];
    if (validMacdValues.length >= signalPeriod) {
      const multiplier = 2 / (signalPeriod + 1);
      let sum = 0;
      for (let j = 0; j < signalPeriod; j++) {
        sum += validMacdValues[j];
      }
      let prevSig = sum / signalPeriod;
      signalLine[validMacdStartIndex + signalPeriod - 1] = prevSig;

      for (let k = signalPeriod; k < validMacdValues.length; k++) {
        const currentVal = validMacdValues[k];
        const curSig = (currentVal - prevSig) * multiplier + prevSig;
        prevSig = curSig;
        signalLine[validMacdStartIndex + k] = curSig;
      }
    }
  }

  for (let i = 0; i < data.length; i++) {
    if (macdLine[i] !== null && signalLine[i] !== null) {
      histogram[i] = (macdLine[i] as number) - (signalLine[i] as number);
    } else {
      histogram[i] = null;
    }
  }

  return { macdLine, signalLine, histogram };
}

// Bollinger Bands (20, 2)
export function calculateBollingerBands(
  data: Candle[],
  period: number = 20,
  stdDevMultiplier: number = 2
): {
  upper: (number | null)[];
  middle: (number | null)[];
  lower: (number | null)[];
} {
  const middle = calculateSMA(data, period);
  const upper: (number | null)[] = [];
  const lower: (number | null)[] = [];

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1 || middle[i] === null) {
      upper.push(null);
      lower.push(null);
      continue;
    }

    const mean = middle[i] as number;
    let sumSquares = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const diff = data[j].close - mean;
      sumSquares += diff * diff;
    }

    const stdDev = Math.sqrt(sumSquares / period);
    upper.push(mean + stdDevMultiplier * stdDev);
    lower.push(mean - stdDevMultiplier * stdDev);
  }

  return { upper, middle, lower };
}

// Calculate Heikin-Ashi Candles
export function calculateHeikinAshi(candles: Candle[]): Candle[] {
  if (candles.length === 0) return [];
  const result: Candle[] = [];

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    const haClose = (c.open + c.high + c.low + c.close) / 4;
    let haOpen: number;

    if (i === 0) {
      haOpen = (c.open + c.close) / 2;
    } else {
      const prevHA = result[i - 1];
      haOpen = (prevHA.open + prevHA.close) / 2;
    }

    const haHigh = Math.max(c.high, haOpen, haClose);
    const haLow = Math.min(c.low, haOpen, haClose);

    result.push({
      time: c.time,
      open: haOpen,
      high: haHigh,
      low: haLow,
      close: haClose,
      volume: c.volume,
    });
  }

  return result;
}

// Enrich candles array with all indicators
export function enrichCandlesWithIndicators(candles: Candle[], config: IndicatorConfig): Candle[] {
  const smaValues = config.sma.enabled ? calculateSMA(candles, config.sma.period) : [];
  const emaValues = config.ema.enabled ? calculateEMA(candles, config.ema.period) : [];
  const rsiValues = config.rsi.enabled ? calculateRSI(candles, config.rsi.period) : [];
  const macdData = config.macd.enabled
    ? calculateMACD(candles, config.macd.fastPeriod, config.macd.slowPeriod, config.macd.signalPeriod)
    : null;
  const bbData = config.bb.enabled
    ? calculateBollingerBands(candles, config.bb.period, config.bb.stdDev)
    : null;

  return candles.map((c, i) => ({
    ...c,
    sma20: config.sma.enabled ? smaValues[i] : null,
    ema50: config.ema.enabled ? emaValues[i] : null,
    rsi: config.rsi.enabled ? rsiValues[i] : null,
    macd: macdData ? macdData.macdLine[i] : null,
    macdSignal: macdData ? macdData.signalLine[i] : null,
    macdHist: macdData ? macdData.histogram[i] : null,
    bbUpper: bbData ? bbData.upper[i] : null,
    bbMiddle: bbData ? bbData.middle[i] : null,
    bbLower: bbData ? bbData.lower[i] : null,
  }));
}

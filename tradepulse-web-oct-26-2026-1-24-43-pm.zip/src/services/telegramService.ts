import { PriceAlert, TelegramSettings } from '../types/chart';

export const DEFAULT_TELEGRAM_SETTINGS: TelegramSettings = {
  enabled: false,
  botToken: '',
  chatId: '',
  autoSendAlerts: true,
  lastTestStatus: null,
  lastTestMessage: undefined,
};

const STORAGE_KEY = 'tradepulse_telegram_settings';

/**
 * Load saved Telegram settings from localStorage
 */
export function loadTelegramSettings(): TelegramSettings {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_TELEGRAM_SETTINGS,
        ...parsed,
      };
    }
  } catch {
    // Ignore JSON parse errors
  }
  return DEFAULT_TELEGRAM_SETTINGS;
}

/**
 * Persist Telegram settings to localStorage
 */
export function saveTelegramSettings(settings: TelegramSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Ignore storage quota errors
  }
}

/**
 * Send an arbitrary HTML-formatted message to Telegram
 */
export async function sendTelegramMessage(
  botToken: string,
  chatId: string,
  htmlMessage: string
): Promise<{ success: boolean; error?: string }> {
  const cleanToken = botToken?.trim();
  const cleanChatId = chatId?.trim();

  if (!cleanToken) {
    return { success: false, error: 'Telegram Bot Token is missing.' };
  }
  if (!cleanChatId) {
    return { success: false, error: 'Telegram Chat ID is missing.' };
  }

  try {
    const endpoint = `https://api.telegram.org/bot${cleanToken}/sendMessage`;
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: cleanChatId,
        text: htmlMessage,
        parse_mode: 'HTML',
        disable_web_page_preview: true,
      }),
    });

    const data = await response.json();

    if (!data.ok) {
      let description = data.description || `Error ${data.error_code || 'unknown'}`;
      if (data.error_code === 401) {
        description = 'Invalid Bot Token. Please check token from @BotFather.';
      } else if (data.error_code === 400 && description.includes('chat not found')) {
        description = 'Chat ID not found. Ensure you started the bot by sending /start first.';
      } else if (data.error_code === 403) {
        description = 'Bot was blocked or not started by the user. Open Telegram and send /start to your bot.';
      }
      return { success: false, error: description };
    }

    return { success: true };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'Network error communicating with Telegram Bot API.',
    };
  }
}

/**
 * Format a PriceAlert trigger event into a clean, modern Telegram message
 */
export function formatAlertTelegramMessage(
  alert: PriceAlert,
  currentPrice: number,
  priceDecimals: number = 2,
  assetName?: string
): string {
  const conditionLabel =
    alert.condition === 'CROSSES_ABOVE'
      ? '🟢 Crosses Above'
      : alert.condition === 'CROSSES_BELOW'
      ? '🔴 Crosses Below'
      : '⚡ Either Way Cross';

  const formattedTarget = alert.targetPrice.toLocaleString(undefined, {
    minimumFractionDigits: priceDecimals,
    maximumFractionDigits: priceDecimals,
  });

  const formattedCurrent = currentPrice.toLocaleString(undefined, {
    minimumFractionDigits: priceDecimals,
    maximumFractionDigits: priceDecimals,
  });

  const now = new Date(alert.triggeredAt || Date.now());
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const dateStr = now.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });

  return (
    `🚨 <b>TradePulse Price Alert Triggered!</b>\n\n` +
    `📈 <b>Asset:</b> <code>${alert.symbol}</code>${assetName ? ` (${assetName})` : ''}\n` +
    `🎯 <b>Target Level:</b> <code>$${formattedTarget}</code>\n` +
    `⚡ <b>Triggered At:</b> <code>$${formattedCurrent}</code>\n` +
    `🧭 <b>Condition:</b> ${conditionLabel}\n` +
    (alert.note ? `📝 <b>Note:</b> <i>${alert.note}</i>\n` : '') +
    `⏰ <b>Timestamp:</b> ${dateStr} ${timeStr}\n\n` +
    `📡 <i>TradePulse Pro Real-Time Alerts</i>`
  );
}

/**
 * Send a verification test message to verify Telegram setup
 */
export async function sendTelegramTestMessage(
  botToken: string,
  chatId: string
): Promise<{ success: boolean; error?: string }> {
  const testMessage =
    `✅ <b>TradePulse Telegram Alert Test</b>\n\n` +
    `Your Telegram Bot connection is successfully configured!\n` +
    `You will receive instant price alerts here whenever your target levels are reached.\n\n` +
    `⏰ <i>${new Date().toLocaleString()}</i>`;

  return sendTelegramMessage(botToken, chatId, testMessage);
}

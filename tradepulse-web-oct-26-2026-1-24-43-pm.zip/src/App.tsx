import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Code } from 'lucide-react';
import {
  AssetInfo,
  Candle,
  ChartSettings,
  ChartType,
  CustomPythonIndicator,
  DrawingItem,
  DrawingToolType,
  IndicatorConfig,
  PaperTradePosition,
  PriceAlert,
  TelegramSettings,
  Timeframe,
} from './types/chart';
import {
  SUPPORTED_ASSETS,
  fetchChartHistory,
} from './services/marketData';
import { enrichCandlesWithIndicators } from './services/indicatorCalculator';
import { soundManager } from './utils/soundAlert';
import {
  loadTelegramSettings,
  saveTelegramSettings,
  formatAlertTelegramMessage,
  sendTelegramMessage,
} from './services/telegramService';
import { HeaderNav } from './components/HeaderNav';
import { DrawingToolbar } from './components/DrawingToolbar';
import { ChartContainer } from './components/ChartContainer';
import { ReplayControls } from './components/ReplayControls';
import { WatchlistSidebar } from './components/WatchlistSidebar';
import { IndicatorModal } from './components/IndicatorModal';
import { SymbolSearchModal } from './components/SymbolSearchModal';
import { SettingsModal } from './components/SettingsModal';
import { ChartSettingsModal } from './components/ChartSettingsModal';
import { CreateAlertModal } from './components/CreateAlertModal';
import { AlertToastBanner } from './components/AlertToastBanner';
import { MarketAnalysisModal } from './components/MarketAnalysisModal';
import { computeMarketAnalysis } from './services/marketAnalysis';
import { PythonScriptEditor } from './components/PythonScriptEditor';
import {
  executePythonIndicator,
  PYTHON_INDICATOR_TEMPLATES,
} from './services/pythonIndicatorEngine';

const DEFAULT_PYTHON_INDICATOR: CustomPythonIndicator = {
  id: 'py_dual_ema',
  name: 'Dual EMA Cross Ribbon',
  description: 'Fast EMA (9) and Slow EMA (21) trend crossover',
  overlay: true,
  enabled: true,
  code: `# Python Custom Indicator: Dual EMA Cross Ribbon
fast_len = 9
slow_len = 21

fast_ema = ema(close, fast_len)
slow_ema = ema(close, slow_len)

print(f"Calculated {len(close)} bars")
print(f"Latest Fast EMA: {fast_ema[-1]:.2f}")
print(f"Latest Slow EMA: {slow_ema[-1]:.2f}")

plot(fast_ema, title="Fast EMA (9)", color="#38bdf8", width=2)
plot(slow_ema, title="Slow EMA (21)", color="#f97316", width=2)
`,
  plots: [],
  logs: ['Pre-loaded Dual EMA Cross Ribbon script'],
  error: null,
};

const DEFAULT_INDICATOR_CONFIG: IndicatorConfig = {
  sma: {
    enabled: true,
    period: 20,
    color: '#38bdf8',
    lineWidth: 1,
  },
  ema: {
    enabled: true,
    period: 50,
    color: '#eab308',
    lineWidth: 1,
  },
  rsi: {
    enabled: false,
    period: 14,
    color: '#a855f7',
    overbought: 70,
    oversold: 30,
  },
  macd: {
    enabled: false,
    fastPeriod: 12,
    slowPeriod: 26,
    signalPeriod: 9,
    macdColor: '#3b82f6',
    signalColor: '#f97316',
    histUpColor: '#22c55e',
    histDownColor: '#ef4444',
  },
  bb: {
    enabled: false,
    period: 20,
    stdDev: 2,
    upperColor: '#818cf8',
    middleColor: '#a5b4fc',
    lowerColor: '#818cf8',
    fillColor: 'rgba(99, 102, 241, 0.08)',
  },
  sma200: {
    enabled: false,
    period: 200,
    color: '#f43f5e',
    lineWidth: 1,
  },
  stoch: {
    enabled: false,
    kPeriod: 14,
    dPeriod: 3,
    kColor: '#38bdf8',
    dColor: '#f97316',
  },
  supertrend: {
    enabled: false,
    period: 10,
    multiplier: 3,
    upColor: '#22c55e',
    downColor: '#ef4444',
  },
  pivotPoints: {
    enabled: false,
    type: 'Classic',
  },
};

const DEFAULT_CHART_SETTINGS: ChartSettings = {
  backgroundColor: '#0b0f19',
  showGridVert: true,
  showGridHorz: true,
  gridColor: 'rgba(30, 41, 59, 0.45)',
  upColor: '#22c55e',
  downColor: '#ef4444',
  candleBorder: true,
  soundAlerts: true,
  watermark: true,
};

export default function App() {
  // Navigation & Asset State
  const [currentSymbol, setCurrentSymbol] = useState<string>('XAUUSD=X');
  const [timeframe, setTimeframe] = useState<Timeframe>('1H');
  const [chartType, setChartType] = useState<ChartType>('candlestick');

  // Chart Customization Settings
  const [chartSettings, setChartSettings] = useState<ChartSettings>(() => {
    try {
      const saved = localStorage.getItem('tradepulse_chart_settings');
      return saved ? JSON.parse(saved) : DEFAULT_CHART_SETTINGS;
    } catch {
      return DEFAULT_CHART_SETTINGS;
    }
  });

  // Price Alerts
  const [alerts, setAlerts] = useState<PriceAlert[]>(() => {
    try {
      const saved = localStorage.getItem('tradepulse_alerts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [activeTriggeredAlerts, setActiveTriggeredAlerts] = useState<PriceAlert[]>([]);

  // Market Data
  const [rawCandles, setRawCandles] = useState<Candle[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [fastApiUrl, setFastApiUrl] = useState<string>('');

  // Technical Indicators
  const [indicatorConfig, setIndicatorConfig] = useState<IndicatorConfig>(DEFAULT_INDICATOR_CONFIG);

  // 100% Free Historical Bar Replay Engine
  const [isReplayMode, setIsReplayMode] = useState<boolean>(false);
  const [replayIndex, setReplayIndex] = useState<number>(100);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(1);
  const [isSelectingCutPoint, setIsSelectingCutPoint] = useState<boolean>(false);

  // Interactive Drawings
  const [activeDrawingTool, setActiveDrawingTool] = useState<DrawingToolType>('cursor');
  const [drawings, setDrawings] = useState<DrawingItem[]>([]);
  const [drawingColor, setDrawingColor] = useState<string>('#38bdf8');
  const [drawingLineWidth, setDrawingLineWidth] = useState<number>(1);

  // Paper Trading Simulator & Positions
  const [positions, setPositions] = useState<PaperTradePosition[]>([]);
  const [accountBalance, setAccountBalance] = useState<number>(50000); // $50k paper funding

  // Modals & Sidebars
  const [isWatchlistOpen, setIsWatchlistOpen] = useState<boolean>(true);
  const [isSymbolSearchOpen, setIsSymbolSearchOpen] = useState<boolean>(false);
  const [isIndicatorsOpen, setIsIndicatorsOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isChartSettingsOpen, setIsChartSettingsOpen] = useState<boolean>(false);
  const [isCreateAlertOpen, setIsCreateAlertOpen] = useState<boolean>(false);
  const [isMarketAnalysisOpen, setIsMarketAnalysisOpen] = useState<boolean>(false);
  const [isPythonEditorOpen, setIsPythonEditorOpen] = useState<boolean>(false);

  // Custom Python Indicator Scripts
  const [savedPythonScripts, setSavedPythonScripts] = useState<CustomPythonIndicator[]>(() => {
    try {
      const saved = localStorage.getItem('tradepulse_python_scripts');
      return saved ? JSON.parse(saved) : [DEFAULT_PYTHON_INDICATOR];
    } catch {
      return [DEFAULT_PYTHON_INDICATOR];
    }
  });

  const [customPythonIndicators, setCustomPythonIndicators] = useState<CustomPythonIndicator[]>(() => {
    try {
      const saved = localStorage.getItem('tradepulse_active_python_indicators');
      return saved ? JSON.parse(saved) : [DEFAULT_PYTHON_INDICATOR];
    } catch {
      return [DEFAULT_PYTHON_INDICATOR];
    }
  });

  const [activePythonScript, setActivePythonScript] = useState<CustomPythonIndicator>(DEFAULT_PYTHON_INDICATOR);

  // Previous price reference to detect price crossings
  const prevPriceRef = useRef<number | null>(null);

  // Find active asset info
  const currentAsset: AssetInfo = useMemo(() => {
    return (
      SUPPORTED_ASSETS.find((a) => a.symbol === currentSymbol) || SUPPORTED_ASSETS[0]
    );
  }, [currentSymbol]);

  // Save chart settings to localStorage
  const handleUpdateChartSettings = (newSettings: ChartSettings) => {
    setChartSettings(newSettings);
    try {
      localStorage.setItem('tradepulse_chart_settings', JSON.stringify(newSettings));
    } catch {
      // ignore
    }
  };

  // Save alerts to localStorage
  const saveAlerts = (newAlerts: PriceAlert[]) => {
    setAlerts(newAlerts);
    try {
      localStorage.setItem('tradepulse_alerts', JSON.stringify(newAlerts));
    } catch {
      // ignore
    }
  };

  // Telegram Notifications Settings
  const [telegramSettings, setTelegramSettings] = useState<TelegramSettings>(loadTelegramSettings);

  const handleUpdateTelegramSettings = (newSettings: TelegramSettings) => {
    setTelegramSettings(newSettings);
    saveTelegramSettings(newSettings);
  };

  // Add new price alert
  const handleSaveAlert = (newAlertData: Omit<PriceAlert, 'id' | 'createdAt' | 'triggered'>) => {
    const alert: PriceAlert = {
      ...newAlertData,
      id: `alert_${Date.now()}`,
      createdAt: Date.now(),
      triggered: false,
    };
    const updated = [alert, ...alerts];
    saveAlerts(updated);
  };

  // Delete price alert
  const handleDeleteAlert = (id: string) => {
    const updated = alerts.filter((a) => a.id !== id);
    saveAlerts(updated);
    setActiveTriggeredAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  // Dismiss triggered alert notification toast
  const handleDismissTriggeredAlert = (id: string) => {
    setActiveTriggeredAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  const handleDismissAllTriggeredAlerts = () => {
    setActiveTriggeredAlerts([]);
  };

  // Load saved drawings for symbol from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`tradepulse_drawings_${currentSymbol}`);
      if (saved) {
        setDrawings(JSON.parse(saved));
      } else {
        setDrawings([]);
      }
    } catch {
      setDrawings([]);
    }
  }, [currentSymbol]);

  // Persist drawings to localStorage
  const saveDrawings = useCallback(
    (newDrawings: DrawingItem[]) => {
      setDrawings(newDrawings);
      try {
        localStorage.setItem(
          `tradepulse_drawings_${currentSymbol}`,
          JSON.stringify(newDrawings)
        );
      } catch {
        // ignore storage quota
      }
    },
    [currentSymbol]
  );

  // Fetch chart history on symbol, timeframe, or fastApiUrl change
  useEffect(() => {
    let isCancelled = false;
    setIsLoading(true);

    fetchChartHistory(currentSymbol, timeframe, fastApiUrl)
      .then((data) => {
        if (!isCancelled) {
          setRawCandles(data);
          // Default replay cut index to 70% of dataset
          setReplayIndex(Math.floor(data.length * 0.7));
          setIsLoading(false);
        }
      })
      .catch(() => {
        if (!isCancelled) {
          setIsLoading(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [currentSymbol, timeframe, fastApiUrl]);

  // Enrich candles with all calculated indicators
  const candles = useMemo(() => {
    if (rawCandles.length === 0) return [];
    return enrichCandlesWithIndicators(rawCandles, indicatorConfig);
  }, [rawCandles, indicatorConfig]);

  // Current active candle (during replay or live)
  const activeCandle = useMemo(() => {
    if (candles.length === 0) return null;
    if (isReplayMode) {
      const idx = Math.min(replayIndex, candles.length) - 1;
      return candles[Math.max(0, idx)];
    }
    return candles[candles.length - 1];
  }, [candles, isReplayMode, replayIndex]);

  // Current price and 24h change stats
  const currentPrice = activeCandle ? activeCandle.close : currentAsset.basePrice;
  const firstCandlePrice = candles.length > 0 ? candles[0].close : currentAsset.basePrice;
  const priceChange = currentPrice - firstCandlePrice;
  const priceChangePercent = (priceChange / firstCandlePrice) * 100;

  // Real-time Market Analysis (TradingView Technicals & Gauges)
  const marketAnalysis = useMemo(() => {
    return computeMarketAnalysis(candles, currentAsset.priceDecimals);
  }, [candles, currentAsset.priceDecimals]);

  // Recalculate active Python indicators whenever candle dataset changes
  useEffect(() => {
    if (candles.length === 0) return;
    setCustomPythonIndicators((prev) => {
      let hasChange = false;
      const updated = prev.map((ind) => {
        if (!ind.enabled) return ind;
        const res = executePythonIndicator(ind.code, candles, ind.overlay);
        if (res.success) {
          hasChange = true;
          return {
            ...ind,
            plots: res.plots,
            overlay: res.overlay,
            logs: res.logs,
            executionTimeMs: res.executionTimeMs,
            error: null,
          };
        }
        return ind;
      });
      return hasChange ? updated : prev;
    });
  }, [candles]);

  // Real-time Tick Simulator (when NOT in Replay mode)
  useEffect(() => {
    if (isReplayMode || rawCandles.length === 0) return;

    const interval = setInterval(() => {
      setRawCandles((prev) => {
        if (prev.length === 0) return prev;
        const last = { ...prev[prev.length - 1] };
        // Small realistic micro-fluctuation (0.05% - 0.12%)
        const changePct = (Math.random() - 0.495) * 0.0010;
        const newClose = Number((last.close * (1 + changePct)).toFixed(currentAsset.priceDecimals));
        
        // Strict candlestick invariants: High >= max(Open, Close), Low <= min(Open, Close)
        const newHigh = Math.max(last.open, last.high, newClose);
        const newLow = Math.min(last.open, last.low, newClose);

        const updated = [...prev];
        updated[updated.length - 1] = {
          ...last,
          high: newHigh,
          low: newLow,
          close: newClose,
          volume: 0,
        };
        return updated;
      });
    }, 2500);

    return () => clearInterval(interval);
  }, [isReplayMode, currentAsset.priceDecimals, rawCandles.length]);

  // Monitor Price Alerts whenever currentPrice changes
  useEffect(() => {
    if (!currentPrice || prevPriceRef.current === null) {
      prevPriceRef.current = currentPrice;
      return;
    }

    const prevPrice = prevPriceRef.current;
    prevPriceRef.current = currentPrice;

    // Check non-triggered alerts for current symbol
    const activeAlertsForAsset = alerts.filter(
      (a) => a.symbol === currentSymbol && !a.triggered
    );

    if (activeAlertsForAsset.length === 0) return;

    let triggeredAny = false;
    const now = Date.now();

    const updatedAlerts = alerts.map((a) => {
      if (a.symbol !== currentSymbol || a.triggered) return a;

      let hasHit = false;
      if (a.condition === 'CROSSES_ABOVE') {
        if ((prevPrice < a.targetPrice && currentPrice >= a.targetPrice) || currentPrice >= a.targetPrice) {
          hasHit = true;
        }
      } else if (a.condition === 'CROSSES_BELOW') {
        if ((prevPrice > a.targetPrice && currentPrice <= a.targetPrice) || currentPrice <= a.targetPrice) {
          hasHit = true;
        }
      } else {
        // CROSSES either way
        if (
          (prevPrice < a.targetPrice && currentPrice >= a.targetPrice) ||
          (prevPrice > a.targetPrice && currentPrice <= a.targetPrice)
        ) {
          hasHit = true;
        }
      }

      if (hasHit) {
        triggeredAny = true;
        let sentToTelegram = false;

        // Check if Telegram alert should be dispatched
        const shouldSendTg =
          (a.telegramEnabled ?? telegramSettings.autoSendAlerts) &&
          telegramSettings.enabled &&
          Boolean(telegramSettings.botToken?.trim() && telegramSettings.chatId?.trim());

        if (shouldSendTg) {
          sentToTelegram = true;
          const msg = formatAlertTelegramMessage(
            a,
            currentPrice,
            currentAsset.priceDecimals,
            currentAsset.name
          );
          sendTelegramMessage(telegramSettings.botToken, telegramSettings.chatId, msg).catch(() => {});
        }

        const triggeredAlert = {
          ...a,
          triggered: true,
          triggeredAt: now,
          sentToTelegram,
        };
        setActiveTriggeredAlerts((curr) => [triggeredAlert, ...curr]);
        return triggeredAlert;
      }

      return a;
    });

    if (triggeredAny) {
      saveAlerts(updatedAlerts);
      if (chartSettings.soundAlerts) {
        soundManager.playPriceAlertChime();
      }
    }
  }, [currentPrice, currentSymbol, alerts, chartSettings.soundAlerts, telegramSettings, currentAsset]);

  // Bar Replay Auto-Playback Engine
  useEffect(() => {
    if (!isReplayMode || !isPlaying) return;

    const delayMs = Math.max(100, Math.floor(1000 / speed));
    const timer = setInterval(() => {
      setReplayIndex((prev) => {
        if (prev >= candles.length) {
          setIsPlaying(false);
          return prev;
        }
        return prev + 1;
      });
    }, delayMs);

    return () => clearInterval(timer);
  }, [isReplayMode, isPlaying, speed, candles.length]);

  // Update Paper Trading positions PnL whenever currentPrice changes
  useEffect(() => {
    if (positions.length === 0 || !activeCandle) return;

    setPositions((prev) =>
      prev.map((pos) => {
        if (pos.status === 'CLOSED') return pos;
        const priceDiff =
          pos.type === 'BUY'
            ? activeCandle.close - pos.entryPrice
            : pos.entryPrice - activeCandle.close;
        const pnl = priceDiff * pos.size;
        const pnlPercent = (priceDiff / pos.entryPrice) * 100;

        return {
          ...pos,
          currentPrice: activeCandle.close,
          pnl,
          pnlPercent,
        };
      })
    );
  }, [activeCandle]);

  // Total Open Positions Unrealized PnL
  const totalPnL = useMemo(() => {
    return positions
      .filter((p) => p.status === 'OPEN')
      .reduce((sum, p) => sum + p.pnl, 0);
  }, [positions]);

  // Execute Simulated Paper Trade at current bar
  const handleExecutePaperTrade = (type: 'BUY' | 'SELL') => {
    if (!activeCandle) return;
    const size = currentAsset.category === 'Crypto' ? 0.5 : 10;
    const newPosition: PaperTradePosition = {
      id: `trade_${Date.now()}`,
      symbol: currentSymbol,
      type,
      entryPrice: activeCandle.close,
      entryTime: activeCandle.time,
      size,
      currentPrice: activeCandle.close,
      pnl: 0,
      pnlPercent: 0,
      status: 'OPEN',
    };
    setPositions((prev) => [newPosition, ...prev]);
    setIsWatchlistOpen(true);
  };

  // Close Paper Trade position
  const handleClosePosition = (id: string) => {
    setPositions((prev) =>
      prev.map((p) => {
        if (p.id !== id || p.status === 'CLOSED') return p;
        setAccountBalance((bal) => bal + p.pnl);
        return {
          ...p,
          status: 'CLOSED',
          closedAt: activeCandle ? activeCandle.time : Math.floor(Date.now() / 1000),
          closePrice: activeCandle ? activeCandle.close : p.currentPrice,
        };
      })
    );
  };

  // Active indicators count
  const activeIndicatorsCount = useMemo(() => {
    let count = 0;
    if (indicatorConfig.sma.enabled) count++;
    if (indicatorConfig.ema.enabled) count++;
    if (indicatorConfig.rsi.enabled) count++;
    if (indicatorConfig.macd.enabled) count++;
    if (indicatorConfig.bb.enabled) count++;
    return count;
  }, [indicatorConfig]);

  // Active alerts count for badge
  const activeAlertsCount = useMemo(() => {
    return alerts.filter((a) => !a.triggered).length;
  }, [alerts]);

  // Python Script Handlers
  const handleApplyPythonScriptToChart = (script: CustomPythonIndicator) => {
    const updated = { ...script, enabled: true };
    setCustomPythonIndicators((prev) => {
      const exists = prev.some((s) => s.id === updated.id);
      const nextList = exists
        ? prev.map((s) => (s.id === updated.id ? updated : s))
        : [...prev, updated];
      try {
        localStorage.setItem('tradepulse_active_python_indicators', JSON.stringify(nextList));
      } catch {
        // ignore
      }
      return nextList;
    });

    // Also update saved scripts library
    setSavedPythonScripts((prev) => {
      const exists = prev.some((s) => s.id === updated.id);
      const nextSaved = exists
        ? prev.map((s) => (s.id === updated.id ? updated : s))
        : [...prev, updated];
      try {
        localStorage.setItem('tradepulse_python_scripts', JSON.stringify(nextSaved));
      } catch {
        // ignore
      }
      return nextSaved;
    });
  };

  const handleRemovePythonScriptFromChart = (scriptId: string) => {
    setCustomPythonIndicators((prev) => {
      const nextList = prev.filter((s) => s.id !== scriptId);
      try {
        localStorage.setItem('tradepulse_active_python_indicators', JSON.stringify(nextList));
      } catch {
        // ignore
      }
      return nextList;
    });
  };

  const handleToggleCustomPythonIndicator = (scriptId: string) => {
    setCustomPythonIndicators((prev) => {
      const nextList = prev.map((s) => (s.id === scriptId ? { ...s, enabled: !s.enabled } : s));
      try {
        localStorage.setItem('tradepulse_active_python_indicators', JSON.stringify(nextList));
      } catch {
        // ignore
      }
      return nextList;
    });
  };

  const handleSavePythonScriptList = (scripts: CustomPythonIndicator[]) => {
    setSavedPythonScripts(scripts);
    try {
      localStorage.setItem('tradepulse_python_scripts', JSON.stringify(scripts));
    } catch {
      // ignore
    }
  };

  // Drawing Handlers
  const handleAddDrawing = (item: DrawingItem) => {
    const updated = [...drawings, item];
    saveDrawings(updated);
  };

  const handleUpdateDrawing = (item: DrawingItem) => {
    const updated = drawings.map((d) => (d.id === item.id ? item : d));
    saveDrawings(updated);
  };

  const handleDeleteDrawing = (id: string) => {
    const updated = drawings.filter((d) => d.id !== id);
    saveDrawings(updated);
  };

  const handleClearAllDrawings = () => {
    saveDrawings([]);
  };

  // Export CSV Handler
  const handleExportCSV = () => {
    if (candles.length === 0) return;
    const headers = ['time', 'date', 'open', 'high', 'low', 'close', 'sma20', 'ema50', 'rsi'];
    const rows = candles.map((c) => [
      c.time,
      new Date(c.time * 1000).toISOString(),
      c.open,
      c.high,
      c.low,
      c.close,
      c.sma20 ?? '',
      c.ema50 ?? '',
      c.rsi ?? '',
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${currentSymbol}_${timeframe}_TradePulse.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Fullscreen Toggle
  const handleToggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  return (
    <div
      className="flex flex-col h-screen w-screen text-slate-100 overflow-hidden select-none transition-colors"
      style={{ backgroundColor: chartSettings.backgroundColor }}
    >
      {/* Top Header Navigation */}
      <HeaderNav
        currentAsset={currentAsset}
        currentPrice={currentPrice}
        priceChange={priceChange}
        priceChangePercent={priceChangePercent}
        timeframe={timeframe}
        onChangeTimeframe={setTimeframe}
        chartType={chartType}
        onChangeChartType={setChartType}
        onOpenSymbolSearch={() => setIsSymbolSearchOpen(true)}
        onOpenIndicators={() => setIsIndicatorsOpen(true)}
        activeIndicatorsCount={activeIndicatorsCount}
        onTogglePythonEditor={() => setIsPythonEditorOpen(!isPythonEditorOpen)}
        isPythonEditorOpen={isPythonEditorOpen}
        activePythonScriptsCount={customPythonIndicators.filter((s) => s.enabled).length}
        isReplayMode={isReplayMode}
        onToggleReplayMode={() => {
          setIsReplayMode(!isReplayMode);
          setIsPlaying(false);
          if (!isReplayMode) {
            setReplayIndex(Math.floor(candles.length * 0.7));
          }
        }}
        onToggleWatchlist={() => setIsWatchlistOpen(!isWatchlistOpen)}
        isWatchlistOpen={isWatchlistOpen}
        onOpenChartSettings={() => setIsChartSettingsOpen(true)}
        onOpenCreateAlert={() => setIsCreateAlertOpen(true)}
        activeAlertsCount={activeAlertsCount}
        onOpenMarketAnalysis={() => setIsMarketAnalysisOpen(true)}
        onToggleFullscreen={handleToggleFullscreen}
      />

      {/* Floating Price Alert Notification Toasts */}
      <AlertToastBanner
        activeTriggeredAlerts={activeTriggeredAlerts}
        onDismiss={handleDismissTriggeredAlert}
        onDismissAll={handleDismissAllTriggeredAlerts}
      />

      {/* Main Workspace: Drawing Toolbar + Chart Container + Watchlist Sidebar */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Drawing Tools Sidebar */}
        <DrawingToolbar
          activeTool={activeDrawingTool}
          setActiveTool={setActiveDrawingTool}
          selectedColor={drawingColor}
          setSelectedColor={setDrawingColor}
          selectedLineWidth={drawingLineWidth}
          setSelectedLineWidth={setDrawingLineWidth}
          drawingsCount={drawings.length}
          onClearAll={handleClearAllDrawings}
        />

        {/* Center Main Financial Chart Area (Volume removed, clean price action) */}
        <main className="flex-1 flex flex-col relative h-full overflow-hidden">
          {isLoading ? (
            <div className="flex-1 flex items-center justify-center text-slate-400 text-xs gap-2">
              <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
              <span>Loading market data for {currentSymbol}...</span>
            </div>
          ) : (
            <ChartContainer
              data={candles}
              symbol={currentSymbol}
              assetName={currentAsset.name}
              timeframe={timeframe}
              priceDecimals={currentAsset.priceDecimals}
              chartType={chartType}
              indicatorConfig={indicatorConfig}
              customPythonIndicators={customPythonIndicators}
              chartSettings={chartSettings}
              activeAlerts={alerts}
              isReplayMode={isReplayMode}
              replayIndex={replayIndex}
              isSelectingCutPoint={isSelectingCutPoint}
              onSelectCutIndex={(index) => {
                setReplayIndex(index);
                setIsSelectingCutPoint(false);
              }}
              activeDrawingTool={activeDrawingTool}
              drawings={drawings}
              onAddDrawing={handleAddDrawing}
              onUpdateDrawing={handleUpdateDrawing}
              onDeleteDrawing={handleDeleteDrawing}
              drawingColor={drawingColor}
              drawingLineWidth={drawingLineWidth}
            />
          )}

          {/* 100% Free Historical Bar Replay Controller Bar */}
          <ReplayControls
            isReplayMode={isReplayMode}
            onToggleReplayMode={() => {
              setIsReplayMode(false);
              setIsPlaying(false);
              setIsSelectingCutPoint(false);
            }}
            replayIndex={replayIndex}
            totalCandles={candles.length}
            currentCandle={activeCandle}
            isPlaying={isPlaying}
            onPlayPause={() => setIsPlaying(!isPlaying)}
            onStepForward={() => {
              setIsPlaying(false);
              setReplayIndex((prev) => Math.min(prev + 1, candles.length));
            }}
            onStepBackward={() => {
              setIsPlaying(false);
              setReplayIndex((prev) => Math.max(15, prev - 1));
            }}
            onResetReplay={() => {
              setIsPlaying(false);
              setReplayIndex(20);
            }}
            speed={speed}
            onSpeedChange={setSpeed}
            isSelectingCutPoint={isSelectingCutPoint}
            onToggleSelectCutPoint={() => setIsSelectingCutPoint(!isSelectingCutPoint)}
            onScrub={(index) => {
              setIsPlaying(false);
              setReplayIndex(index);
            }}
            onExecutePaperTrade={handleExecutePaperTrade}
            paperTradePnL={totalPnL}
            openPositionCount={positions.filter((p) => p.status === 'OPEN').length}
            priceDecimals={currentAsset.priceDecimals}
          />

          {/* Sleek Bottom Dock Bar (TradingView Pine & Python Dock) */}
          <div className="h-7 bg-[#080c16] border-t border-slate-800/80 px-3 flex items-center justify-between text-xs select-none shrink-0 z-20">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsPythonEditorOpen(!isPythonEditorOpen)}
                className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                  isPythonEditorOpen
                    ? 'bg-blue-600/25 text-blue-300 border border-blue-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
                title="Toggle Pine & Python Custom Script Editor"
              >
                <Code className="w-3.5 h-3.5 text-emerald-400" />
                <span>Pine & Python Editor</span>
                {customPythonIndicators.some((s) => s.enabled) && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </button>
            </div>
            <div className="flex items-center gap-2.5 text-[10px] text-slate-500 font-mono">
              <span className="hidden sm:inline">Python 3.12 Engine</span>
              <span className="hidden sm:inline">•</span>
              <span>{customPythonIndicators.filter((s) => s.enabled).length} Active Script(s)</span>
            </div>
          </div>
        </main>

        {/* Right Watchlist, Trades & Price Alerts Sidebar */}
        <WatchlistSidebar
          isOpen={isWatchlistOpen}
          onClose={() => setIsWatchlistOpen(false)}
          currentSymbol={currentSymbol}
          onSelectSymbol={setCurrentSymbol}
          positions={positions}
          onClosePosition={handleClosePosition}
          accountBalance={accountBalance}
          totalPnL={totalPnL}
          alerts={alerts}
          onDeleteAlert={handleDeleteAlert}
          onOpenCreateAlert={() => setIsCreateAlertOpen(true)}
          currentPrice={currentPrice}
        />
      </div>

      {/* Symbol Search Modal */}
      <SymbolSearchModal
        isOpen={isSymbolSearchOpen}
        onClose={() => setIsSymbolSearchOpen(false)}
        currentSymbol={currentSymbol}
        onSelectSymbol={setCurrentSymbol}
      />

      {/* Technical Indicators Modal */}
      <IndicatorModal
        isOpen={isIndicatorsOpen}
        onClose={() => setIsIndicatorsOpen(false)}
        config={indicatorConfig}
        onChangeConfig={setIndicatorConfig}
        customPythonIndicators={customPythonIndicators}
        onToggleCustomPythonIndicator={handleToggleCustomPythonIndicator}
        onOpenPythonEditor={() => {
          setIsIndicatorsOpen(false);
          setIsPythonEditorOpen(true);
        }}
      />

      {/* Comprehensive Chart Settings Modal */}
      <ChartSettingsModal
        isOpen={isChartSettingsOpen}
        onClose={() => setIsChartSettingsOpen(false)}
        settings={chartSettings}
        onChangeSettings={handleUpdateChartSettings}
      />

      {/* Create Price Alert Modal */}
      <CreateAlertModal
        isOpen={isCreateAlertOpen}
        onClose={() => setIsCreateAlertOpen(false)}
        currentAsset={currentAsset}
        currentPrice={currentPrice}
        alerts={alerts}
        onSaveAlert={handleSaveAlert}
        onDeleteAlert={handleDeleteAlert}
        telegramSettings={telegramSettings}
        onUpdateTelegramSettings={handleUpdateTelegramSettings}
      />

      {/* TradingView Technical Market Analysis Tool Modal */}
      <MarketAnalysisModal
        isOpen={isMarketAnalysisOpen}
        onClose={() => setIsMarketAnalysisOpen(false)}
        analysis={marketAnalysis}
        currentAsset={currentAsset}
        currentPrice={currentPrice}
        timeframe={timeframe}
        onChangeTimeframe={setTimeframe}
      />

      {/* Platform & FastAPI Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        fastApiUrl={fastApiUrl}
        onSaveFastApiUrl={setFastApiUrl}
        onExportCSV={handleExportCSV}
        onTakeScreenshot={() => {
          window.print();
        }}
      />

      {/* Pine & Python Script Editor Bottom Panel / Drawer */}
      <PythonScriptEditor
        isOpen={isPythonEditorOpen}
        onClose={() => setIsPythonEditorOpen(false)}
        candles={candles}
        activeScript={activePythonScript}
        onChangeActiveScript={setActivePythonScript}
        onApplyToChart={handleApplyPythonScriptToChart}
        onRemoveFromChart={handleRemovePythonScriptFromChart}
        savedScripts={savedPythonScripts}
        onSaveScriptList={handleSavePythonScriptList}
      />

    </div>
  );
}

export type Timeframe = 
  | '1m' | '3m' | '5m' | '15m' | '30m' | '45m'
  | '1h' | '1H' | '2h' | '3h' | '4h' | '4H'
  | '1D' | '1W' | '1M' | '3M' | '6M' | '1Y';

export type ChartType = 'candlestick' | 'line' | 'area' | 'bar' | 'heikin-ashi';

export interface Candle {
  time: number; // Unix timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  // Technical indicator overlays & oscillators
  rsi?: number | null;
  ema20?: number | null;
  sma20?: number | null;
  ema50?: number | null;
  sma200?: number | null;
  macd?: number | null;
  macdSignal?: number | null;
  macdHist?: number | null;
  bbUpper?: number | null;
  bbMiddle?: number | null;
  bbLower?: number | null;
  stochK?: number | null;
  stochD?: number | null;
  atr?: number | null;
  supertrend?: number | null;
  supertrendDirection?: 1 | -1 | null; // 1 = bullish green, -1 = bearish red
}

export type AssetCategory = 'Forex' | 'Crypto' | 'Commodities' | 'Stocks' | 'Indices';

export interface AssetInfo {
  symbol: string;
  name: string;
  category: AssetCategory;
  priceDecimals: number;
  basePrice: number;
  currency: string;
  exchange: string;
  description: string;
}

export interface IndicatorConfig {
  sma: {
    enabled: boolean;
    period: number;
    color: string;
    lineWidth: number;
  };
  ema: {
    enabled: boolean;
    period: number;
    color: string;
    lineWidth: number;
  };
  sma200: {
    enabled: boolean;
    period: number;
    color: string;
    lineWidth: number;
  };
  rsi: {
    enabled: boolean;
    period: number;
    color: string;
    overbought: number;
    oversold: number;
  };
  macd: {
    enabled: boolean;
    fastPeriod: number;
    slowPeriod: number;
    signalPeriod: number;
    macdColor: string;
    signalColor: string;
    histUpColor: string;
    histDownColor: string;
  };
  bb: {
    enabled: boolean;
    period: number;
    stdDev: number;
    upperColor: string;
    middleColor: string;
    lowerColor: string;
    fillColor: string;
  };
  stoch: {
    enabled: boolean;
    kPeriod: number;
    dPeriod: number;
    kColor: string;
    dColor: string;
  };
  supertrend: {
    enabled: boolean;
    period: number;
    multiplier: number;
    upColor: string;
    downColor: string;
  };
  pivotPoints: {
    enabled: boolean;
    type: 'Classic' | 'Fibonacci' | 'Camarilla';
  };
}

export type CustomPlotType = 'line' | 'histogram' | 'cross' | 'area';

export interface CustomPlotOutput {
  id: string;
  name: string;
  color: string;
  lineWidth?: number;
  type: CustomPlotType;
  overlay: boolean;
  paneIndex?: number;
  levelValue?: number; // for horizontal level lines (e.g. 70, 30, 0)
  data: { time: number; value: number }[];
}

export interface CustomPythonIndicator {
  id: string;
  name: string;
  description?: string;
  code: string;
  overlay: boolean;
  enabled: boolean;
  plots: CustomPlotOutput[];
  error?: string | null;
  lastExecutedAt?: number;
  executionTimeMs?: number;
  logs?: string[];
}

export type DrawingToolType = 
  | 'cursor'
  | 'trendline'
  | 'ray'
  | 'horizontal'
  | 'horizontal_ray'
  | 'vertical'
  | 'parallel_channel'
  | 'fibonacci'
  | 'fib_extension'
  | 'rectangle'
  | 'circle'
  | 'arrow'
  | 'text_note'
  | 'position_long'
  | 'position_short'
  | 'measure';

export interface DrawingPoint {
  time: number; // unix timestamp
  price: number;
}

export interface DrawingItem {
  id: string;
  type: DrawingToolType;
  points: DrawingPoint[];
  color: string;
  lineWidth: number;
  text?: string;
  extra?: {
    stopLossPrice?: number;
    takeProfitPrice?: number;
    entryPrice?: number;
    rrRatio?: number;
    channelWidth?: number;
  };
}

export interface PaperTradePosition {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  entryPrice: number;
  entryTime: number;
  size: number;
  stopLoss?: number;
  takeProfit?: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  status: 'OPEN' | 'CLOSED';
  closedAt?: number;
  closePrice?: number;
}

export interface PriceAlert {
  id: string;
  symbol: string;
  targetPrice: number;
  condition: 'CROSSES_ABOVE' | 'CROSSES_BELOW' | 'CROSSES';
  note?: string;
  createdPrice: number;
  createdAt: number;
  triggered: boolean;
  triggeredAt?: number;
  soundEnabled: boolean;
  telegramEnabled?: boolean;
  sentToTelegram?: boolean;
}

export interface TelegramSettings {
  enabled: boolean;
  botToken: string;
  chatId: string;
  autoSendAlerts: boolean;
  lastTestStatus?: 'success' | 'error' | null;
  lastTestMessage?: string;
}

export interface ChartSettings {
  backgroundColor: string;
  showGridVert: boolean;
  showGridHorz: boolean;
  gridColor: string;
  upColor: string;
  downColor: string;
  candleBorder: boolean;
  soundAlerts: boolean;
  watermark: boolean;
}

export type TechnicalSignal = 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'SELL' | 'STRONG_SELL';

export interface MultiTimeframeItem {
  timeframe: Timeframe;
  label: string;
  signal: TechnicalSignal;
  rsi: number;
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
}

export interface MarketAnalysisData {
  overallSignal: TechnicalSignal;
  summary: {
    buy: number;
    neutral: number;
    sell: number;
  };
  oscillators: {
    signal: TechnicalSignal;
    buy: number;
    neutral: number;
    sell: number;
    indicators: {
      name: string;
      value: number | string;
      action: 'BUY' | 'NEUTRAL' | 'SELL';
    }[];
  };
  movingAverages: {
    signal: TechnicalSignal;
    buy: number;
    neutral: number;
    sell: number;
    indicators: {
      name: string;
      value: number;
      action: 'BUY' | 'NEUTRAL' | 'SELL';
    }[];
  };
  pivotPoints: {
    type: string;
    p: number;
    r1: number;
    r2: number;
    r3: number;
    s1: number;
    s2: number;
    s3: number;
  };
  performance: {
    week1: number;
    month1: number;
    month3: number;
    month6: number;
    year1: number;
    ytd: number;
  };
  stats: {
    high52w: number;
    low52w: number;
    atr: number;
    volatility: number;
  };
  multiTimeframe: MultiTimeframeItem[];
}


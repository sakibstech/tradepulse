import React, { useState } from 'react';
import {
  X,
  TrendingUp,
  TrendingDown,
  Gauge,
  Layers,
  Activity,
  Clock,
  ChevronDown,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from 'lucide-react';
import { AssetInfo, MarketAnalysisData, TechnicalSignal, Timeframe } from '../types/chart';

interface MarketAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  analysis: MarketAnalysisData | null;
  currentAsset: AssetInfo;
  currentPrice: number;
  timeframe: Timeframe;
  onChangeTimeframe: (tf: Timeframe) => void;
}

const MODAL_TIMEFRAMES: Timeframe[] = ['1m', '5m', '15m', '30m', '1H', '4H', '1D', '1W', '1M', '6M', '1Y'];
const ALL_TIMEFRAMES_LIST: Timeframe[] = [
  '1m', '3m', '5m', '15m', '30m', '45m',
  '1H', '2h', '3h', '4H',
  '1D', '1W', '1M', '3M', '6M', '1Y'
];

const normalizeTf = (tf: Timeframe): string => {
  if (tf === '1h') return '1H';
  if (tf === '4h') return '4H';
  return tf;
};

export const MarketAnalysisModal: React.FC<MarketAnalysisModalProps> = ({
  isOpen,
  onClose,
  analysis,
  currentAsset,
  currentPrice,
  timeframe,
  onChangeTimeframe,
}) => {
  const [activeTab, setActiveTab] = useState<'summary' | 'oscillators' | 'averages' | 'pivots' | 'mtf'>('summary');
  const [showTfDropdown, setShowTfDropdown] = useState(false);

  if (!isOpen || !analysis) return null;

  const getSignalBadge = (sig: TechnicalSignal) => {
    switch (sig) {
      case 'STRONG_BUY':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/25 text-emerald-400 border border-emerald-500/40">Strong Buy</span>;
      case 'BUY':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">Buy</span>;
      case 'STRONG_SELL':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/25 text-red-400 border border-red-500/40">Strong Sell</span>;
      case 'SELL':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/15 text-red-300 border border-red-500/30">Sell</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-700/50 text-slate-300 border border-slate-600">Neutral</span>;
    }
  };

  const getGaugeRotation = (sig: TechnicalSignal) => {
    switch (sig) {
      case 'STRONG_SELL': return -70;
      case 'SELL': return -35;
      case 'NEUTRAL': return 0;
      case 'BUY': return 35;
      case 'STRONG_BUY': return 70;
    }
  };

  const high52 = analysis.stats.high52w;
  const low52 = analysis.stats.low52w;
  const rangePct = Math.max(0, Math.min(100, ((currentPrice - low52) / (high52 - low52 || 1)) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm select-none p-4">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-slate-100">
                  {currentAsset.symbol} Technical Market Analysis
                </h2>
                <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-blue-600/30 text-blue-300 border border-blue-500/30 font-tabular">
                  {timeframe}
                </span>
                {getSignalBadge(analysis.overallSignal)}
              </div>
              <p className="text-[11px] text-slate-400 font-tabular">
                Spot: ${currentPrice.toFixed(currentAsset.priceDecimals)} · Multi-indicator consensus engine
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Timeframe Switcher Row (Dynamic Analysis Recalculation) */}
        <div className="px-5 py-2 border-b border-slate-800/80 bg-slate-900/40 flex items-center justify-between gap-2 overflow-x-auto text-xs">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Clock className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-[11px] font-medium hidden sm:inline">Timeframe:</span>
          </div>

          <div className="flex items-center gap-1 flex-1 overflow-x-auto">
            {MODAL_TIMEFRAMES.map((tf) => {
              const isActive = normalizeTf(timeframe) === normalizeTf(tf);
              return (
                <button
                  key={tf}
                  onClick={() => onChangeTimeframe(tf)}
                  className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-colors font-tabular ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {tf}
                </button>
              );
            })}

            {!MODAL_TIMEFRAMES.some((t) => normalizeTf(t) === normalizeTf(timeframe)) && (
              <span className="px-2 py-1 rounded-md text-xs font-semibold bg-blue-600 text-white shadow-sm font-tabular">
                {timeframe}
              </span>
            )}

            {/* Timeframe Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowTfDropdown(!showTfDropdown)}
                className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
                title="More Timeframes"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {showTfDropdown && (
                <div className="absolute right-0 top-7 bg-slate-900 border border-slate-800 rounded-lg shadow-xl p-2 z-50 w-44 grid grid-cols-3 gap-1">
                  {ALL_TIMEFRAMES_LIST.map((tf) => {
                    const isActive = normalizeTf(timeframe) === normalizeTf(tf);
                    return (
                      <button
                        key={tf}
                        onClick={() => {
                          onChangeTimeframe(tf);
                          setShowTfDropdown(false);
                        }}
                        className={`p-1 text-center rounded text-xs font-medium font-tabular ${
                          isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        {tf}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="px-5 py-2 border-b border-slate-800/80 bg-slate-950 flex items-center gap-1.5 overflow-x-auto text-xs">
          <button
            onClick={() => setActiveTab('summary')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'summary'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Gauge className="w-3.5 h-3.5" />
            <span>Summary Gauges</span>
          </button>
          <button
            onClick={() => setActiveTab('mtf')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'mtf'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Multi-Timeframe Matrix</span>
          </button>
          <button
            onClick={() => setActiveTab('oscillators')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'oscillators'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Oscillators ({analysis.oscillators.indicators.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('averages')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'averages'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Moving Averages ({analysis.movingAverages.indicators.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('pivots')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1.5 ${
              activeTab === 'pivots'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Pivot Levels</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs text-slate-300 flex-1 font-tabular">
          {/* TAB 1: SUMMARY GAUGES */}
          {activeTab === 'summary' && (
            <div className="space-y-5">
              {/* 3 Technical Dials */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Dial 1: Oscillators */}
                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col items-center text-center">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                    Oscillators ({timeframe})
                  </span>
                  <div className="relative w-28 h-14 overflow-hidden mb-2">
                    <div className="w-28 h-28 rounded-full border-8 border-slate-800 border-t-amber-500 border-r-emerald-500 border-l-red-500 absolute top-0 left-0" />
                    <div
                      className="w-1 h-12 bg-white absolute bottom-0 left-[54px] origin-bottom transition-transform duration-500 rounded-full"
                      style={{ transform: `rotate(${getGaugeRotation(analysis.oscillators.signal)}deg)` }}
                    />
                  </div>
                  {getSignalBadge(analysis.oscillators.signal)}
                  <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400">
                    <span className="text-red-400">{analysis.oscillators.sell} Sell</span>
                    <span>·</span>
                    <span className="text-slate-300">{analysis.oscillators.neutral} Neutral</span>
                    <span>·</span>
                    <span className="text-emerald-400">{analysis.oscillators.buy} Buy</span>
                  </div>
                </div>

                {/* Dial 2: Overall Summary */}
                <div className="p-3.5 rounded-xl bg-slate-900 border-2 border-blue-500/40 flex flex-col items-center text-center shadow-lg">
                  <span className="text-xs font-bold text-blue-400 uppercase tracking-wider mb-2">
                    Overall Summary ({timeframe})
                  </span>
                  <div className="relative w-32 h-16 overflow-hidden mb-2">
                    <div className="w-32 h-32 rounded-full border-[10px] border-slate-800 border-t-amber-500 border-r-emerald-500 border-l-red-500 absolute top-0 left-0" />
                    <div
                      className="w-1.5 h-14 bg-white absolute bottom-0 left-[62px] origin-bottom transition-transform duration-500 rounded-full shadow"
                      style={{ transform: `rotate(${getGaugeRotation(analysis.overallSignal)}deg)` }}
                    />
                  </div>
                  {getSignalBadge(analysis.overallSignal)}
                  <div className="flex items-center gap-2 mt-2 text-[11px] font-semibold">
                    <span className="text-red-400">{analysis.summary.sell} Sell</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-slate-300">{analysis.summary.neutral} Neutral</span>
                    <span className="text-slate-500">·</span>
                    <span className="text-emerald-400">{analysis.summary.buy} Buy</span>
                  </div>
                </div>

                {/* Dial 3: Moving Averages */}
                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 flex flex-col items-center text-center">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                    Moving Averages ({timeframe})
                  </span>
                  <div className="relative w-28 h-14 overflow-hidden mb-2">
                    <div className="w-28 h-28 rounded-full border-8 border-slate-800 border-t-amber-500 border-r-emerald-500 border-l-red-500 absolute top-0 left-0" />
                    <div
                      className="w-1 h-12 bg-white absolute bottom-0 left-[54px] origin-bottom transition-transform duration-500 rounded-full"
                      style={{ transform: `rotate(${getGaugeRotation(analysis.movingAverages.signal)}deg)` }}
                    />
                  </div>
                  {getSignalBadge(analysis.movingAverages.signal)}
                  <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400">
                    <span className="text-red-400">{analysis.movingAverages.sell} Sell</span>
                    <span>·</span>
                    <span className="text-slate-300">{analysis.movingAverages.neutral} Neutral</span>
                    <span>·</span>
                    <span className="text-emerald-400">{analysis.movingAverages.buy} Buy</span>
                  </div>
                </div>
              </div>

              {/* 52-Week Range Bar */}
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                    52-Week Price Range
                  </span>
                  <span className="text-slate-200 font-bold">
                    ${currentPrice.toFixed(currentAsset.priceDecimals)} ({rangePct.toFixed(1)}% of range)
                  </span>
                </div>
                <div className="relative w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-red-500 via-amber-500 to-emerald-500 rounded-full"
                    style={{ width: `${rangePct}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>52W Low: ${low52.toFixed(currentAsset.priceDecimals)}</span>
                  <span>52W High: ${high52.toFixed(currentAsset.priceDecimals)}</span>
                </div>
              </div>

              {/* Performance Screener Matrix */}
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2.5">
                <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px] block">
                  Historical Performance Screener
                </span>
                <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-center">
                  {[
                    { label: '1 Week', val: analysis.performance.week1 },
                    { label: '1 Month', val: analysis.performance.month1 },
                    { label: '3 Months', val: analysis.performance.month3 },
                    { label: '6 Months', val: analysis.performance.month6 },
                    { label: 'YTD', val: analysis.performance.ytd },
                    { label: '1 Year', val: analysis.performance.year1 },
                  ].map((p) => {
                    const isUp = p.val >= 0;
                    return (
                      <div key={p.label} className="p-2 rounded-lg bg-slate-800/60 border border-slate-700/60">
                        <span className="text-[10px] text-slate-400 block mb-0.5">{p.label}</span>
                        <span className={`font-bold text-xs ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
                          {isUp ? '+' : ''}{p.val.toFixed(2)}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: MULTI-TIMEFRAME TREND MATRIX */}
          {activeTab === 'mtf' && (
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-xs">
                <span className="font-semibold text-slate-200 block mb-1">
                  Multi-Timeframe Horizon Matrix
                </span>
                <p className="text-slate-400 text-[11px]">
                  Simultaneous technical confirmation across scalping, intraday, swing, and macro horizons.
                  Click any row to switch the chart immediately to that timeframe.
                </p>
              </div>

              <div className="divide-y divide-slate-800/60 border border-slate-800 rounded-xl overflow-hidden bg-slate-900/40">
                {analysis.multiTimeframe.map((item) => {
                  const isActiveTf = item.timeframe === timeframe;
                  return (
                    <div
                      key={item.timeframe}
                      onClick={() => onChangeTimeframe(item.timeframe)}
                      className={`p-3 flex items-center justify-between cursor-pointer transition-colors ${
                        isActiveTf
                          ? 'bg-blue-600/15 border-l-2 border-l-blue-500'
                          : 'hover:bg-slate-800/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="w-10 font-bold text-white text-xs font-tabular">
                          {item.timeframe}
                        </span>
                        <div>
                          <span className="text-slate-200 font-semibold text-xs block">
                            {item.label}
                          </span>
                          <span className="text-[11px] text-slate-400">
                            RSI Momentum: {item.rsi}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1 text-[11px] font-semibold">
                          {item.trend === 'BULLISH' ? (
                            <span className="text-emerald-400 flex items-center gap-0.5">
                              <ArrowUpRight className="w-3.5 h-3.5" /> Bullish
                            </span>
                          ) : item.trend === 'BEARISH' ? (
                            <span className="text-red-400 flex items-center gap-0.5">
                              <ArrowDownRight className="w-3.5 h-3.5" /> Bearish
                            </span>
                          ) : (
                            <span className="text-slate-400 flex items-center gap-0.5">
                              <Minus className="w-3.5 h-3.5" /> Sideways
                            </span>
                          )}
                        </div>

                        {getSignalBadge(item.signal)}

                        {isActiveTf && (
                          <span className="text-[10px] text-blue-400 font-bold bg-blue-500/20 px-1.5 py-0.5 rounded border border-blue-500/30">
                            Active Chart
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 3: OSCILLATORS */}
          {activeTab === 'oscillators' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400 text-[11px]">
                <span>Oscillator Name ({timeframe})</span>
                <div className="flex items-center gap-12">
                  <span>Value</span>
                  <span className="w-16 text-right">Action</span>
                </div>
              </div>
              {analysis.oscillators.indicators.map((osc) => (
                <div
                  key={osc.name}
                  className="py-2.5 px-3 rounded-lg bg-slate-900/60 border border-slate-800/60 flex items-center justify-between"
                >
                  <span className="font-semibold text-slate-200">{osc.name}</span>
                  <div className="flex items-center gap-12">
                    <span className="text-slate-300 font-medium">{osc.value}</span>
                    <span
                      className={`w-16 text-right font-bold text-[11px] ${
                        osc.action === 'BUY'
                          ? 'text-emerald-400'
                          : osc.action === 'SELL'
                          ? 'text-red-400'
                          : 'text-slate-400'
                      }`}
                    >
                      {osc.action}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: MOVING AVERAGES */}
          {activeTab === 'averages' && (
            <div className="space-y-2">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400 text-[11px]">
                <span>Moving Average ({timeframe})</span>
                <div className="flex items-center gap-12">
                  <span>Level</span>
                  <span className="w-16 text-right">Action</span>
                </div>
              </div>
              {analysis.movingAverages.indicators.map((ma) => (
                <div
                  key={ma.name}
                  className="py-2.5 px-3 rounded-lg bg-slate-900/60 border border-slate-800/60 flex items-center justify-between"
                >
                  <span className="font-semibold text-slate-200">{ma.name}</span>
                  <div className="flex items-center gap-12">
                    <span className="text-slate-300 font-medium">${ma.value.toFixed(currentAsset.priceDecimals)}</span>
                    <span
                      className={`w-16 text-right font-bold text-[11px] ${
                        ma.action === 'BUY' ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {ma.action}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 5: PIVOT POINTS */}
          {activeTab === 'pivots' && (
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-xs">
                <span className="font-semibold text-slate-200 block mb-1">
                  Classic Floor Trader Pivots ({timeframe})
                </span>
                <p className="text-slate-400 text-[11px]">
                  Institutional support and resistance levels computed from previous period high, low, and close.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {/* Resistance */}
                <div className="space-y-2">
                  <span className="text-red-400 font-semibold text-[11px] uppercase tracking-wider block">
                    Resistance Levels
                  </span>
                  {[
                    { label: 'R3 (Extreme Target)', val: analysis.pivotPoints.r3 },
                    { label: 'R2 (Breakout Level)', val: analysis.pivotPoints.r2 },
                    { label: 'R1 (Initial Resistance)', val: analysis.pivotPoints.r1 },
                  ].map((lvl) => (
                    <div key={lvl.label} className="p-2.5 rounded-lg bg-red-950/20 border border-red-900/30 flex justify-between">
                      <span className="text-slate-300">{lvl.label}</span>
                      <span className="font-bold text-red-400">${lvl.val.toFixed(currentAsset.priceDecimals)}</span>
                    </div>
                  ))}
                </div>

                {/* Support */}
                <div className="space-y-2">
                  <span className="text-emerald-400 font-semibold text-[11px] uppercase tracking-wider block">
                    Support Levels
                  </span>
                  {[
                    { label: 'S1 (Initial Support)', val: analysis.pivotPoints.s1 },
                    { label: 'S2 (Key Demand Level)', val: analysis.pivotPoints.s2 },
                    { label: 'S3 (Extreme Floor)', val: analysis.pivotPoints.s3 },
                  ].map((lvl) => (
                    <div key={lvl.label} className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-900/30 flex justify-between">
                      <span className="text-slate-300">{lvl.label}</span>
                      <span className="font-bold text-emerald-400">${lvl.val.toFixed(currentAsset.priceDecimals)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Central Pivot Point */}
              <div className="p-3 rounded-lg bg-blue-950/30 border border-blue-800/40 flex items-center justify-between font-bold">
                <span className="text-blue-300">Central Pivot Point (PP):</span>
                <span className="text-white text-sm">${analysis.pivotPoints.p.toFixed(currentAsset.priceDecimals)}</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/40 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            Click any timeframe above to switch chart & analysis
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

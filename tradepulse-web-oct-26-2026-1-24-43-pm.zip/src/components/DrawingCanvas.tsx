import React, { useState, useRef, useEffect, useCallback } from 'react';
import { IChartApi, ISeriesApi } from 'lightweight-charts';
import { Candle, DrawingItem, DrawingPoint, DrawingToolType } from '../types/chart';

interface DrawingCanvasProps {
  chart: IChartApi | null;
  series: ISeriesApi<any> | null;
  activeTool: DrawingToolType;
  drawings: DrawingItem[];
  candles?: Candle[];
  onAddDrawing: (drawing: DrawingItem) => void;
  onUpdateDrawing: (drawing: DrawingItem) => void;
  onDeleteDrawing: (id: string) => void;
  selectedColor: string;
  selectedLineWidth: number;
  priceDecimals: number;
}

export const DrawingCanvas: React.FC<DrawingCanvasProps> = ({
  chart,
  series,
  activeTool,
  drawings,
  candles,
  onAddDrawing,
  onDeleteDrawing,
  selectedColor,
  selectedLineWidth,
  priceDecimals,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [inProgressPoints, setInProgressPoints] = useState<DrawingPoint[]>([]);
  const [hoveredPoint, setHoveredPoint] = useState<{ x: number; y: number } | null>(null);
  const [selectedDrawingId, setSelectedDrawingId] = useState<string | null>(null);
  const [, setRenderTrigger] = useState(0);

  // Re-render overlay whenever chart visible range or scroll changes
  useEffect(() => {
    if (!chart) return;
    const timeScale = chart.timeScale();
    const handleRangeChange = () => {
      setRenderTrigger((prev) => prev + 1);
    };

    timeScale.subscribeVisibleLogicalRangeChange(handleRangeChange);
    timeScale.subscribeVisibleTimeRangeChange(handleRangeChange);

    return () => {
      timeScale.unsubscribeVisibleLogicalRangeChange(handleRangeChange);
      timeScale.unsubscribeVisibleTimeRangeChange(handleRangeChange);
    };
  }, [chart]);

  // Convert chart data coords (time, price) to screen pixel coords (x, y)
  const getCoordinates = useCallback(
    (time: number, price: number): { x: number; y: number } | null => {
      if (!chart || !series) return null;
      try {
        const timeScale = chart.timeScale();
        // @ts-expect-error lightweight-charts accepts unix timestamp seconds as UTCTimestamp
        const x = timeScale.timeToCoordinate(time);
        const y = series.priceToCoordinate(price);
        if (x === null || y === null) return null;
        return { x, y };
      } catch {
        return null;
      }
    },
    [chart, series]
  );

  // Convert mouse pixel coords (x, y) back to chart data coords (time, price)
  const getDataCoords = useCallback(
    (clientX: number, clientY: number): DrawingPoint | null => {
      if (!chart || !series || !containerRef.current) return null;
      const rect = containerRef.current.getBoundingClientRect();
      const x = clientX - rect.left;
      const y = clientY - rect.top;

      try {
        const timeScale = chart.timeScale();
        let time = timeScale.coordinateToTime(x);
        const price = series.coordinateToPrice(y);
        if (price === null) return null;

        // If time is null because click was to the right of the latest bar
        if (time === null) {
          const visibleRange = timeScale.getVisibleRange();
          if (visibleRange) {
            time = visibleRange.to;
          }
        }
        if (time === null) return null;
        return { time: Number(time), price };
      } catch {
        return null;
      }
    },
    [chart, series]
  );

  // Calculate the exact number of candles between two timestamps
  const calculateCandleCount = useCallback(
    (time1: number, time2: number): number => {
      if (!candles || candles.length === 0) {
        return 1;
      }
      const minT = Math.min(time1, time2);
      const maxT = Math.max(time1, time2);
      let count = 0;
      for (let i = 0; i < candles.length; i++) {
        const ct = candles[i].time;
        if (ct >= minT && ct <= maxT) {
          count++;
        }
      }
      return Math.max(1, count);
    },
    [candles]
  );

  // Handle canvas click to place or finish drawings
  const handlePointerDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (activeTool === 'cursor') return;
    const pt = getDataCoords(e.clientX, e.clientY);
    if (!pt) return;

    // 1-point instant placements
    if (
      activeTool === 'horizontal' ||
      activeTool === 'horizontal_ray' ||
      activeTool === 'vertical' ||
      activeTool === 'text_note'
    ) {
      let defaultText = undefined;
      if (activeTool === 'text_note') {
        const inputNote = window.prompt('Enter chart note text:', 'Key Pivot / S&R level');
        if (!inputNote) return;
        defaultText = inputNote;
      }

      const newDrawing: DrawingItem = {
        id: `draw_${Date.now()}`,
        type: activeTool,
        points: [pt],
        color: selectedColor,
        lineWidth: selectedLineWidth,
        text: defaultText,
      };
      onAddDrawing(newDrawing);
      setInProgressPoints([]);
      return;
    }

    if (inProgressPoints.length === 0) {
      setInProgressPoints([pt]);
    } else if (inProgressPoints.length === 1) {
      // Complete 2-point drawing
      let extraData = {};
      if (activeTool === 'position_long' || activeTool === 'position_short') {
        const entry = inProgressPoints[0].price;
        const target = pt.price;
        const risk = Math.abs(target - entry) * 0.5;
        const stopLoss = activeTool === 'position_long' ? entry - risk : entry + risk;
        extraData = {
          entryPrice: entry,
          takeProfitPrice: target,
          stopLossPrice: stopLoss,
          rrRatio: 2.0,
        };
      } else if (activeTool === 'trendline') {
        extraData = {
          entryPrice: inProgressPoints[0].price,
          takeProfitPrice: pt.price,
        };
      }

      const newDrawing: DrawingItem = {
        id: `draw_${Date.now()}`,
        type: activeTool,
        points: [inProgressPoints[0], pt],
        color: selectedColor,
        lineWidth: selectedLineWidth,
        extra: extraData,
      };
      onAddDrawing(newDrawing);
      setInProgressPoints([]);
    }
  };

  const handlePointerMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setHoveredPoint({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  // Keyboard shortcut: Delete to remove selected drawing
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedDrawingId) {
        onDeleteDrawing(selectedDrawingId);
        setSelectedDrawingId(null);
      } else if (e.key === 'Escape') {
        setInProgressPoints([]);
        setSelectedDrawingId(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedDrawingId, onDeleteDrawing]);

  // Compute container bounds
  const width = containerRef.current?.clientWidth || 800;
  const height = containerRef.current?.clientHeight || 500;

  return (
    <div
      ref={containerRef}
      onMouseDown={handlePointerDown}
      onMouseMove={handlePointerMove}
      className={`absolute inset-0 z-10 ${
        activeTool !== 'cursor' ? 'cursor-crosshair pointer-events-auto' : 'pointer-events-none'
      }`}
      style={{ overflow: 'hidden' }}
    >
      <svg className="w-full h-full pointer-events-none select-none">
        <defs>
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor="#38bdf8" />
          </filter>
          <marker
            id="arrowhead"
            markerWidth="7"
            markerHeight="7"
            refX="6"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 7 3.5, 0 7" fill={selectedColor} />
          </marker>
        </defs>

        {/* Existing Persisted Drawings */}
        {drawings.map((draw) => {
          const isSelected = draw.id === selectedDrawingId;
          const strokeStyle = isSelected ? '#38bdf8' : draw.color;

          // 1. Horizontal Ray / Line
          if (draw.type === 'horizontal' && draw.points[0]) {
            const coord = getCoordinates(draw.points[0].time, draw.points[0].price);
            if (!coord) return null;
            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <line
                  x1={0}
                  y1={coord.y}
                  x2={width}
                  y2={coord.y}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                  strokeDasharray="4 4"
                />
                <rect
                  x={width - 92}
                  y={coord.y - 10}
                  width={85}
                  height={20}
                  rx={3}
                  fill="#1e293b"
                  stroke={strokeStyle}
                  strokeWidth={1}
                />
                <text
                  x={width - 50}
                  y={coord.y + 4}
                  fill="#f1f5f9"
                  fontSize={10}
                  textAnchor="middle"
                  className="font-tabular"
                >
                  {draw.points[0].price.toFixed(priceDecimals)}
                </text>
              </g>
            );
          }

          // Horizontal Ray (Starts at anchor point and extends infinitely rightward)
          if (draw.type === 'horizontal_ray' && draw.points[0]) {
            const coord = getCoordinates(draw.points[0].time, draw.points[0].price);
            if (!coord) return null;
            const startX = coord.x;
            const endX = Math.max(startX, width);

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                {/* Transparent hit area for reliable click selection */}
                <line
                  x1={startX}
                  y1={coord.y}
                  x2={endX}
                  y2={coord.y}
                  stroke="transparent"
                  strokeWidth={Math.max(14, draw.lineWidth + 10)}
                />
                {/* Visible horizontal ray line extending right */}
                <line
                  x1={startX}
                  y1={coord.y}
                  x2={endX}
                  y2={coord.y}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                  strokeLinecap="round"
                />
                {/* Starting anchor node */}
                <circle
                  cx={startX}
                  cy={coord.y}
                  r={isSelected ? 5 : 3.5}
                  fill={strokeStyle}
                  stroke="#090d16"
                  strokeWidth={1}
                />
                {isSelected && (
                  <circle
                    cx={startX}
                    cy={coord.y}
                    r={9}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth={1.5}
                    strokeDasharray="2 2"
                  />
                )}
                {/* Right edge price badge */}
                <rect
                  x={width - 92}
                  y={coord.y - 10}
                  width={85}
                  height={20}
                  rx={3}
                  fill="#1e293b"
                  stroke={strokeStyle}
                  strokeWidth={1}
                />
                <text
                  x={width - 50}
                  y={coord.y + 4}
                  fill="#f1f5f9"
                  fontSize={10}
                  textAnchor="middle"
                  className="font-tabular"
                >
                  {draw.points[0].price.toFixed(priceDecimals)}
                </text>
              </g>
            );
          }

          // 2. Vertical Time Line
          if (draw.type === 'vertical' && draw.points[0]) {
            const coord = getCoordinates(draw.points[0].time, draw.points[0].price);
            if (!coord) return null;
            const dateStr = new Date(draw.points[0].time * 1000).toLocaleDateString([], {
              month: 'short',
              day: 'numeric',
            });
            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <line
                  x1={coord.x}
                  y1={0}
                  x2={coord.x}
                  y2={height}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                  strokeDasharray="3 3"
                />
                <rect
                  x={coord.x - 30}
                  y={height - 24}
                  width={60}
                  height={18}
                  rx={3}
                  fill="#1e293b"
                  stroke={strokeStyle}
                  strokeWidth={1}
                />
                <text
                  x={coord.x}
                  y={height - 11}
                  fill="#f1f5f9"
                  fontSize={10}
                  textAnchor="middle"
                  className="font-tabular"
                >
                  {dateStr}
                </text>
              </g>
            );
          }

          // 3. Trendline (2-Point Line Segment)
          if (draw.type === 'trendline' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;
            const deltaPrice = draw.points[1].price - draw.points[0].price;
            const pct = draw.points[0].price !== 0
              ? ((deltaPrice / draw.points[0].price) * 100).toFixed(2)
              : '0.00';
            const midX = (p1.x + p2.x) / 2;
            const midY = (p1.y + p2.y) / 2;

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                {/* Transparent hit area for reliable click selection */}
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke="transparent"
                  strokeWidth={Math.max(14, draw.lineWidth + 10)}
                />
                {/* Visible Trendline segment */}
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                  strokeLinecap="round"
                />
                {/* Anchor Points */}
                <circle cx={p1.x} cy={p1.y} r={isSelected ? 5 : 3.5} fill={strokeStyle} stroke="#090d16" strokeWidth={1} />
                <circle cx={p2.x} cy={p2.y} r={isSelected ? 5 : 3.5} fill={strokeStyle} stroke="#090d16" strokeWidth={1} />
                {isSelected && (
                  <>
                    <circle cx={p1.x} cy={p1.y} r={9} fill="none" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="2 2" />
                    <circle cx={p2.x} cy={p2.y} r={9} fill="none" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="2 2" />
                  </>
                )}
                {/* Trendline Info Badge */}
                <g transform={`translate(${midX}, ${midY - 14})`}>
                  <rect
                    x={-56}
                    y={-10}
                    width={112}
                    height={20}
                    rx={4}
                    fill="#090d16"
                    fillOpacity={0.92}
                    stroke={strokeStyle}
                    strokeWidth={1}
                  />
                  <text
                    x={0}
                    y={4}
                    fill="#f1f5f9"
                    fontSize={10}
                    textAnchor="middle"
                    className="font-tabular font-medium select-none"
                  >
                    {deltaPrice >= 0 ? '+' : ''}{pct}% ({deltaPrice >= 0 ? '+' : ''}{deltaPrice.toFixed(priceDecimals)})
                  </text>
                </g>
              </g>
            );
          }

          // 4. Extended Ray
          if (draw.type === 'ray' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const extFactor = dx === 0 ? 1000 : (width - p1.x) / dx;
            const endX = p1.x + dx * extFactor;
            const endY = p1.y + dy * extFactor;

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={endX}
                  y2={endY}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                />
                <circle cx={p1.x} cy={p1.y} r={4} fill={strokeStyle} />
                <circle cx={p2.x} cy={p2.y} r={3} fill={strokeStyle} />
              </g>
            );
          }

          // 5. Parallel Channel
          if (draw.type === 'parallel_channel' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            const offset = 35; // Channel height spread
            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <polygon
                  points={`${p1.x},${p1.y - offset} ${p2.x},${p2.y - offset} ${p2.x},${p2.y + offset} ${p1.x},${p1.y + offset}`}
                  fill={draw.color}
                  fillOpacity={0.15}
                />
                {/* Upper Line */}
                <line x1={p1.x} y1={p1.y - offset} x2={p2.x} y2={p2.y - offset} stroke={strokeStyle} strokeWidth={draw.lineWidth} />
                {/* Middle Line */}
                <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke={strokeStyle} strokeWidth={1} strokeDasharray="3 3" />
                {/* Lower Line */}
                <line x1={p1.x} y1={p1.y + offset} x2={p2.x} y2={p2.y + offset} stroke={strokeStyle} strokeWidth={draw.lineWidth} />
              </g>
            );
          }

          // 6. Arrow Pointer
          if (draw.type === 'arrow' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth + 1}
                  markerEnd="url(#arrowhead)"
                />
                <circle cx={p1.x} cy={p1.y} r={3} fill={strokeStyle} />
              </g>
            );
          }

          // 7. Circle / Pivot Ellipse
          if (draw.type === 'circle' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            const rx = Math.max(15, Math.abs(p2.x - p1.x));
            const ry = Math.max(15, Math.abs(p2.y - p1.y));

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <ellipse
                  cx={p1.x}
                  cy={p1.y}
                  rx={rx}
                  ry={ry}
                  fill={draw.color}
                  fillOpacity={0.15}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                />
              </g>
            );
          }

          // 8. Text Note Annotation
          if (draw.type === 'text_note' && draw.points[0]) {
            const coord = getCoordinates(draw.points[0].time, draw.points[0].price);
            if (!coord) return null;

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <circle cx={coord.x} cy={coord.y} r={4} fill={strokeStyle} />
                <rect
                  x={coord.x + 8}
                  y={coord.y - 12}
                  width={(draw.text?.length || 10) * 7 + 16}
                  height={24}
                  rx={4}
                  fill="#1e293b"
                  stroke={strokeStyle}
                  strokeWidth={1}
                />
                <text
                  x={coord.x + 16}
                  y={coord.y + 4}
                  fill="#f8fafc"
                  fontSize={11}
                  className="font-medium"
                >
                  {draw.text || 'Note'}
                </text>
              </g>
            );
          }

          // 9. Rectangle
          if (draw.type === 'rectangle' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;
            const x = Math.min(p1.x, p2.x);
            const y = Math.min(p1.y, p2.y);
            const w = Math.abs(p2.x - p1.x);
            const h = Math.abs(p2.y - p1.y);

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <rect
                  x={x}
                  y={y}
                  width={w}
                  height={h}
                  fill={draw.color}
                  fillOpacity={0.15}
                  stroke={strokeStyle}
                  strokeWidth={draw.lineWidth}
                />
              </g>
            );
          }

          // 10. Fibonacci Retracement (Levels: 0.0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0)
          if (draw.type === 'fibonacci' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);

            // Allow priceToCoordinate fallback if one or both times are scrolled off-screen
            const p1Y = p1 ? p1.y : (series?.priceToCoordinate(draw.points[0].price) ?? null);
            const p2Y = p2 ? p2.y : (series?.priceToCoordinate(draw.points[1].price) ?? null);
            if (p1Y === null || p2Y === null) return null;

            const p1X = p1 ? p1.x : 0;
            const p2X = p2 ? p2.x : width;
            const xLeft = Math.max(0, Math.min(p1X, p2X));
            const xRight = Math.max(p1X, p2X, width);

            // Standard Fibonacci Retracement Levels: 0, 0.236, 0.382, 0.5, 0.618, 0.786, 1.0
            const fibLevels = [
              { ratio: 0.0, label: '0.0 (0.0%)', color: '#94a3b8', fill: 'rgba(148, 163, 184, 0.08)' },
              { ratio: 0.236, label: '0.236 (23.6%)', color: '#f87171', fill: 'rgba(248, 113, 113, 0.10)' },
              { ratio: 0.382, label: '0.382 (38.2%)', color: '#fb923c', fill: 'rgba(251, 146, 60, 0.10)' },
              { ratio: 0.5, label: '0.500 (50.0%)', color: '#38bdf8', fill: 'rgba(56, 189, 248, 0.12)' },
              { ratio: 0.618, label: '0.618 (61.8%)', color: '#4ade80', fill: 'rgba(74, 222, 128, 0.14)' },
              { ratio: 0.786, label: '0.786 (78.6%)', color: '#c084fc', fill: 'rgba(192, 132, 252, 0.10)' },
              { ratio: 1.0, label: '1.000 (100.0%)', color: '#818cf8', fill: 'transparent' },
            ];

            const priceDiff = draw.points[1].price - draw.points[0].price;

            // Compute coords for each level
            const computedLevels = fibLevels.map((lvl) => {
              const lvlPrice = draw.points[1].price - lvl.ratio * priceDiff;
              const y = series ? series.priceToCoordinate(lvlPrice) : null;
              return {
                ...lvl,
                price: lvlPrice,
                y,
              };
            });

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                {/* Connecting Trendline between Point 1 and Point 2 */}
                {p1 && p2 && (
                  <>
                    <line
                      x1={p1.x}
                      y1={p1.y}
                      x2={p2.x}
                      y2={p2.y}
                      stroke="transparent"
                      strokeWidth={14}
                    />
                    <line
                      x1={p1.x}
                      y1={p1.y}
                      x2={p2.x}
                      y2={p2.y}
                      stroke={isSelected ? '#38bdf8' : strokeStyle}
                      strokeWidth={isSelected ? 1.5 : 1}
                      strokeDasharray="4 3"
                    />
                    {/* Anchor 1 Node */}
                    <circle cx={p1.x} cy={p1.y} r={isSelected ? 5 : 4} fill={strokeStyle} stroke="#090d16" strokeWidth={1} />
                    {isSelected && (
                      <circle cx={p1.x} cy={p1.y} r={9} fill="none" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="2 2" />
                    )}
                    {/* Anchor 2 Node */}
                    <circle cx={p2.x} cy={p2.y} r={isSelected ? 5 : 4} fill={strokeStyle} stroke="#090d16" strokeWidth={1} />
                    {isSelected && (
                      <circle cx={p2.x} cy={p2.y} r={9} fill="none" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="2 2" />
                    )}
                  </>
                )}

                {/* Shaded Bands between consecutive levels */}
                {computedLevels.map((lvl, idx) => {
                  if (idx === computedLevels.length - 1) return null;
                  const nextLvl = computedLevels[idx + 1];
                  if (lvl.y === null || nextLvl.y === null) return null;

                  const yTop = Math.min(lvl.y, nextLvl.y);
                  const bandHeight = Math.abs(nextLvl.y - lvl.y);

                  return (
                    <rect
                      key={`band_${lvl.ratio}`}
                      x={xLeft}
                      y={yTop}
                      width={xRight - xLeft}
                      height={bandHeight}
                      fill={lvl.fill}
                    />
                  );
                })}

                {/* Retracement Horizontal Lines & Price Badges */}
                {computedLevels.map((lvl) => {
                  if (lvl.y === null) return null;
                  const textStr = `${lvl.label} · $${lvl.price.toFixed(priceDecimals)}`;
                  const badgeW = Math.max(145, textStr.length * 6.6 + 14);

                  return (
                    <g key={lvl.ratio}>
                      {/* Invisible hit area for responsive clicking */}
                      <line
                        x1={xLeft}
                        y1={lvl.y}
                        x2={xRight}
                        y2={lvl.y}
                        stroke="transparent"
                        strokeWidth={14}
                      />
                      {/* Level Line */}
                      <line
                        x1={xLeft}
                        y1={lvl.y}
                        x2={xRight}
                        y2={lvl.y}
                        stroke={lvl.color}
                        strokeWidth={lvl.ratio === 0.618 || lvl.ratio === 0.5 ? 1.5 : 1}
                        strokeDasharray={lvl.ratio === 0 || lvl.ratio === 1 ? undefined : '3 3'}
                      />
                      {/* Price Tag Badge */}
                      <rect
                        x={xLeft}
                        y={lvl.y - 14}
                        width={badgeW}
                        height={16}
                        rx={3}
                        fill="#0b0f19"
                        fillOpacity={0.92}
                        stroke={lvl.color}
                        strokeWidth={0.75}
                      />
                      <text
                        x={xLeft + 6}
                        y={lvl.y - 2}
                        fill={lvl.color}
                        fontSize={9.5}
                        className="font-tabular font-medium select-none"
                      >
                        {textStr}
                      </text>
                    </g>
                  );
                })}
              </g>
            );
          }

          // 11. Fibonacci Extension
          if (draw.type === 'fib_extension' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            const extLevels = [
              { ratio: 0.618, label: '0.618 Exp', color: '#38bdf8' },
              { ratio: 1.0, label: '1.000 Target', color: '#4ade80' },
              { ratio: 1.618, label: '1.618 Golden Ext', color: '#facc15' },
              { ratio: 2.618, label: '2.618 Expansion', color: '#fb923c' },
            ];

            const range = Math.abs(draw.points[1].price - draw.points[0].price);
            const isUp = draw.points[1].price >= draw.points[0].price;
            const xLeft = Math.min(p1.x, p2.x);
            const xRight = Math.max(p1.x, p2.x, width);

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                {extLevels.map((lvl) => {
                  const targetPrice = isUp
                    ? draw.points[1].price + range * lvl.ratio
                    : draw.points[1].price - range * lvl.ratio;
                  const lvlCoord = getCoordinates(draw.points[1].time, targetPrice);
                  if (!lvlCoord) return null;

                  return (
                    <g key={lvl.ratio}>
                      <line
                        x1={xLeft}
                        y1={lvlCoord.y}
                        x2={xRight}
                        y2={lvlCoord.y}
                        stroke={lvl.color}
                        strokeWidth={1}
                        strokeDasharray="3 3"
                      />
                      <rect
                        x={xLeft}
                        y={lvlCoord.y - 13}
                        width={140}
                        height={14}
                        fill="#0b0f19"
                        fillOpacity={0.8}
                      />
                      <text
                        x={xLeft + 4}
                        y={lvlCoord.y - 2}
                        fill={lvl.color}
                        fontSize={9}
                        className="font-tabular"
                      >
                        {lvl.label} - {targetPrice.toFixed(priceDecimals)}
                      </text>
                    </g>
                  );
                })}
              </g>
            );
          }

          // 12. Long / Short Position R:R
          if ((draw.type === 'position_long' || draw.type === 'position_short') && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            const entryY = p1.y;
            const targetY = p2.y;
            const riskHeight = Math.abs(targetY - entryY) * 0.5;
            const stopY = draw.type === 'position_long' ? entryY + riskHeight : entryY - riskHeight;
            const boxWidth = Math.max(140, Math.abs(p2.x - p1.x));

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                <rect
                  x={p1.x}
                  y={Math.min(entryY, targetY)}
                  width={boxWidth}
                  height={Math.abs(targetY - entryY)}
                  fill="#22c55e"
                  fillOpacity={0.2}
                  stroke="#22c55e"
                  strokeWidth={1}
                />
                <rect
                  x={p1.x}
                  y={Math.min(entryY, stopY)}
                  width={boxWidth}
                  height={Math.abs(stopY - entryY)}
                  fill="#ef4444"
                  fillOpacity={0.2}
                  stroke="#ef4444"
                  strokeWidth={1}
                />
                <line
                  x1={p1.x}
                  y1={entryY}
                  x2={p1.x + boxWidth}
                  y2={entryY}
                  stroke="#e2e8f0"
                  strokeWidth={1.5}
                />
                <text
                  x={p1.x + 8}
                  y={entryY - 4}
                  fill="#f8fafc"
                  fontSize={10}
                  className="font-tabular font-medium"
                >
                  {draw.type === 'position_long' ? 'LONG' : 'SHORT'} R:R 2.00
                </text>
              </g>
            );
          }

          // 13. Measure Tool (Price Range % & Number of Candles)
          if (draw.type === 'measure' && draw.points.length >= 2) {
            const p1 = getCoordinates(draw.points[0].time, draw.points[0].price);
            const p2 = getCoordinates(draw.points[1].time, draw.points[1].price);
            if (!p1 || !p2) return null;

            const deltaPrice = draw.points[1].price - draw.points[0].price;
            const pct = draw.points[0].price !== 0
              ? ((deltaPrice / draw.points[0].price) * 100).toFixed(2)
              : '0.00';
            const numCandles = calculateCandleCount(draw.points[0].time, draw.points[1].time);
            const isPositive = deltaPrice >= 0;
            const measureColor = isSelected ? '#38bdf8' : isPositive ? '#06b6d4' : '#f43f5e';
            const badgeBg = '#090d16';

            const xMin = Math.min(p1.x, p2.x);
            const yMin = Math.min(p1.y, p2.y);
            const w = Math.max(Math.abs(p2.x - p1.x), 2);
            const h = Math.max(Math.abs(p2.y - p1.y), 2);
            const badgeWidth = 148;
            const badgeHeight = 44;
            const badgeX = Math.max(10, Math.min(width - badgeWidth - 10, xMin + w / 2 - badgeWidth / 2));
            const badgeY = Math.max(10, Math.min(height - badgeHeight - 10, yMin + h / 2 - badgeHeight / 2));

            return (
              <g
                key={draw.id}
                className="pointer-events-auto cursor-pointer"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedDrawingId(draw.id);
                }}
              >
                {/* Measurement shaded rectangle */}
                <rect
                  x={xMin}
                  y={yMin}
                  width={w}
                  height={h}
                  fill={measureColor}
                  fillOpacity={isSelected ? 0.22 : 0.14}
                  stroke={measureColor}
                  strokeWidth={isSelected ? 2 : 1.5}
                  strokeDasharray="4 3"
                />

                {/* Connecting diagonal line between anchors */}
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={p2.x}
                  y2={p2.y}
                  stroke={measureColor}
                  strokeWidth={1}
                  strokeDasharray="2 2"
                  strokeOpacity={0.7}
                />

                {/* Anchor Points */}
                <circle cx={p1.x} cy={p1.y} r={isSelected ? 5 : 4} fill={measureColor} stroke="#090d16" strokeWidth={1.5} />
                <circle cx={p2.x} cy={p2.y} r={isSelected ? 5 : 4} fill={measureColor} stroke="#090d16" strokeWidth={1.5} />
                {isSelected && (
                  <>
                    <circle cx={p1.x} cy={p1.y} r={9} fill="none" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="2 2" />
                    <circle cx={p2.x} cy={p2.y} r={9} fill="none" stroke="#38bdf8" strokeWidth={1.5} strokeDasharray="2 2" />
                  </>
                )}

                {/* Measurement Callout Badge */}
                <g transform={`translate(${badgeX}, ${badgeY})`}>
                  <rect
                    width={badgeWidth}
                    height={badgeHeight}
                    rx={6}
                    fill={badgeBg}
                    fillOpacity={0.95}
                    stroke={measureColor}
                    strokeWidth={1.5}
                  />
                  {/* Top line: Price change & % */}
                  <text
                    x={badgeWidth / 2}
                    y={18}
                    fill={isPositive ? '#34d399' : '#fb7185'}
                    fontSize={11}
                    fontWeight="700"
                    textAnchor="middle"
                    className="font-tabular font-sans select-none"
                  >
                    {isPositive ? '▲ +' : '▼ '}{pct}% ({isPositive ? '+' : ''}{deltaPrice.toFixed(priceDecimals)})
                  </text>
                  {/* Bottom line: Candle Count */}
                  <text
                    x={badgeWidth / 2}
                    y={34}
                    fill="#94a3b8"
                    fontSize={10}
                    fontWeight="500"
                    textAnchor="middle"
                    className="font-tabular font-sans select-none"
                  >
                    {numCandles} {numCandles === 1 ? 'candle' : 'candles'} (bars)
                  </text>
                </g>
              </g>
            );
          }

          return null;
        })}

        {/* Live In-Progress Preview */}
        {inProgressPoints.length === 1 && hoveredPoint && (
          <g>
            {(() => {
              const p1 = getCoordinates(inProgressPoints[0].time, inProgressPoints[0].price);
              if (!p1) return null;

              if (activeTool === 'rectangle') {
                const x = Math.min(p1.x, hoveredPoint.x);
                const y = Math.min(p1.y, hoveredPoint.y);
                const w = Math.abs(hoveredPoint.x - p1.x);
                const h = Math.abs(hoveredPoint.y - p1.y);
                return (
                  <rect
                    x={x}
                    y={y}
                    width={w}
                    height={h}
                    fill={selectedColor}
                    fillOpacity={0.15}
                    stroke={selectedColor}
                    strokeDasharray="3 3"
                  />
                );
              }

              if (activeTool === 'measure') {
                const hoverTime = chart
                  ? Number(chart.timeScale().coordinateToTime(hoveredPoint.x) ?? inProgressPoints[0].time)
                  : inProgressPoints[0].time;
                const livePrice = series?.coordinateToPrice(hoveredPoint.y) ?? inProgressPoints[0].price;
                const deltaPrice = livePrice - inProgressPoints[0].price;
                const pct = inProgressPoints[0].price !== 0
                  ? ((deltaPrice / inProgressPoints[0].price) * 100).toFixed(2)
                  : '0.00';
                const numCandles = calculateCandleCount(inProgressPoints[0].time, hoverTime);
                const isPositive = deltaPrice >= 0;
                const measureColor = isPositive ? '#06b6d4' : '#f43f5e';

                const xMin = Math.min(p1.x, hoveredPoint.x);
                const yMin = Math.min(p1.y, hoveredPoint.y);
                const w = Math.max(Math.abs(hoveredPoint.x - p1.x), 2);
                const h = Math.max(Math.abs(hoveredPoint.y - p1.y), 2);
                const badgeWidth = 148;
                const badgeHeight = 44;
                const badgeX = Math.max(10, Math.min(width - badgeWidth - 10, xMin + w / 2 - badgeWidth / 2));
                const badgeY = Math.max(10, Math.min(height - badgeHeight - 10, yMin + h / 2 - badgeHeight / 2));

                return (
                  <g>
                    {/* Live measurement shaded box */}
                    <rect
                      x={xMin}
                      y={yMin}
                      width={w}
                      height={h}
                      fill={measureColor}
                      fillOpacity={0.16}
                      stroke={measureColor}
                      strokeWidth={1.5}
                      strokeDasharray="4 3"
                    />
                    {/* Diagonal guide */}
                    <line
                      x1={p1.x}
                      y1={p1.y}
                      x2={hoveredPoint.x}
                      y2={hoveredPoint.y}
                      stroke={measureColor}
                      strokeWidth={1}
                      strokeDasharray="2 2"
                      strokeOpacity={0.7}
                    />
                    {/* Corner anchors */}
                    <circle cx={p1.x} cy={p1.y} r={4.5} fill={measureColor} stroke="#090d16" strokeWidth={1} />
                    <circle cx={hoveredPoint.x} cy={hoveredPoint.y} r={4.5} fill={measureColor} stroke="#090d16" strokeWidth={1} />

                    {/* Live Metric Badge */}
                    <g transform={`translate(${badgeX}, ${badgeY})`}>
                      <rect
                        width={badgeWidth}
                        height={badgeHeight}
                        rx={6}
                        fill="#090d16"
                        fillOpacity={0.95}
                        stroke={measureColor}
                        strokeWidth={1.5}
                      />
                      <text
                        x={badgeWidth / 2}
                        y={18}
                        fill={isPositive ? '#34d399' : '#fb7185'}
                        fontSize={11}
                        fontWeight="700"
                        textAnchor="middle"
                        className="font-tabular font-sans select-none"
                      >
                        {isPositive ? '▲ +' : '▼ '}{pct}% ({isPositive ? '+' : ''}{deltaPrice.toFixed(priceDecimals)})
                      </text>
                      <text
                        x={badgeWidth / 2}
                        y={34}
                        fill="#94a3b8"
                        fontSize={10}
                        fontWeight="500"
                        textAnchor="middle"
                        className="font-tabular font-sans select-none"
                      >
                        {numCandles} {numCandles === 1 ? 'candle' : 'candles'} (bars)
                      </text>
                    </g>
                  </g>
                );
              }

              if (activeTool === 'fibonacci') {
                const xLeft = Math.min(p1.x, hoveredPoint.x);
                const xRight = Math.max(p1.x, hoveredPoint.x, width);
                const p1Price = inProgressPoints[0].price;
                const curPrice = series?.coordinateToPrice(hoveredPoint.y) ?? p1Price;
                const priceDiff = curPrice - p1Price;

                const ratios = [
                  { r: 0.0, label: '0.0 (0.0%)', color: '#94a3b8', fill: 'rgba(148, 163, 184, 0.08)' },
                  { r: 0.236, label: '0.236 (23.6%)', color: '#f87171', fill: 'rgba(248, 113, 113, 0.10)' },
                  { r: 0.382, label: '0.382 (38.2%)', color: '#fb923c', fill: 'rgba(251, 146, 60, 0.10)' },
                  { r: 0.5, label: '0.500 (50.0%)', color: '#38bdf8', fill: 'rgba(56, 189, 248, 0.12)' },
                  { r: 0.618, label: '0.618 (61.8%)', color: '#4ade80', fill: 'rgba(74, 222, 128, 0.14)' },
                  { r: 0.786, label: '0.786 (78.6%)', color: '#c084fc', fill: 'rgba(192, 132, 252, 0.10)' },
                  { r: 1.0, label: '1.000 (100.0%)', color: '#818cf8', fill: 'transparent' },
                ];

                const computedPreview = ratios.map((item) => {
                  const lvlPrice = curPrice - item.r * priceDiff;
                  const curY = series?.priceToCoordinate(lvlPrice) ?? (hoveredPoint.y - item.r * (hoveredPoint.y - p1.y));
                  return {
                    ...item,
                    price: lvlPrice,
                    y: curY,
                  };
                });

                return (
                  <g>
                    {/* Connecting reference line */}
                    <line
                      x1={p1.x}
                      y1={p1.y}
                      x2={hoveredPoint.x}
                      y2={hoveredPoint.y}
                      stroke={selectedColor}
                      strokeWidth={1.5}
                      strokeDasharray="4 3"
                    />
                    <circle cx={p1.x} cy={p1.y} r={4.5} fill={selectedColor} stroke="#090d16" strokeWidth={1} />
                    <circle cx={hoveredPoint.x} cy={hoveredPoint.y} r={4.5} fill={selectedColor} stroke="#090d16" strokeWidth={1} />

                    {/* Shaded bands between levels */}
                    {computedPreview.map((lvl, idx) => {
                      if (idx === computedPreview.length - 1) return null;
                      const nextLvl = computedPreview[idx + 1];
                      if (lvl.y === null || nextLvl.y === null) return null;
                      const yTop = Math.min(lvl.y, nextLvl.y);
                      const bandH = Math.abs(nextLvl.y - lvl.y);
                      return (
                        <rect
                          key={`live_fib_band_${lvl.r}`}
                          x={xLeft}
                          y={yTop}
                          width={xRight - xLeft}
                          height={bandH}
                          fill={lvl.fill}
                        />
                      );
                    })}

                    {/* Level lines and price tags */}
                    {computedPreview.map((lvl) => {
                      if (lvl.y === null) return null;
                      const textStr = `${lvl.label} · $${lvl.price.toFixed(priceDecimals)}`;
                      const badgeW = Math.max(145, textStr.length * 6.6 + 14);

                      return (
                        <g key={lvl.r}>
                          <line
                            x1={xLeft}
                            y1={lvl.y}
                            x2={xRight}
                            y2={lvl.y}
                            stroke={lvl.color}
                            strokeWidth={lvl.r === 0.618 || lvl.r === 0.5 ? 1.5 : 1}
                            strokeDasharray={lvl.r === 0 || lvl.r === 1 ? undefined : '3 3'}
                          />
                          <rect
                            x={xLeft}
                            y={lvl.y - 14}
                            width={badgeW}
                            height={16}
                            rx={3}
                            fill="#0b0f19"
                            fillOpacity={0.92}
                            stroke={lvl.color}
                            strokeWidth={0.75}
                          />
                          <text
                            x={xLeft + 6}
                            y={lvl.y - 2}
                            fill={lvl.color}
                            fontSize={9.5}
                            className="font-tabular font-medium select-none"
                          >
                            {textStr}
                          </text>
                        </g>
                      );
                    })}
                  </g>
                );
              }

              if (activeTool === 'circle') {
                const rx = Math.max(10, Math.abs(hoveredPoint.x - p1.x));
                const ry = Math.max(10, Math.abs(hoveredPoint.y - p1.y));
                return (
                  <ellipse
                    cx={p1.x}
                    cy={p1.y}
                    rx={rx}
                    ry={ry}
                    fill={selectedColor}
                    fillOpacity={0.15}
                    stroke={selectedColor}
                    strokeDasharray="3 3"
                  />
                );
              }

              if (activeTool === 'trendline') {
                const curPrice = series?.coordinateToPrice(hoveredPoint.y) ?? inProgressPoints[0].price;
                const dPrice = curPrice - inProgressPoints[0].price;
                const dPct = inProgressPoints[0].price !== 0
                  ? ((dPrice / inProgressPoints[0].price) * 100).toFixed(2)
                  : '0.00';
                const midX = (p1.x + hoveredPoint.x) / 2;
                const midY = (p1.y + hoveredPoint.y) / 2;

                return (
                  <g>
                    {/* Live Line Segment Preview */}
                    <line
                      x1={p1.x}
                      y1={p1.y}
                      x2={hoveredPoint.x}
                      y2={hoveredPoint.y}
                      stroke={selectedColor}
                      strokeWidth={selectedLineWidth}
                      strokeDasharray="4 3"
                    />
                    {/* Anchor 1 */}
                    <circle cx={p1.x} cy={p1.y} r={4.5} fill={selectedColor} stroke="#090d16" strokeWidth={1} />
                    <circle cx={p1.x} cy={p1.y} r={9} fill="none" stroke={selectedColor} strokeWidth={1} strokeOpacity={0.6} />
                    {/* Pointer Anchor */}
                    <circle cx={hoveredPoint.x} cy={hoveredPoint.y} r={4.5} fill={selectedColor} stroke="#090d16" strokeWidth={1} />
                    {/* Live Midpoint Metric Badge */}
                    <g transform={`translate(${midX}, ${midY - 14})`}>
                      <rect
                        x={-56}
                        y={-10}
                        width={112}
                        height={20}
                        rx={4}
                        fill="#090d16"
                        fillOpacity={0.92}
                        stroke={selectedColor}
                        strokeWidth={1}
                      />
                      <text
                        x={0}
                        y={4}
                        fill="#f8fafc"
                        fontSize={10}
                        textAnchor="middle"
                        className="font-tabular font-medium select-none"
                      >
                        {dPrice >= 0 ? '+' : ''}{dPct}% ({dPrice >= 0 ? '+' : ''}{dPrice.toFixed(priceDecimals)})
                      </text>
                    </g>
                  </g>
                );
              }

              return (
                <line
                  x1={p1.x}
                  y1={p1.y}
                  x2={hoveredPoint.x}
                  y2={hoveredPoint.y}
                  stroke={selectedColor}
                  strokeWidth={selectedLineWidth}
                  strokeDasharray="3 3"
                />
              );
            })()}
          </g>
        )}

        {/* Live Hover Preview for Horizontal Ray */}
        {activeTool === 'horizontal_ray' && inProgressPoints.length === 0 && hoveredPoint && (
          <g className="pointer-events-none">
            {/* Live Ray from hover point extending infinitely to the right */}
            <line
              x1={hoveredPoint.x}
              y1={hoveredPoint.y}
              x2={width}
              y2={hoveredPoint.y}
              stroke={selectedColor}
              strokeWidth={selectedLineWidth}
              strokeDasharray="4 3"
            />
            {/* Anchor Node at cursor */}
            <circle
              cx={hoveredPoint.x}
              cy={hoveredPoint.y}
              r={4}
              fill={selectedColor}
              stroke="#090d16"
              strokeWidth={1}
            />
            <circle
              cx={hoveredPoint.x}
              cy={hoveredPoint.y}
              r={8}
              fill="none"
              stroke={selectedColor}
              strokeWidth={1}
              strokeOpacity={0.6}
              strokeDasharray="2 2"
            />
            {/* Live Price Tag at right margin */}
            {(() => {
              const livePrice = series?.coordinateToPrice(hoveredPoint.y);
              if (livePrice === null || livePrice === undefined) return null;
              return (
                <g>
                  <rect
                    x={width - 92}
                    y={hoveredPoint.y - 10}
                    width={85}
                    height={20}
                    rx={3}
                    fill="#0f172a"
                    fillOpacity={0.92}
                    stroke={selectedColor}
                    strokeWidth={1}
                  />
                  <text
                    x={width - 50}
                    y={hoveredPoint.y + 4}
                    fill="#38bdf8"
                    fontSize={10}
                    textAnchor="middle"
                    className="font-tabular font-medium select-none"
                  >
                    {livePrice.toFixed(priceDecimals)}
                  </text>
                </g>
              );
            })()}
          </g>
        )}
      </svg>

      {/* 2-Point Drawing Guide Badge */}
      {inProgressPoints.length === 1 && activeTool === 'trendline' && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-blue-950/90 border border-blue-500/60 text-blue-100 text-xs px-3.5 py-1.5 rounded-full shadow-xl pointer-events-none flex items-center gap-2 backdrop-blur-md z-30">
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
          <span className="font-medium">Trendline: Click 2nd point to anchor line segment</span>
          <span className="text-blue-300/70 text-[10px] bg-blue-900/60 px-1.5 py-0.5 rounded">Esc to cancel</span>
        </div>
      )}

      {/* Horizontal Ray Guide Badge */}
      {activeTool === 'horizontal_ray' && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-blue-950/90 border border-blue-500/60 text-blue-100 text-xs px-3.5 py-1.5 rounded-full shadow-xl pointer-events-none flex items-center gap-2 backdrop-blur-md z-30">
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
          <span className="font-medium">Horizontal Ray: Click any bar to anchor start (extends right)</span>
        </div>
      )}

      {/* Measure Tool Guide Badges */}
      {activeTool === 'measure' && inProgressPoints.length === 0 && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-cyan-950/90 border border-cyan-500/60 text-cyan-100 text-xs px-3.5 py-1.5 rounded-full shadow-xl pointer-events-none flex items-center gap-2 backdrop-blur-md z-30">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-medium">Measure: Click 1st point to start measuring</span>
        </div>
      )}
      {activeTool === 'measure' && inProgressPoints.length === 1 && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-cyan-950/90 border border-cyan-500/60 text-cyan-100 text-xs px-3.5 py-1.5 rounded-full shadow-xl pointer-events-none flex items-center gap-2 backdrop-blur-md z-30">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-medium">Measure: Click 2nd point to calculate price % & candle count</span>
          <span className="text-cyan-300/70 text-[10px] bg-cyan-900/60 px-1.5 py-0.5 rounded">Esc to cancel</span>
        </div>
      )}

      {/* Fibonacci Retracement Guide Badges */}
      {activeTool === 'fibonacci' && inProgressPoints.length === 0 && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-indigo-950/90 border border-indigo-500/60 text-indigo-100 text-xs px-3.5 py-1.5 rounded-full shadow-xl pointer-events-none flex items-center gap-2 backdrop-blur-md z-30">
          <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
          <span className="font-medium">Fibonacci Retracement: Click 1st point (Swing High / Low)</span>
        </div>
      )}
      {activeTool === 'fibonacci' && inProgressPoints.length === 1 && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-indigo-950/90 border border-indigo-500/60 text-indigo-100 text-xs px-3.5 py-1.5 rounded-full shadow-xl pointer-events-none flex items-center gap-2 backdrop-blur-md z-30">
          <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
          <span className="font-medium">Fibonacci Retracement: Click 2nd point to anchor levels (0.236, 0.382, 0.5, 0.618, 0.786)</span>
          <span className="text-indigo-300/70 text-[10px] bg-indigo-900/60 px-1.5 py-0.5 rounded">Esc to cancel</span>
        </div>
      )}

      {/* Selected Drawing Action Bar */}
      {selectedDrawingId && (
        <div
          className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-slate-900/90 backdrop-blur border border-slate-700/80 rounded-md px-3 py-1.5 flex items-center gap-3 text-xs shadow-xl pointer-events-auto z-20"
        >
          <span className="text-slate-300 font-medium">
            {(() => {
              const d = drawings.find((it) => it.id === selectedDrawingId);
              if (d?.type === 'fibonacci') return 'Fibonacci Retracement Selected';
              if (d?.type === 'measure') return 'Measure Selected';
              if (d?.type === 'horizontal_ray') return 'Horizontal Ray Selected';
              return 'Drawing Selected';
            })()}
          </span>
          <button
            onClick={() => {
              onDeleteDrawing(selectedDrawingId);
              setSelectedDrawingId(null);
            }}
            className="text-red-400 hover:text-red-300 font-medium transition-colors"
          >
            Delete (Del)
          </button>
          <button
            onClick={() => setSelectedDrawingId(null)}
            className="text-slate-400 hover:text-slate-200"
          >
            Deselect
          </button>
        </div>
      )}
    </div>
  );
};

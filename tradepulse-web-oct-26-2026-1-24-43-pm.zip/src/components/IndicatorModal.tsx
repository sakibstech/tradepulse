import React, { useState } from 'react';
import { X, Check, Code, Plus, Play, Sparkles } from 'lucide-react';
import { CustomPythonIndicator, IndicatorConfig } from '../types/chart';

interface IndicatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: IndicatorConfig;
  onChangeConfig: (newConfig: IndicatorConfig) => void;
  customPythonIndicators?: CustomPythonIndicator[];
  onToggleCustomPythonIndicator?: (id: string) => void;
  onOpenPythonEditor?: () => void;
}

export const IndicatorModal: React.FC<IndicatorModalProps> = ({
  isOpen,
  onClose,
  config,
  onChangeConfig,
  customPythonIndicators = [],
  onToggleCustomPythonIndicator,
  onOpenPythonEditor,
}) => {
  const [modalTab, setModalTab] = useState<'standard' | 'python'>('standard');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm select-none p-4">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Technical Indicators</h2>
            <div className="flex items-center gap-1.5 mt-2">
              <button
                onClick={() => setModalTab('standard')}
                className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                  modalTab === 'standard'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                Built-in Technicals
              </button>
              <button
                onClick={() => setModalTab('python')}
                className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                  modalTab === 'python'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Code className="w-3.5 h-3.5 text-emerald-400" />
                <span>Python Scripts ({customPythonIndicators.length})</span>
              </button>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Tab Body */}
        {modalTab === 'python' ? (
          <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1">
            <div className="flex items-center justify-between">
              <div>
                <span className="font-semibold text-slate-200 text-sm block">Custom Python Indicators</span>
                <span className="text-slate-400 text-[11px]">
                  Execute custom algorithmic formulas & momentum oscillators
                </span>
              </div>
              {onOpenPythonEditor && (
                <button
                  onClick={() => {
                    onClose();
                    onOpenPythonEditor();
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-colors flex items-center gap-1 text-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Open Python Editor</span>
                </button>
              )}
            </div>

            {customPythonIndicators.length === 0 ? (
              <div className="p-8 rounded-xl border border-dashed border-slate-800 text-center space-y-3 bg-slate-900/30">
                <div className="w-10 h-10 rounded-full bg-blue-600/10 text-blue-400 mx-auto flex items-center justify-center border border-blue-500/20">
                  <Code className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-200">No Python Custom Scripts Added Yet</h4>
                  <p className="text-slate-400 text-[11px] max-w-xs mx-auto mt-1">
                    Use our built-in Python Script Editor to write custom moving averages, breakout channels, or momentum oscillators.
                  </p>
                </div>
                {onOpenPythonEditor && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenPythonEditor();
                    }}
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium transition-colors inline-flex items-center gap-1.5 text-xs shadow-md shadow-blue-500/20"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>Launch Python Script Editor</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="space-y-2.5">
                {customPythonIndicators.map((script) => (
                  <div
                    key={script.id}
                    className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/60 flex items-center justify-between"
                  >
                    <label className="flex items-center gap-2.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={script.enabled}
                        onChange={() => onToggleCustomPythonIndicator && onToggleCustomPythonIndicator(script.id)}
                        className="rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-0 cursor-pointer"
                      />
                      <div>
                        <div className="font-semibold text-slate-200">{script.name}</div>
                        <div className="text-[10px] text-slate-400">
                          {script.plots.length} plot(s) • {script.overlay ? 'Price Overlay' : 'Oscillator Pane'}
                        </div>
                      </div>
                    </label>

                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase ${
                          script.overlay ? 'bg-emerald-500/20 text-emerald-400' : 'bg-purple-500/20 text-purple-400'
                        }`}
                      >
                        {script.overlay ? 'Overlay' : 'Pane'}
                      </span>
                      {onOpenPythonEditor && (
                        <button
                          onClick={() => {
                            onClose();
                            onOpenPythonEditor();
                          }}
                          className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors"
                        >
                          Edit Script
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Standard Indicator List */
          <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* SMA (Simple Moving Average) */}
          <div className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/60">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.sma.enabled}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      sma: { ...config.sma, enabled: e.target.checked },
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
                <span className="font-semibold text-slate-200">SMA (Simple Moving Average)</span>
              </label>
              <input
                type="color"
                value={config.sma.color}
                onChange={(e) =>
                  onChangeConfig({
                    ...config,
                    sma: { ...config.sma, color: e.target.value },
                  })
                }
                className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
              />
            </div>
            {config.sma.enabled && (
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-400 block mb-1">Period (Length)</span>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={config.sma.period}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        sma: { ...config.sma, period: Number(e.target.value) || 20 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Line Width</span>
                  <select
                    value={config.sma.lineWidth}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        sma: { ...config.sma, lineWidth: Number(e.target.value) },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 focus:outline-none focus:border-blue-500"
                  >
                    <option value={1}>1px</option>
                    <option value={2}>2px</option>
                    <option value={3}>3px</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* EMA (Exponential Moving Average) */}
          <div className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/60">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.ema.enabled}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      ema: { ...config.ema, enabled: e.target.checked },
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
                <span className="font-semibold text-slate-200">
                  EMA (Exponential Moving Average)
                </span>
              </label>
              <input
                type="color"
                value={config.ema.color}
                onChange={(e) =>
                  onChangeConfig({
                    ...config,
                    ema: { ...config.ema, color: e.target.value },
                  })
                }
                className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
              />
            </div>
            {config.ema.enabled && (
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-400 block mb-1">Period (Length)</span>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={config.ema.period}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        ema: { ...config.ema, period: Number(e.target.value) || 50 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Line Width</span>
                  <select
                    value={config.ema.lineWidth}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        ema: { ...config.ema, lineWidth: Number(e.target.value) },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 focus:outline-none focus:border-blue-500"
                  >
                    <option value={1}>1px</option>
                    <option value={2}>2px</option>
                    <option value={3}>3px</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* RSI (Relative Strength Index) */}
          <div className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/60">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.rsi.enabled}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      rsi: { ...config.rsi, enabled: e.target.checked },
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
                <span className="font-semibold text-slate-200">
                  RSI (Relative Strength Index)
                </span>
              </label>
              <input
                type="color"
                value={config.rsi.color}
                onChange={(e) =>
                  onChangeConfig({
                    ...config,
                    rsi: { ...config.rsi, color: e.target.value },
                  })
                }
                className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
              />
            </div>
            {config.rsi.enabled && (
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-400 block mb-1">Length</span>
                  <input
                    type="number"
                    min={2}
                    max={50}
                    value={config.rsi.period}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        rsi: { ...config.rsi, period: Number(e.target.value) || 14 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Overbought</span>
                  <input
                    type="number"
                    value={config.rsi.overbought}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        rsi: { ...config.rsi, overbought: Number(e.target.value) || 70 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Oversold</span>
                  <input
                    type="number"
                    value={config.rsi.oversold}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        rsi: { ...config.rsi, oversold: Number(e.target.value) || 30 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* MACD */}
          <div className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/60">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.macd.enabled}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      macd: { ...config.macd, enabled: e.target.checked },
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
                <span className="font-semibold text-slate-200">MACD (12, 26, 9)</span>
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  type="color"
                  title="MACD Line Color"
                  value={config.macd.macdColor}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      macd: { ...config.macd, macdColor: e.target.value },
                    })
                  }
                  className="w-5 h-5 rounded cursor-pointer bg-transparent border-0"
                />
                <input
                  type="color"
                  title="Signal Line Color"
                  value={config.macd.signalColor}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      macd: { ...config.macd, signalColor: e.target.value },
                    })
                  }
                  className="w-5 h-5 rounded cursor-pointer bg-transparent border-0"
                />
              </div>
            </div>
            {config.macd.enabled && (
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-400 block mb-1">Fast EMA</span>
                  <input
                    type="number"
                    value={config.macd.fastPeriod}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        macd: { ...config.macd, fastPeriod: Number(e.target.value) || 12 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Slow EMA</span>
                  <input
                    type="number"
                    value={config.macd.slowPeriod}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        macd: { ...config.macd, slowPeriod: Number(e.target.value) || 26 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Signal</span>
                  <input
                    type="number"
                    value={config.macd.signalPeriod}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        macd: { ...config.macd, signalPeriod: Number(e.target.value) || 9 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Bollinger Bands */}
          <div className="p-3 rounded-lg border border-slate-800/80 bg-slate-900/60">
            <div className="flex items-center justify-between mb-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.bb.enabled}
                  onChange={(e) =>
                    onChangeConfig({
                      ...config,
                      bb: { ...config.bb, enabled: e.target.checked },
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
                <span className="font-semibold text-slate-200">Bollinger Bands (20, 2)</span>
              </label>
              <input
                type="color"
                value={config.bb.upperColor}
                onChange={(e) =>
                  onChangeConfig({
                    ...config,
                    bb: { ...config.bb, upperColor: e.target.value },
                  })
                }
                className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
              />
            </div>
            {config.bb.enabled && (
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800/60">
                <div>
                  <span className="text-slate-400 block mb-1">Period</span>
                  <input
                    type="number"
                    value={config.bb.period}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        bb: { ...config.bb, period: Number(e.target.value) || 20 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Std Dev Multiplier</span>
                  <input
                    type="number"
                    step="0.1"
                    value={config.bb.stdDev}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        bb: { ...config.bb, stdDev: Number(e.target.value) || 2 },
                      })
                    }
                    className="w-full bg-slate-800 border border-slate-700 rounded px-2.5 py-1 text-slate-100 font-tabular focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/40 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition-colors flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  );
};

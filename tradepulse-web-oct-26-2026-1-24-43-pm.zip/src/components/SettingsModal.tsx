import React, { useState } from 'react';
import { X, Server, Check, Download, Camera } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  fastApiUrl: string;
  onSaveFastApiUrl: (url: string) => void;
  onExportCSV: () => void;
  onTakeScreenshot: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  fastApiUrl,
  onSaveFastApiUrl,
  onExportCSV,
  onTakeScreenshot,
}) => {
  const [url, setUrl] = useState(fastApiUrl);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm select-none p-4">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Server className="w-4 h-4 text-blue-400" />
            <h2 className="text-base font-semibold text-slate-100">Platform Settings</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-5 space-y-5 text-xs text-slate-300">
          {/* FastAPI Backend URL (PRD Requirement) */}
          <div className="space-y-1.5">
            <label className="font-semibold text-slate-200 block">
              Python FastAPI Backend Endpoint
            </label>
            <p className="text-[11px] text-slate-400">
              Optionally connect to your local or deployed FastAPI service (e.g. <code>http://localhost:8000</code>).
              Leave empty to use built-in high-speed data & Binance live feeds.
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="http://localhost:8000"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-slate-100 font-mono text-xs focus:outline-none focus:border-blue-500"
              />
              <button
                onClick={() => {
                  onSaveFastApiUrl(url);
                  onClose();
                }}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-medium transition-colors"
              >
                Save
              </button>
            </div>
          </div>

          {/* Export and Screenshot Tools */}
          <div className="pt-3 border-t border-slate-800 space-y-2">
            <span className="font-semibold text-slate-200 block">Data & Export Tools</span>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  onExportCSV();
                  onClose();
                }}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors font-medium"
              >
                <Download className="w-3.5 h-3.5 text-blue-400" />
                <span>Export OHLCV (CSV)</span>
              </button>
              <button
                onClick={() => {
                  onTakeScreenshot();
                  onClose();
                }}
                className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition-colors font-medium"
              >
                <Camera className="w-3.5 h-3.5 text-emerald-400" />
                <span>Chart Snapshot</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

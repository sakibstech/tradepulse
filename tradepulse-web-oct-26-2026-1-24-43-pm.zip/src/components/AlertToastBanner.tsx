import React from 'react';
import { Bell, X, ArrowUp, ArrowDown, Check } from 'lucide-react';
import { PriceAlert } from '../types/chart';

interface AlertToastBannerProps {
  activeTriggeredAlerts: PriceAlert[];
  onDismiss: (id: string) => void;
  onDismissAll: () => void;
}

export const AlertToastBanner: React.FC<AlertToastBannerProps> = ({
  activeTriggeredAlerts,
  onDismiss,
  onDismissAll,
}) => {
  if (activeTriggeredAlerts.length === 0) return null;

  return (
    <div className="fixed top-16 right-4 z-50 flex flex-col gap-2 max-w-sm w-full select-none pointer-events-auto">
      {activeTriggeredAlerts.slice(0, 3).map((alert) => (
        <div
          key={alert.id}
          className="bg-slate-900/95 border-2 border-amber-500/80 rounded-xl p-3.5 shadow-2xl backdrop-blur-md flex items-start gap-3 animate-slide-in"
        >
          <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/40">
            <Bell className="w-4 h-4 animate-bounce" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-100 text-xs">
                Price Alert Triggered!
              </span>
              <button
                onClick={() => onDismiss(alert.id)}
                className="text-slate-400 hover:text-slate-200 p-0.5 rounded"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="flex items-center gap-1.5 mt-1 font-tabular text-xs">
              <span className="font-semibold text-blue-400">{alert.symbol}</span>
              <span className="text-slate-400">hit</span>
              <span className="font-bold text-amber-400">
                ${alert.targetPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </span>
              {alert.condition === 'CROSSES_ABOVE' ? (
                <span className="text-emerald-400 flex items-center text-[10px]">
                  <ArrowUp className="w-3 h-3" /> Above
                </span>
              ) : (
                <span className="text-red-400 flex items-center text-[10px]">
                  <ArrowDown className="w-3 h-3" /> Below
                </span>
              )}
            </div>

            {alert.note && (
              <p className="text-[11px] text-slate-300 mt-1 italic truncate">
                "{alert.note}"
              </p>
            )}

            {alert.sentToTelegram && (
              <div className="mt-1 flex items-center gap-1 text-[10px] text-sky-400 font-medium">
                <span>✈️ Delivered to Telegram</span>
              </div>
            )}

            <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              <span>{new Date(alert.triggeredAt || Date.now()).toLocaleTimeString()}</span>
              <button
                onClick={() => onDismiss(alert.id)}
                className="text-amber-400 hover:underline font-medium flex items-center gap-0.5"
              >
                <Check className="w-3 h-3" /> Acknowledge
              </button>
            </div>
          </div>
        </div>
      ))}

      {activeTriggeredAlerts.length > 1 && (
        <button
          onClick={onDismissAll}
          className="self-end px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-md border border-slate-700 transition-colors"
        >
          Dismiss All ({activeTriggeredAlerts.length})
        </button>
      )}
    </div>
  );
};

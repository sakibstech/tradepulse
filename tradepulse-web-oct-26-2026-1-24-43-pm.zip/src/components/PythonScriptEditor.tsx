import React, { useState, useRef, useEffect } from 'react';
import {
  Code,
  Play,
  Save,
  Trash2,
  Maximize2,
  Minimize2,
  X,
  FileCode,
  Terminal,
  Palette,
  FolderOpen,
  Check,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  Sparkles,
  Layers,
  RotateCcw,
} from 'lucide-react';
import { Candle, CustomPlotOutput, CustomPythonIndicator } from '../types/chart';
import {
  PYTHON_INDICATOR_TEMPLATES,
  executePythonIndicator,
  PythonTemplate,
} from '../services/pythonIndicatorEngine';

interface PythonScriptEditorProps {
  isOpen: boolean;
  onClose: () => void;
  candles: Candle[];
  activeScript: CustomPythonIndicator;
  onChangeActiveScript: (script: CustomPythonIndicator) => void;
  onApplyToChart: (script: CustomPythonIndicator) => void;
  onRemoveFromChart: (scriptId: string) => void;
  savedScripts: CustomPythonIndicator[];
  onSaveScriptList: (scripts: CustomPythonIndicator[]) => void;
}

type TabType = 'editor' | 'console' | 'styles' | 'library' | 'docs';

export const PythonScriptEditor: React.FC<PythonScriptEditorProps> = ({
  isOpen,
  onClose,
  candles,
  activeScript,
  onChangeActiveScript,
  onApplyToChart,
  onRemoveFromChart,
  savedScripts,
  onSaveScriptList,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('editor');
  const [panelHeight, setPanelHeight] = useState<'normal' | 'expanded' | 'fullscreen'>('normal');
  const [showTemplateDropdown, setShowTemplateDropdown] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowTemplateDropdown(false);
      }
    };
    if (showTemplateDropdown) document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, [showTemplateDropdown]);

  // Flash status message
  const showFlash = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  // Run script
  const handleRunScript = () => {
    const result = executePythonIndicator(activeScript.code, candles, activeScript.overlay);
    const updated: CustomPythonIndicator = {
      ...activeScript,
      plots: result.plots,
      overlay: result.overlay,
      error: result.error,
      logs: result.logs,
      lastExecutedAt: Date.now(),
      executionTimeMs: result.executionTimeMs,
      enabled: result.success ? true : activeScript.enabled,
    };

    onChangeActiveScript(updated);
    if (result.success) {
      onApplyToChart(updated);
      showFlash(`Applied: ${result.plots.length} plot(s) generated in ${result.executionTimeMs}ms`);
      if (activeTab === 'console' && !result.error) {
        // stay
      }
    } else {
      setActiveTab('console');
      showFlash('Execution failed. See Console logs.');
    }
  };

  // Load a template
  const handleLoadTemplate = (template: PythonTemplate) => {
    const updated: CustomPythonIndicator = {
      ...activeScript,
      name: template.name,
      description: template.description,
      overlay: template.overlay,
      code: template.code,
      error: null,
      logs: [`Loaded template: ${template.name}`],
    };
    onChangeActiveScript(updated);
    setShowTemplateDropdown(false);
    showFlash(`Loaded "${template.name}" template`);
  };

  // Save current script to library
  const handleSaveToLibrary = () => {
    const exists = savedScripts.some((s) => s.id === activeScript.id);
    let updatedList: CustomPythonIndicator[];
    if (exists) {
      updatedList = savedScripts.map((s) => (s.id === activeScript.id ? activeScript : s));
    } else {
      updatedList = [...savedScripts, activeScript];
    }
    onSaveScriptList(updatedList);
    showFlash(`Saved "${activeScript.name}" to library`);
  };

  // Create new blank script
  const handleNewScript = () => {
    const newScript: CustomPythonIndicator = {
      id: `py_script_${Date.now()}`,
      name: 'Custom Indicator',
      description: 'My custom technical indicator',
      overlay: true,
      enabled: false,
      code: `# Custom Python Indicator\n# Access open, high, low, close, volume\n\nfast_ema = ema(close, 9)\nplot(fast_ema, title="EMA (9)", color="#38bdf8", width=2)\n`,
      plots: [],
      logs: ['New script created'],
      error: null,
    };
    onChangeActiveScript(newScript);
    showFlash('Created new script');
  };

  // Handle Tab key in code textarea (insert 4 spaces)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const val = ta.value;
      const newVal = val.substring(0, start) + '    ' + val.substring(end);
      onChangeActiveScript({ ...activeScript, code: newVal });
      setTimeout(() => {
        ta.selectionStart = ta.selectionEnd = start + 4;
      }, 0);
    }
  };

  // Update plot visual color or line width directly
  const handleUpdatePlotColor = (plotIndex: number, newColor: string) => {
    const updatedPlots = [...activeScript.plots];
    if (updatedPlots[plotIndex]) {
      updatedPlots[plotIndex] = { ...updatedPlots[plotIndex], color: newColor };
      const updated = { ...activeScript, plots: updatedPlots };
      onChangeActiveScript(updated);
      onApplyToChart(updated);
    }
  };

  const handleUpdatePlotWidth = (plotIndex: number, newWidth: number) => {
    const updatedPlots = [...activeScript.plots];
    if (updatedPlots[plotIndex]) {
      updatedPlots[plotIndex] = { ...updatedPlots[plotIndex], lineWidth: newWidth };
      const updated = { ...activeScript, plots: updatedPlots };
      onChangeActiveScript(updated);
      onApplyToChart(updated);
    }
  };

  if (!isOpen) return null;

  // Compute height class
  const heightClass =
    panelHeight === 'fullscreen'
      ? 'h-[85vh]'
      : panelHeight === 'expanded'
      ? 'h-[480px]'
      : 'h-[320px]';

  const lineCount = activeScript.code.split('\n').length;

  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-40 bg-[#090d16] border-t border-slate-800 shadow-2xl flex flex-col transition-all duration-200 ${heightClass}`}
    >
      {/* Top Header Bar */}
      <div className="h-10 bg-[#0c1220] border-b border-slate-800/90 px-3 flex items-center justify-between text-xs select-none shrink-0">
        {/* Left: Indicator Title & Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-blue-600/10 text-blue-400 font-semibold border border-blue-500/20 shrink-0">
            <Code className="w-3.5 h-3.5 text-blue-400" />
            <span>Python Script</span>
          </div>

          <input
            type="text"
            value={activeScript.name}
            onChange={(e) => onChangeActiveScript({ ...activeScript, name: e.target.value })}
            className="bg-slate-900 border border-slate-700/60 rounded px-2 py-0.5 text-xs text-slate-200 font-medium focus:outline-none focus:border-blue-500 w-44"
            title="Rename script"
          />

          {/* Overlay vs Oscillator Sub-pane toggle */}
          <button
            onClick={() => {
              const newOverlay = !activeScript.overlay;
              onChangeActiveScript({ ...activeScript, overlay: newOverlay });
            }}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-colors flex items-center gap-1 shrink-0 ${
              activeScript.overlay
                ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-300'
                : 'bg-purple-500/15 border-purple-500/30 text-purple-300'
            }`}
            title="Toggle between Price Overlay (Pane 0) and Separate Oscillator Pane"
          >
            <Layers className="w-3 h-3" />
            <span>{activeScript.overlay ? 'Overlay on Price' : 'Oscillator Pane'}</span>
          </button>

          <div className="w-px h-4 bg-slate-800 mx-1 shrink-0" />

          {/* Tab Navigation */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              onClick={() => setActiveTab('editor')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                activeTab === 'editor'
                  ? 'bg-slate-800 text-blue-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Editor</span>
            </button>
            <button
              onClick={() => setActiveTab('console')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium relative ${
                activeTab === 'console'
                  ? 'bg-slate-800 text-blue-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Console</span>
              {activeScript.error && (
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('styles')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                activeTab === 'styles'
                  ? 'bg-slate-800 text-blue-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Palette className="w-3.5 h-3.5" />
              <span>Plots & Styles ({activeScript.plots.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('library')}
              className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                activeTab === 'library'
                  ? 'bg-slate-800 text-blue-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <FolderOpen className="w-3.5 h-3.5" />
              <span>Library ({savedScripts.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('docs')}
              className={`px-2 py-1 rounded transition-colors flex items-center gap-1 font-medium ${
                activeTab === 'docs'
                  ? 'bg-slate-800 text-blue-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
              title="API Reference & Syntax Help"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Docs</span>
            </button>
          </div>
        </div>

        {/* Right: Actions (Run, Templates, Save, Expand, Close) */}
        <div className="flex items-center gap-2 shrink-0">
          {statusMessage && (
            <span className="text-[11px] text-emerald-400 font-medium px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 hidden md:inline animate-fade-in">
              {statusMessage}
            </span>
          )}

          {/* Templates Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setShowTemplateDropdown(!showTemplateDropdown)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium transition-colors"
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Templates</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showTemplateDropdown && (
              <div className="absolute right-0 bottom-full mb-1 bg-[#0f172a] border border-slate-800 rounded-xl shadow-2xl p-2 z-50 w-72 text-xs max-h-72 overflow-y-auto">
                <div className="text-[10px] uppercase font-bold text-slate-500 px-2 py-1 border-b border-slate-800">
                  Prebuilt Indicator Templates
                </div>
                <div className="py-1 space-y-1">
                  {PYTHON_INDICATOR_TEMPLATES.map((tmpl) => (
                    <button
                      key={tmpl.id}
                      onClick={() => handleLoadTemplate(tmpl)}
                      className="w-full text-left px-2.5 py-1.5 rounded hover:bg-slate-800 transition-colors group flex flex-col"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-200 group-hover:text-blue-400">
                          {tmpl.name}
                        </span>
                        <span
                          className={`text-[9px] px-1 rounded uppercase font-semibold ${
                            tmpl.overlay
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-purple-500/20 text-purple-400'
                          }`}
                        >
                          {tmpl.overlay ? 'Overlay' : 'Pane'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                        {tmpl.description}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Save Script */}
          <button
            onClick={handleSaveToLibrary}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-medium transition-colors"
            title="Save script to local library"
          >
            <Save className="w-3 h-3 text-slate-300" />
            <span>Save</span>
          </button>

          {/* Run & Apply Button */}
          <button
            onClick={handleRunScript}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold transition-all shadow-md shadow-emerald-500/20"
            title="Compile and apply Python indicator onto chart"
          >
            <Play className="w-3 h-3 fill-current" />
            <span>Run & Apply</span>
          </button>

          <div className="w-px h-4 bg-slate-800 mx-0.5" />

          {/* Resize / Maximize */}
          <button
            onClick={() => {
              if (panelHeight === 'normal') setPanelHeight('expanded');
              else if (panelHeight === 'expanded') setPanelHeight('fullscreen');
              else setPanelHeight('normal');
            }}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="Change panel height"
          >
            {panelHeight === 'fullscreen' ? (
              <Minimize2 className="w-3.5 h-3.5" />
            ) : (
              <Maximize2 className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Close Panel */}
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
            title="Close Python Editor panel"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Tab Body */}
      <div className="flex-1 overflow-hidden relative flex">
        {/* Tab 1: Code Editor */}
        {activeTab === 'editor' && (
          <div className="flex-1 flex overflow-hidden font-mono text-xs">
            {/* Line numbers gutter */}
            <div className="w-12 bg-[#060a12] text-slate-600 py-3 text-right pr-3 select-none border-r border-slate-800/80 shrink-0 font-tabular">
              {Array.from({ length: Math.max(lineCount, 12) }).map((_, i) => (
                <div key={i} className="leading-5">
                  {i + 1}
                </div>
              ))}
            </div>

            {/* Code Textarea */}
            <textarea
              ref={textareaRef}
              value={activeScript.code}
              onChange={(e) => onChangeActiveScript({ ...activeScript, code: e.target.value })}
              onKeyDown={handleKeyDown}
              spellCheck={false}
              autoCapitalize="off"
              autoComplete="off"
              className="flex-1 bg-[#090d16] text-slate-100 p-3 leading-5 resize-none focus:outline-none font-mono selection:bg-blue-600/30 placeholder-slate-600 overflow-y-auto"
              placeholder="# Write your custom Python indicator here...
fast_ema = ema(close, 9)
plot(fast_ema, title='Fast EMA', color='#38bdf8', width=2)"
            />
          </div>
        )}

        {/* Tab 2: Console & Execution Output */}
        {activeTab === 'console' && (
          <div className="flex-1 bg-[#060a12] p-4 font-mono text-xs overflow-y-auto space-y-2">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-400">
              <span className="flex items-center gap-1.5 font-semibold text-slate-300">
                <Terminal className="w-4 h-4 text-emerald-400" />
                Script Execution Console
              </span>
              <div className="flex items-center gap-3">
                {activeScript.executionTimeMs !== undefined && (
                  <span className="text-[11px] text-slate-400">
                    Execution time: {activeScript.executionTimeMs}ms
                  </span>
                )}
                <button
                  onClick={() => onChangeActiveScript({ ...activeScript, logs: [], error: null })}
                  className="text-[11px] text-slate-400 hover:text-slate-200 hover:underline"
                >
                  Clear Console
                </button>
              </div>
            </div>

            {activeScript.error && (
              <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/60 text-red-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-red-200">Execution Error:</div>
                  <div className="mt-0.5 font-mono text-[11px]">{activeScript.error}</div>
                </div>
              </div>
            )}

            {activeScript.logs && activeScript.logs.length > 0 ? (
              <div className="space-y-1 text-slate-300">
                {activeScript.logs.map((log, idx) => (
                  <div
                    key={idx}
                    className={`leading-relaxed ${
                      log.startsWith('✕') || log.includes('Error')
                        ? 'text-red-400 font-semibold'
                        : log.startsWith('✓')
                        ? 'text-emerald-400'
                        : 'text-slate-300'
                    }`}
                  >
                    {log}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-slate-500 italic py-4">
                No logs recorded yet. Click "Run & Apply" to compile and run your script.
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Plot Styles & Customization */}
        {activeTab === 'styles' && (
          <div className="flex-1 bg-[#090d16] p-4 text-xs overflow-y-auto">
            <div className="max-w-2xl">
              <h3 className="text-sm font-semibold text-slate-200 mb-1">
                Visual Plot Styles & Settings
              </h3>
              <p className="text-slate-400 text-[11px] mb-4">
                Customize colors, line thickness, and rendering styles for each plot generated by this
                script.
              </p>

              {activeScript.plots.length === 0 ? (
                <div className="p-6 rounded-xl border border-dashed border-slate-800 text-center text-slate-500">
                  <p>No active plots yet.</p>
                  <p className="text-[11px] mt-1 text-slate-600">
                    Run your Python script using the "Run & Apply" button to generate indicator plots.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {activeScript.plots.map((plot, idx) => (
                    <div
                      key={plot.id || idx}
                      className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/60 flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3">
                        <input
                          type="color"
                          value={plot.color}
                          onChange={(e) => handleUpdatePlotColor(idx, e.target.value)}
                          className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                          title="Change plot color"
                        />
                        <div>
                          <div className="font-semibold text-slate-200">{plot.name}</div>
                          <div className="text-[10px] text-slate-400">
                            Type: {plot.type} | Data Points: {plot.data.length}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-400 text-[11px]">Line Width:</span>
                          <select
                            value={plot.lineWidth || 2}
                            onChange={(e) => handleUpdatePlotWidth(idx, Number(e.target.value))}
                            className="bg-slate-800 border border-slate-700 rounded px-2 py-1 text-slate-200 text-xs focus:outline-none"
                          >
                            <option value={1}>1px</option>
                            <option value={2}>2px</option>
                            <option value={3}>3px</option>
                            <option value={4}>4px</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 4: Library & Saved Scripts */}
        {activeTab === 'library' && (
          <div className="flex-1 bg-[#090d16] p-4 text-xs overflow-y-auto">
            <div className="max-w-3xl">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Saved Python Scripts</h3>
                  <p className="text-slate-400 text-[11px]">
                    Manage, load, or duplicate your custom indicator scripts
                  </p>
                </div>
                <button
                  onClick={handleNewScript}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold transition-colors flex items-center gap-1.5"
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>Create New Script</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {savedScripts.map((script) => (
                  <div
                    key={script.id}
                    className={`p-3.5 rounded-xl border transition-all ${
                      script.id === activeScript.id
                        ? 'bg-blue-950/20 border-blue-500/50 shadow-md shadow-blue-500/10'
                        : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-semibold text-slate-100 text-sm block">
                          {script.name}
                        </span>
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          {script.description || 'Custom indicator'}
                        </span>
                      </div>
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase ${
                          script.overlay
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-purple-500/20 text-purple-400'
                        }`}
                      >
                        {script.overlay ? 'Overlay' : 'Pane'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-800/80">
                      <button
                        onClick={() => {
                          onChangeActiveScript(script);
                          setActiveTab('editor');
                          showFlash(`Loaded "${script.name}"`);
                        }}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
                      >
                        Load to Editor
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            if (script.enabled) {
                              onRemoveFromChart(script.id);
                            } else {
                              onApplyToChart(script);
                            }
                          }}
                          className={`px-2 py-1 rounded font-medium transition-colors ${
                            script.enabled
                              ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                          }`}
                        >
                          {script.enabled ? 'On Chart' : 'Add to Chart'}
                        </button>
                        <button
                          onClick={() => {
                            const filtered = savedScripts.filter((s) => s.id !== script.id);
                            onSaveScriptList(filtered);
                            onRemoveFromChart(script.id);
                            showFlash('Deleted script');
                          }}
                          className="p-1 rounded text-slate-500 hover:text-red-400 transition-colors"
                          title="Delete script"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 5: Docs & API Reference */}
        {activeTab === 'docs' && (
          <div className="flex-1 bg-[#060a12] p-5 text-xs overflow-y-auto space-y-4">
            <div className="max-w-3xl">
              <h3 className="text-sm font-semibold text-slate-100 mb-1">
                TradePulse Python Script API Reference
              </h3>
              <p className="text-slate-400 text-[11px] mb-4">
                Write standard Python calculations on candlestick arrays. High performance in-browser
                execution.
              </p>

              <div className="space-y-4">
                {/* 1. Market Data Arrays */}
                <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/40">
                  <div className="font-semibold text-blue-400 mb-1.5">1. Market OHLCV Arrays</div>
                  <p className="text-slate-300 mb-2">
                    Direct access to time series lists of numbers across all bars:
                  </p>
                  <code className="block bg-[#090d16] p-2.5 rounded font-mono text-[11px] text-slate-200">
                    open, high, low, close, volume, time, bar_index, n, price
                  </code>
                  <p className="text-slate-400 text-[10px] mt-1.5">
                    Supports negative indexing like <code className="text-slate-300">close[-1]</code> (most
                    recent close) and list comprehensions.
                  </p>
                </div>

                {/* 2. Technical Math Built-ins */}
                <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/40">
                  <div className="font-semibold text-blue-400 mb-1.5">2. Built-in Technical Functions</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 font-mono text-[11px]">
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      sma(source, period=20)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      ema(source, period=20)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      wma(source, period=20)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      rsi(source, period=14)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      std(source, period=20)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      highest(source, period=20)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      lowest(source, period=20)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      macd(source, 12, 26, 9)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      bollinger(source, 20, 2)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      atr(high, low, close, 14)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      vwap(high, low, close, volume)
                    </div>
                    <div className="p-2 rounded bg-[#090d16] text-slate-300">
                      supertrend(high, low, close, 10, 3)
                    </div>
                  </div>
                </div>

                {/* 3. Output Plotting API */}
                <div className="p-3.5 rounded-lg border border-slate-800 bg-slate-900/40">
                  <div className="font-semibold text-blue-400 mb-1.5">3. Plotting & Console Output</div>
                  <pre className="bg-[#090d16] p-2.5 rounded font-mono text-[11px] text-slate-200 overflow-x-auto">
{`# Line plot:
plot(series, title="Fast EMA", color="#38bdf8", width=2)

# Histogram plot:
plot_hist(series, title="MACD Hist", color="#22c55e")

# Static level line (e.g. for RSI 70/30 or MACD 0):
plot_level(70, title="Overbought", color="#ef4444")
plot_level(30, title="Oversold", color="#22c55e")

# Print to console tab:
print(f"Latest Close: {close[-1]:.2f}")`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Sleek Bottom Status Bar */}
      <div className="h-6 bg-[#060a12] border-t border-slate-800/80 px-3 flex items-center justify-between text-[11px] text-slate-500 font-mono select-none shrink-0">
        <div className="flex items-center gap-3">
          <span>Python 3.12 (TradePulse Engine)</span>
          <span>•</span>
          <span>Bars: {candles.length}</span>
          <span>•</span>
          <span>Lines: {lineCount}</span>
        </div>
        <div className="flex items-center gap-3">
          {activeScript.enabled && (
            <span className="flex items-center gap-1 text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Active on Chart
            </span>
          )}
          <span>{activeScript.overlay ? 'Price Overlay' : 'Oscillator Pane'}</span>
        </div>
      </div>
    </div>
  );
};

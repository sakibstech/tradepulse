import React, { useEffect, useRef, useState } from 'react';
import {
  createChart,
  ColorType,
  IChartApi,
  ISeriesApi,
  CandlestickSeries,
  LineSeries,
  AreaSeries,
  BarSeries,
  HistogramSeries,
  UTCTimestamp,
  IPriceLine,
} from 'lightweight-charts';
import {
  Candle,
  ChartSettings,
  ChartType,
  CustomPythonIndicator,
  DrawingItem,
  DrawingToolType,
  IndicatorConfig,
  PriceAlert,
  Timeframe,
} from '../types/chart';
import { calculateHeikinAshi } from '../services/indicatorCalculator';
import { DrawingCanvas } from './DrawingCanvas';

interface ChartContainerProps {
  data: Candle[];
  symbol: string;
  assetName: string;
  timeframe: Timeframe;
  priceDecimals: number;
  chartType: ChartType;
  indicatorConfig: IndicatorConfig;
  customPythonIndicators?: CustomPythonIndicator[];
  chartSettings: ChartSettings;
  activeAlerts: PriceAlert[];
  isReplayMode: boolean;
  replayIndex: number;
  isSelectingCutPoint: boolean;
  onSelectCutIndex: (index: number) => void;
  activeDrawingTool: DrawingToolType;
  drawings: DrawingItem[];
  onAddDrawing: (drawing: DrawingItem) => void;
  onUpdateDrawing: (drawing: DrawingItem) => void;
  onDeleteDrawing: (id: string) => void;
  drawingColor: string;
  drawingLineWidth: number;
  onHoverCandleChange?: (candle: Candle | null) => void;
}

export const ChartContainer: React.FC<ChartContainerProps> = ({
  data,
  symbol,
  assetName,
  timeframe,
  priceDecimals,
  chartType,
  indicatorConfig,
  customPythonIndicators = [],
  chartSettings,
  activeAlerts,
  isReplayMode,
  replayIndex,
  isSelectingCutPoint,
  onSelectCutIndex,
  activeDrawingTool,
  drawings,
  onAddDrawing,
  onUpdateDrawing,
  onDeleteDrawing,
  drawingColor,
  drawingLineWidth,
  onHoverCandleChange,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartInstanceRef = useRef<IChartApi | null>(null);
  const mainSeriesRef = useRef<ISeriesApi<any> | null>(null);
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);

  // Price lines for active alerts
  const alertPriceLinesRef = useRef<IPriceLine[]>([]);

  // Indicator series refs
  const smaSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const emaSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const bbUpperSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const bbMiddleSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const bbLowerSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const rsiSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const macdSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const macdSignalSeriesRef = useRef<ISeriesApi<'Line'> | null>(null);
  const macdHistSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);

  // Custom Python Indicator dynamic series map: plotKey -> ISeriesApi
  const customSeriesMapRef = useRef<Map<string, ISeriesApi<any>>>(new Map());

  const [hoveredCandle, setHoveredCandle] = useState<Candle | null>(null);
  const [chartReady, setChartReady] = useState(false);

  // Compute currently visible data slice based on Bar Replay mode
  const visibleData = isReplayMode ? data.slice(0, Math.min(replayIndex, data.length)) : data;
  const currentLastCandle = visibleData.length > 0 ? visibleData[visibleData.length - 1] : null;

  // Initialize Lightweight Chart instance
  useEffect(() => {
    if (!containerRef.current) return;

    const chart = createChart(containerRef.current, {
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      layout: {
        background: { type: ColorType.Solid, color: chartSettings.backgroundColor },
        textColor: '#94a3b8',
        fontSize: 11,
        fontFamily: "'JetBrains Mono', 'Plus Jakarta Sans', monospace",
      },
      grid: {
        vertLines: {
          visible: chartSettings.showGridVert,
          color: chartSettings.gridColor,
        },
        horzLines: {
          visible: chartSettings.showGridHorz,
          color: chartSettings.gridColor,
        },
      },
      crosshair: {
        vertLine: {
          color: '#64748b',
          width: 1,
          style: 3,
          labelBackgroundColor: '#1e293b',
        },
        horzLine: {
          color: '#64748b',
          width: 1,
          style: 3,
          labelBackgroundColor: '#1e293b',
        },
      },
      timeScale: {
        borderColor: '#1e293b',
        timeVisible: true,
        secondsVisible: false,
      },
      rightPriceScale: {
        borderColor: '#1e293b',
        autoScale: true,
      },
    });

    chartInstanceRef.current = chart;

    // Handle Resize
    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0 || !chartInstanceRef.current) return;
      const { width, height } = entries[0].contentRect;
      chartInstanceRef.current.applyOptions({ width, height });
    });
    resizeObserver.observe(containerRef.current);

    setChartReady(true);

    return () => {
      resizeObserver.disconnect();
      chart.remove();
      chartInstanceRef.current = null;
    };
  }, []);

  // Update Chart Layout & Appearance when chartSettings change
  useEffect(() => {
    const chart = chartInstanceRef.current;
    if (!chart || !chartReady) return;

    chart.applyOptions({
      layout: {
        background: { type: ColorType.Solid, color: chartSettings.backgroundColor },
      },
      grid: {
        vertLines: {
          visible: chartSettings.showGridVert,
          color: chartSettings.gridColor,
        },
        horzLines: {
          visible: chartSettings.showGridHorz,
          color: chartSettings.gridColor,
        },
      },
    });
  }, [chartReady, chartSettings]);

  // Update Main Price Series (Candlestick / Line / Area / Bar / Heikin-Ashi)
  useEffect(() => {
    const chart = chartInstanceRef.current;
    if (!chart || !chartReady) return;

    // Remove existing main series if any
    if (mainSeriesRef.current) {
      try {
        chart.removeSeries(mainSeriesRef.current);
      } catch {
        // ignore
      }
      mainSeriesRef.current = null;
      candlestickSeriesRef.current = null;
    }

    const pricePrecision = priceDecimals;
    const priceFormat = {
      type: 'price' as const,
      precision: pricePrecision,
      minMove: 1 / Math.pow(10, pricePrecision),
    };

    if (chartType === 'candlestick') {
      const s = chart.addSeries(CandlestickSeries, {
        upColor: chartSettings.upColor,
        downColor: chartSettings.downColor,
        borderUpColor: chartSettings.candleBorder ? chartSettings.upColor : 'transparent',
        borderDownColor: chartSettings.candleBorder ? chartSettings.downColor : 'transparent',
        wickUpColor: chartSettings.upColor,
        wickDownColor: chartSettings.downColor,
        priceFormat,
      }, 0);
      mainSeriesRef.current = s;
      candlestickSeriesRef.current = s;
    } else if (chartType === 'heikin-ashi') {
      const s = chart.addSeries(CandlestickSeries, {
        upColor: chartSettings.upColor,
        downColor: chartSettings.downColor,
        borderUpColor: chartSettings.candleBorder ? chartSettings.upColor : 'transparent',
        borderDownColor: chartSettings.candleBorder ? chartSettings.downColor : 'transparent',
        wickUpColor: chartSettings.upColor,
        wickDownColor: chartSettings.downColor,
        priceFormat,
      }, 0);
      mainSeriesRef.current = s;
      candlestickSeriesRef.current = s;
    } else if (chartType === 'line') {
      const s = chart.addSeries(LineSeries, {
        color: '#38bdf8',
        lineWidth: 2,
        priceFormat,
      }, 0);
      mainSeriesRef.current = s;
    } else if (chartType === 'area') {
      const s = chart.addSeries(AreaSeries, {
        topColor: 'rgba(56, 189, 248, 0.4)',
        bottomColor: 'rgba(56, 189, 248, 0.01)',
        lineColor: '#38bdf8',
        lineWidth: 2,
        priceFormat,
      }, 0);
      mainSeriesRef.current = s;
    } else if (chartType === 'bar') {
      const s = chart.addSeries(BarSeries, {
        upColor: chartSettings.upColor,
        downColor: chartSettings.downColor,
        priceFormat,
      }, 0);
      mainSeriesRef.current = s;
    }

    // Subscribe to crosshair move for Legend inspection
    chart.subscribeCrosshairMove((param) => {
      if (!param.time || !param.seriesData || visibleData.length === 0) {
        setHoveredCandle(null);
        if (onHoverCandleChange) onHoverCandleChange(null);
        return;
      }
      const matchedCandle = visibleData.find((c) => c.time === (param.time as number));
      if (matchedCandle) {
        setHoveredCandle(matchedCandle);
        if (onHoverCandleChange) onHoverCandleChange(matchedCandle);
      }
    });

  }, [chartReady, chartType, priceDecimals, chartSettings.upColor, chartSettings.downColor, chartSettings.candleBorder]);

  // Render / Update Active Alert Lines on Main Series
  useEffect(() => {
    const series = mainSeriesRef.current;
    if (!series) return;

    // Clear previous alert lines
    alertPriceLinesRef.current.forEach((line) => {
      try {
        series.removePriceLine(line);
      } catch {
        // ignore
      }
    });
    alertPriceLinesRef.current = [];

    // Filter alerts for current symbol that are active (not triggered)
    const currentAssetAlerts = activeAlerts.filter(
      (a) => a.symbol === symbol && !a.triggered
    );

    currentAssetAlerts.forEach((alert) => {
      try {
        const line = series.createPriceLine({
          price: alert.targetPrice,
          color: '#f59e0b',
          lineWidth: 1,
          lineStyle: 2, // dashed
          axisLabelVisible: true,
          title: `🔔 Target: ${alert.targetPrice.toFixed(priceDecimals)}`,
        });
        alertPriceLinesRef.current.push(line);
      } catch {
        // ignore
      }
    });
  }, [activeAlerts, symbol, priceDecimals]);

  // Handle Cut Bar (Jump to bar) click event
  useEffect(() => {
    const chart = chartInstanceRef.current;
    if (!chart) return;

    const handleChartClick = (param: any) => {
      if (!isSelectingCutPoint || !param.time) return;
      const clickedTime = param.time as number;
      const foundIdx = data.findIndex((c) => c.time === clickedTime);
      if (foundIdx !== -1) {
        onSelectCutIndex(foundIdx + 1);
      }
    };

    chart.subscribeClick(handleChartClick);
    return () => chart.unsubscribeClick(handleChartClick);
  }, [isSelectingCutPoint, data, onSelectCutIndex]);

  // Feed / Update Data to Price & Indicator Series (Volume indicator is deleted)
  useEffect(() => {
    if (!chartInstanceRef.current || !mainSeriesRef.current || visibleData.length === 0) return;

    // Deduplicate and ensure ascending timestamps
    const cleanCandles: Candle[] = [];
    const seenTimes = new Set<number>();
    for (const c of visibleData) {
      if (!seenTimes.has(c.time)) {
        seenTimes.add(c.time);
        cleanCandles.push(c);
      }
    }
    cleanCandles.sort((a, b) => a.time - b.time);

    // 1. Main Series Data
    if (chartType === 'candlestick') {
      candlestickSeriesRef.current?.setData(
        cleanCandles.map((c) => ({
          time: c.time as UTCTimestamp,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
        }))
      );
    } else if (chartType === 'heikin-ashi') {
      const haCandles = calculateHeikinAshi(cleanCandles);
      candlestickSeriesRef.current?.setData(
        haCandles.map((c) => ({
          time: c.time as UTCTimestamp,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
        }))
      );
    } else if (chartType === 'bar') {
      (mainSeriesRef.current as any).setData(
        cleanCandles.map((c) => ({
          time: c.time as UTCTimestamp,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
        }))
      );
    } else {
      // Line or Area
      (mainSeriesRef.current as any).setData(
        cleanCandles.map((c) => ({
          time: c.time as UTCTimestamp,
          value: c.close,
        }))
      );
    }

    // 2. Technical Indicators
    const chart = chartInstanceRef.current;

    // SMA Overlay
    if (indicatorConfig.sma.enabled) {
      if (!smaSeriesRef.current) {
        smaSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.sma.color,
          lineWidth: indicatorConfig.sma.lineWidth as any,
          priceScaleId: 'right',
        }, 0);
      } else {
        smaSeriesRef.current.applyOptions({
          color: indicatorConfig.sma.color,
          lineWidth: indicatorConfig.sma.lineWidth as any,
        });
      }
      const smaData = cleanCandles
        .filter((c) => c.sma20 !== null && c.sma20 !== undefined)
        .map((c) => ({
          time: c.time as UTCTimestamp,
          value: c.sma20 as number,
        }));
      smaSeriesRef.current.setData(smaData);
    } else if (smaSeriesRef.current) {
      chart.removeSeries(smaSeriesRef.current);
      smaSeriesRef.current = null;
    }

    // EMA Overlay
    if (indicatorConfig.ema.enabled) {
      if (!emaSeriesRef.current) {
        emaSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.ema.color,
          lineWidth: indicatorConfig.ema.lineWidth as any,
          priceScaleId: 'right',
        }, 0);
      } else {
        emaSeriesRef.current.applyOptions({
          color: indicatorConfig.ema.color,
          lineWidth: indicatorConfig.ema.lineWidth as any,
        });
      }
      const emaData = cleanCandles
        .filter((c) => c.ema50 !== null && c.ema50 !== undefined)
        .map((c) => ({
          time: c.time as UTCTimestamp,
          value: c.ema50 as number,
        }));
      emaSeriesRef.current.setData(emaData);
    } else if (emaSeriesRef.current) {
      chart.removeSeries(emaSeriesRef.current);
      emaSeriesRef.current = null;
    }

    // Bollinger Bands Overlay
    if (indicatorConfig.bb.enabled) {
      if (!bbUpperSeriesRef.current) {
        bbUpperSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.bb.upperColor,
          lineWidth: 1,
          lineStyle: 2,
        }, 0);
        bbMiddleSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.bb.middleColor,
          lineWidth: 1,
        }, 0);
        bbLowerSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.bb.lowerColor,
          lineWidth: 1,
          lineStyle: 2,
        }, 0);
      }
      bbUpperSeriesRef.current.setData(
        cleanCandles
          .filter((c) => c.bbUpper !== null && c.bbUpper !== undefined)
          .map((c) => ({ time: c.time as UTCTimestamp, value: c.bbUpper as number }))
      );
      bbMiddleSeriesRef.current?.setData(
        cleanCandles
          .filter((c) => c.bbMiddle !== null && c.bbMiddle !== undefined)
          .map((c) => ({ time: c.time as UTCTimestamp, value: c.bbMiddle as number }))
      );
      bbLowerSeriesRef.current?.setData(
        cleanCandles
          .filter((c) => c.bbLower !== null && c.bbLower !== undefined)
          .map((c) => ({ time: c.time as UTCTimestamp, value: c.bbLower as number }))
      );
    } else if (bbUpperSeriesRef.current) {
      chart.removeSeries(bbUpperSeriesRef.current);
      if (bbMiddleSeriesRef.current) chart.removeSeries(bbMiddleSeriesRef.current);
      if (bbLowerSeriesRef.current) chart.removeSeries(bbLowerSeriesRef.current);
      bbUpperSeriesRef.current = null;
      bbMiddleSeriesRef.current = null;
      bbLowerSeriesRef.current = null;
    }

    // RSI Oscillator (Sub-Pane 1)
    if (indicatorConfig.rsi.enabled) {
      if (!rsiSeriesRef.current) {
        rsiSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.rsi.color,
          lineWidth: 2,
          priceFormat: { type: 'price', precision: 1, minMove: 0.1 },
        }, 1);
        rsiSeriesRef.current.createPriceLine({
          price: indicatorConfig.rsi.overbought,
          color: '#f87171',
          lineWidth: 1,
          lineStyle: 2,
          title: 'OB 70',
        });
        rsiSeriesRef.current.createPriceLine({
          price: indicatorConfig.rsi.oversold,
          color: '#4ade80',
          lineWidth: 1,
          lineStyle: 2,
          title: 'OS 30',
        });
      }
      const rsiData = cleanCandles
        .filter((c) => c.rsi !== null && c.rsi !== undefined)
        .map((c) => ({
          time: c.time as UTCTimestamp,
          value: c.rsi as number,
        }));
      rsiSeriesRef.current.setData(rsiData);
    } else if (rsiSeriesRef.current) {
      chart.removeSeries(rsiSeriesRef.current);
      rsiSeriesRef.current = null;
    }

    // MACD Oscillator (Sub-Pane 2 or Pane 1)
    if (indicatorConfig.macd.enabled) {
      const macdPane = indicatorConfig.rsi.enabled ? 2 : 1;
      if (!macdSeriesRef.current) {
        macdHistSeriesRef.current = chart.addSeries(HistogramSeries, {
          priceFormat: { type: 'price', precision: 2, minMove: 0.01 },
        }, macdPane);
        macdSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.macd.macdColor,
          lineWidth: 1.5 as any,
        }, macdPane);
        macdSignalSeriesRef.current = chart.addSeries(LineSeries, {
          color: indicatorConfig.macd.signalColor,
          lineWidth: 1.5 as any,
        }, macdPane);
      }
      macdSeriesRef.current?.setData(
        cleanCandles
          .filter((c) => c.macd !== null && c.macd !== undefined)
          .map((c) => ({ time: c.time as UTCTimestamp, value: c.macd as number }))
      );
      macdSignalSeriesRef.current?.setData(
        cleanCandles
          .filter((c) => c.macdSignal !== null && c.macdSignal !== undefined)
          .map((c) => ({ time: c.time as UTCTimestamp, value: c.macdSignal as number }))
      );
      macdHistSeriesRef.current?.setData(
        cleanCandles
          .filter((c) => c.macdHist !== null && c.macdHist !== undefined)
          .map((c) => ({
            time: c.time as UTCTimestamp,
            value: c.macdHist as number,
            color:
              (c.macdHist as number) >= 0
                ? indicatorConfig.macd.histUpColor
                : indicatorConfig.macd.histDownColor,
          }))
      );
    } else if (macdSeriesRef.current) {
      chart.removeSeries(macdSeriesRef.current);
      if (macdSignalSeriesRef.current) chart.removeSeries(macdSignalSeriesRef.current);
      if (macdHistSeriesRef.current) chart.removeSeries(macdHistSeriesRef.current);
      macdSeriesRef.current = null;
      macdSignalSeriesRef.current = null;
      macdHistSeriesRef.current = null;
    }

    // 3. Custom Python Indicators Dynamic Series Rendering
    const activePlotKeySet = new Set<string>();
    let oscillatorPaneCounter = 1;
    if (indicatorConfig.rsi.enabled) oscillatorPaneCounter++;
    if (indicatorConfig.macd.enabled) oscillatorPaneCounter++;

    customPythonIndicators.forEach((ind) => {
      if (!ind.enabled || !ind.plots || ind.plots.length === 0) return;
      const targetPane = ind.overlay ? 0 : oscillatorPaneCounter++;

      ind.plots.forEach((plot, pIdx) => {
        const plotKey = `${ind.id}_plot_${pIdx}_${plot.name}`;
        activePlotKeySet.add(plotKey);

        let series = customSeriesMapRef.current.get(plotKey);
        if (!series) {
          if (plot.type === 'histogram') {
            series = chart.addSeries(HistogramSeries, {
              priceFormat: { type: 'price', precision: 2, minMove: 0.01 },
              color: plot.color,
            }, targetPane);
          } else {
            series = chart.addSeries(LineSeries, {
              color: plot.color,
              lineWidth: (plot.lineWidth || 2) as any,
              lineStyle: plot.levelValue !== undefined ? 2 : 0,
              priceFormat: {
                type: 'price',
                precision: ind.overlay ? priceDecimals : 2,
                minMove: ind.overlay ? 1 / Math.pow(10, priceDecimals) : 0.01,
              },
            }, targetPane);
          }
          customSeriesMapRef.current.set(plotKey, series);
        } else {
          series.applyOptions({
            color: plot.color,
            lineWidth: (plot.lineWidth || 2) as any,
          });
        }

        // Map plot data to visible candles
        const visibleTimeSet = new Set(cleanCandles.map((c) => c.time));
        const plotPoints = plot.data
          .filter((pt) => visibleTimeSet.has(pt.time))
          .map((pt) => ({
            time: pt.time as UTCTimestamp,
            value: pt.value,
            ...(plot.type === 'histogram' ? { color: plot.color } : {}),
          }));
        series.setData(plotPoints);
      });
    });

    // Cleanup any removed or disabled custom plots
    customSeriesMapRef.current.forEach((series, key) => {
      if (!activePlotKeySet.has(key)) {
        try {
          chart.removeSeries(series);
        } catch {
          // ignore
        }
        customSeriesMapRef.current.delete(key);
      }
    });

  }, [visibleData, chartType, indicatorConfig, customPythonIndicators, priceDecimals]);

  // Active Candle to display in Legend (hovered or latest)
  const displayCandle = hoveredCandle || currentLastCandle;
  const isUpCandle = displayCandle ? displayCandle.close >= displayCandle.open : true;

  return (
    <div
      className="relative w-full h-full flex-1 overflow-hidden select-none"
      style={{ backgroundColor: chartSettings.backgroundColor }}
    >
      {/* Background Symbol Watermark (if enabled in chart settings) */}
      {chartSettings.watermark && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0 overflow-hidden">
          <span className="text-[12vw] font-black tracking-tighter text-slate-800/10 uppercase select-none font-tabular">
            {symbol.replace('=X', '').replace('-USD', '')}
          </span>
        </div>
      )}

      {/* Chart Canvas Container */}
      <div
        ref={containerRef}
        className={`w-full h-full ${isSelectingCutPoint ? 'cursor-crosshair' : ''}`}
      />

      {/* Interactive Drawing Canvas Layer */}
      <DrawingCanvas
        chart={chartInstanceRef.current}
        series={candlestickSeriesRef.current || mainSeriesRef.current}
        activeTool={activeDrawingTool}
        drawings={drawings}
        candles={data}
        onAddDrawing={onAddDrawing}
        onUpdateDrawing={onUpdateDrawing}
        onDeleteDrawing={onDeleteDrawing}
        selectedColor={drawingColor}
        selectedLineWidth={drawingLineWidth}
        priceDecimals={priceDecimals}
      />

      {/* Institutional TradingView Header Legend (Volume removed) */}
      {displayCandle && (
        <div className="absolute top-2 left-3 z-20 pointer-events-none flex flex-col gap-0.5 text-xs text-slate-300 font-tabular backdrop-blur-xs bg-[#0b0f19]/75 px-2.5 py-1.5 rounded-md border border-slate-800/60 shadow-lg max-w-[85vw] overflow-hidden">
          {/* Symbol, Name, Timeframe */}
          <div className="flex items-center gap-2 font-semibold">
            <span className="text-white text-xs tracking-wide">{symbol}</span>
            <span className="text-slate-400 font-normal text-[11px]">{assetName}</span>
            <span className="px-1.5 py-0.2 bg-slate-800 text-blue-400 rounded text-[10px]">
              {timeframe}
            </span>
          </div>

          {/* OHLC metrics (Volume cleanly removed) */}
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span>
              O <b className={isUpCandle ? 'text-emerald-400' : 'text-red-400'}>{displayCandle.open.toFixed(priceDecimals)}</b>
            </span>
            <span>
              H <b className={isUpCandle ? 'text-emerald-400' : 'text-red-400'}>{displayCandle.high.toFixed(priceDecimals)}</b>
            </span>
            <span>
              L <b className={isUpCandle ? 'text-emerald-400' : 'text-red-400'}>{displayCandle.low.toFixed(priceDecimals)}</b>
            </span>
            <span>
              C <b className={isUpCandle ? 'text-emerald-400' : 'text-red-400'}>{displayCandle.close.toFixed(priceDecimals)}</b>
            </span>
          </div>

          {/* Active Standard Indicators Legend */}
          <div className="flex items-center flex-wrap gap-2.5 text-[10px] text-slate-400 pt-0.5">
            {indicatorConfig.sma.enabled && displayCandle.sma20 && (
              <span style={{ color: indicatorConfig.sma.color }}>
                SMA({indicatorConfig.sma.period}): {displayCandle.sma20.toFixed(priceDecimals)}
              </span>
            )}
            {indicatorConfig.ema.enabled && displayCandle.ema50 && (
              <span style={{ color: indicatorConfig.ema.color }}>
                EMA({indicatorConfig.ema.period}): {displayCandle.ema50.toFixed(priceDecimals)}
              </span>
            )}
            {indicatorConfig.bb.enabled && displayCandle.bbUpper && displayCandle.bbLower && (
              <span style={{ color: indicatorConfig.bb.upperColor }}>
                BB({indicatorConfig.bb.period}): [{displayCandle.bbUpper.toFixed(priceDecimals)}, {displayCandle.bbLower.toFixed(priceDecimals)}]
              </span>
            )}
            {indicatorConfig.rsi.enabled && displayCandle.rsi && (
              <span style={{ color: indicatorConfig.rsi.color }}>
                RSI({indicatorConfig.rsi.period}): {displayCandle.rsi.toFixed(1)}
              </span>
            )}
            {indicatorConfig.macd.enabled && displayCandle.macd && (
              <span style={{ color: indicatorConfig.macd.macdColor }}>
                MACD: {displayCandle.macd.toFixed(2)} (Sig: {displayCandle.macdSignal?.toFixed(2) || '0.00'})
              </span>
            )}

            {/* Custom Python Indicators in Legend */}
            {customPythonIndicators
              .filter((ind) => ind.enabled && ind.plots && ind.plots.length > 0)
              .map((ind) => (
                <div key={ind.id} className="flex items-center gap-1.5 border-l border-slate-700/60 pl-2">
                  <span className="text-slate-400 font-semibold">{ind.name}:</span>
                  {ind.plots.map((plot) => {
                    const pt = displayCandle ? plot.data.find((d) => d.time === displayCandle.time) : null;
                    return (
                      <span key={plot.id || plot.name} style={{ color: plot.color }} className="font-semibold">
                        {plot.name}: {pt !== undefined && pt !== null ? pt.value.toFixed(ind.overlay ? priceDecimals : 2) : '—'}
                      </span>
                    );
                  })}
                </div>
              ))}
          </div>
        </div>
      )}

    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  SlidersHorizontal,
  Maximize2,
  TrendingUp,
  TrendingDown,
  History,
  CandlestickChart,
  LineChart,
  AreaChart,
  BarChart2,
  Bookmark,
  Activity,
  Bell,
  Settings,
  ChevronDown,
  Gauge,
  Code,
} from 'lucide-react';
import { AssetInfo, ChartType, Timeframe } from '../types/chart';

interface HeaderNavProps {
  currentAsset: AssetInfo;
  currentPrice: number;
  priceChange: number;
  priceChangePercent: number;
  timeframe: Timeframe;
  onChangeTimeframe: (tf: Timeframe) => void;
  chartType: ChartType;
  onChangeChartType: (type: ChartType) => void;
  onOpenSymbolSearch: () => void;
  onOpenIndicators: () => void;
  activeIndicatorsCount: number;
  onTogglePythonEditor: () => void;
  isPythonEditorOpen: boolean;
  activePythonScriptsCount: number;
  isReplayMode: boolean;
  onToggleReplayMode: () => void;
  onToggleWatchlist: () => void;
  isWatchlistOpen: boolean;
  onOpenChartSettings: () => void;
  onOpenCreateAlert: () => void;
  activeAlertsCount: number;
  onOpenMarketAnalysis: () => void;
  onToggleFullscreen: () => void;
}

// Quick access top-bar favorite timeframes (all user-requested intervals)
const FAVORITE_TIMEFRAMES: Timeframe[] = [
  '1m', '3m', '5m', '15m', '30m', '45m',
  '1H', '4H',
  '1D', '1W', '1M', '3M', '6M', '1Y'
];

// All timeframes organized by category
const ALL_TIMEFRAMES: { label: string; items: Timeframe[] }[] = [
  { label: 'MINUTES', items: ['1m', '3m', '5m', '15m', '30m', '45m'] },
  { label: 'HOURS', items: ['1H', '2h', '3h', '4H'] },
  { label: 'DAYS & WEEKS', items: ['1D', '1W'] },
  { label: 'MONTHS & YEARS', items: ['1M', '3M', '6M', '1Y'] },
];

const normalizeTf = (tf: Timeframe): string => {
  if (tf === '1h') return '1H';
  if (tf === '4h') return '4H';
  return tf;
};

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentAsset,
  currentPrice,
  priceChange,
  priceChangePercent,
  timeframe,
  onChangeTimeframe,
  chartType,
  onChangeChartType,
  onOpenSymbolSearch,
  onOpenIndicators,
  activeIndicatorsCount,
  onTogglePythonEditor,
  isPythonEditorOpen,
  activePythonScriptsCount,
  isReplayMode,
  onToggleReplayMode,
  onToggleWatchlist,
  isWatchlistOpen,
  onOpenChartSettings,
  onOpenCreateAlert,
  activeAlertsCount,
  onOpenMarketAnalysis,
  onToggleFullscreen,
}) => {
  const [showTfDropdown, setShowTfDropdown] = useState(false);
  const tfDropdownRef = useRef<HTMLDivElement>(null);
  const isPositive = priceChange >= 0;

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (tfDropdownRef.current && !tfDropdownRef.current.contains(e.target as Node)) {
        setShowTfDropdown(false);
      }
    };
    if (showTfDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showTfDropdown]);

  return (
    <header className="h-14 bg-[#090d16] border-b border-slate-800/80 px-3 flex items-center justify-between gap-3 text-xs select-none shrink-0 z-30">
      {/* Left Section: Brand & Symbol Bar */}
      <div className="flex items-center gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2 pr-2 border-r border-slate-800/80">
          <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-md shadow-blue-500/20">
            <Activity className="w-4 h-4" />
          </div>
          <span className="text-base font-bold tracking-tight text-white hidden sm:inline">
            TradePulse
          </span>
        </div>

        {/* Symbol Quick Trigger */}
        <button
          onClick={onOpenSymbolSearch}
          className="flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 transition-colors group"
        >
          <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-white" />
          <div className="flex items-baseline gap-1.5">
            <span className="font-bold text-slate-100 text-xs tracking-wide">
              {currentAsset.symbol}
            </span>
            <span className="text-[10px] text-slate-400 hidden md:inline">
              {currentAsset.name}
            </span>
          </div>
        </button>

        {/* Realtime Live Price Display */}
        <div className="flex items-center gap-2 font-tabular pl-1">
          <span
            className={`font-semibold text-sm ${
              isPositive ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {currentPrice.toFixed(currentAsset.priceDecimals)}
          </span>
          <div
            className={`hidden sm:flex items-center gap-0.5 text-[11px] font-medium ${
              isPositive ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {isPositive ? (
              <TrendingUp className="w-3 h-3" />
            ) : (
              <TrendingDown className="w-3 h-3" />
            )}
            <span>
              {isPositive ? '+' : ''}
              {priceChange.toFixed(currentAsset.priceDecimals)} ({isPositive ? '+' : ''}
              {priceChangePercent.toFixed(2)}%)
            </span>
          </div>
        </div>
      </div>

      {/* Middle Section: Timeframe Selector (All Timeframes) & Chart Styles */}
      <div className="hidden md:flex items-center gap-0.5 bg-slate-900/60 p-1 rounded-lg border border-slate-800/80 max-w-[54vw] xl:max-w-none overflow-x-auto scrollbar-none">
        {/* Quick Favorite Timeframes */}
        {FAVORITE_TIMEFRAMES.map((tf) => {
          const isActive = normalizeTf(timeframe) === normalizeTf(tf);
          return (
            <button
              key={tf}
              onClick={() => onChangeTimeframe(tf)}
              className={`px-1.5 xl:px-2 py-1 rounded text-xs font-medium transition-colors shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {tf}
            </button>
          );
        })}

        {/* Custom / Non-favorite active timeframe pill if selected */}
        {!FAVORITE_TIMEFRAMES.some((t) => normalizeTf(t) === normalizeTf(timeframe)) && (
          <span className="px-2 py-1 rounded text-xs font-medium bg-blue-600 text-white shadow-sm shrink-0">
            {timeframe}
          </span>
        )}

        {/* All Timeframes Dropdown Button */}
        <div className="relative shrink-0" ref={tfDropdownRef}>
          <button
            onClick={() => setShowTfDropdown(!showTfDropdown)}
            title="All Timeframes"
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <ChevronDown className="w-3.5 h-3.5" />
          </button>

          {showTfDropdown && (
            <div className="absolute left-0 top-8 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-2.5 z-50 w-52 text-xs">
              <div className="text-[10px] font-bold text-slate-500 uppercase px-2 pb-1.5 border-b border-slate-800 tracking-wider">
                All Timeframes
              </div>
              <div className="py-1 space-y-2">
                {ALL_TIMEFRAMES.map((cat) => (
                  <div key={cat.label} className="space-y-1">
                    <span className="text-[9px] font-semibold text-slate-500 px-2 uppercase">
                      {cat.label}
                    </span>
                    <div className="grid grid-cols-4 gap-1">
                      {cat.items.map((tf) => {
                        const isActive = normalizeTf(timeframe) === normalizeTf(tf);
                        return (
                          <button
                            key={tf}
                            onClick={() => {
                              onChangeTimeframe(tf);
                              setShowTfDropdown(false);
                            }}
                            className={`py-1 px-1.5 rounded text-center font-medium transition-colors ${
                              isActive
                                ? 'bg-blue-600 text-white'
                                : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                            }`}
                          >
                            {tf}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="w-px h-4 bg-slate-800 mx-1" />

        {/* Chart Style Switcher */}
        <div className="flex items-center gap-0.5">
          <button
            onClick={() => onChangeChartType('candlestick')}
            title="Candlestick Chart"
            className={`p-1 rounded transition-colors ${
              chartType === 'candlestick'
                ? 'bg-slate-800 text-blue-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <CandlestickChart className="w-4 h-4" />
          </button>
          <button
            onClick={() => onChangeChartType('line')}
            title="Line Chart"
            className={`p-1 rounded transition-colors ${
              chartType === 'line'
                ? 'bg-slate-800 text-blue-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LineChart className="w-4 h-4" />
          </button>
          <button
            onClick={() => onChangeChartType('area')}
            title="Area Chart"
            className={`p-1 rounded transition-colors ${
              chartType === 'area'
                ? 'bg-slate-800 text-blue-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AreaChart className="w-4 h-4" />
          </button>
          <button
            onClick={() => onChangeChartType('heikin-ashi')}
            title="Heikin-Ashi Chart"
            className={`p-1 rounded transition-colors ${
              chartType === 'heikin-ashi'
                ? 'bg-slate-800 text-blue-400'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Right Section: Technicals, Price Alert, Indicators, Bar Replay, Settings, Watchlist */}
      <div className="flex items-center gap-2">
        {/* Technical Market Analysis Tool Trigger */}
        <button
          onClick={onOpenMarketAnalysis}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-blue-600/10 hover:bg-blue-600/20 border border-blue-500/30 text-blue-300 transition-colors font-medium"
          title="Open TradingView Market Analysis & Gauges"
        >
          <Gauge className="w-3.5 h-3.5 text-blue-400" />
          <span className="hidden sm:inline">Technicals</span>
        </button>

        {/* Set Price Alert Button */}
        <button
          onClick={onOpenCreateAlert}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 transition-colors"
          title="Set Price Alert"
        >
          <Bell className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-medium hidden sm:inline">Alert</span>
          {activeAlertsCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 text-[10px] font-bold">
              {activeAlertsCount}
            </span>
          )}
        </button>

        {/* Indicators Trigger */}
        <button
          onClick={onOpenIndicators}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200 transition-colors"
        >
          <SlidersHorizontal className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-medium hidden sm:inline">Indicators</span>
          {activeIndicatorsCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-blue-600/30 text-blue-300 text-[10px] font-semibold border border-blue-500/30">
              {activeIndicatorsCount}
            </span>
          )}
        </button>

        {/* Python Script Custom Indicator Editor Trigger */}
        <button
          onClick={onTogglePythonEditor}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border font-medium transition-colors ${
            isPythonEditorOpen
              ? 'bg-blue-600/25 border-blue-500/50 text-blue-300 shadow-sm'
              : 'bg-slate-900/80 hover:bg-slate-800 border-slate-800 text-slate-200 hover:border-slate-700'
          }`}
          title="Open Custom Indicator Python Script Editor"
        >
          <Code className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-medium hidden sm:inline">Python Script</span>
          {activePythonScriptsCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold border border-emerald-500/30">
              {activePythonScriptsCount}
            </span>
          )}
        </button>

        {/* 100% Free Bar Replay Engine Trigger */}
        <button
          onClick={onToggleReplayMode}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${
            isReplayMode
              ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
              : 'bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-200 hover:border-slate-700'
          }`}
          title="Toggle 100% Free Historical Bar Replay Engine"
        >
          <History className={`w-3.5 h-3.5 ${isReplayMode ? 'animate-spin' : 'text-amber-400'}`} />
          <span>Bar Replay</span>
          <span className="hidden sm:inline-block px-1 py-0.2 rounded text-[9px] uppercase font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 ml-0.5">
            Free
          </span>
        </button>

        {/* Chart Settings Button */}
        <button
          onClick={onOpenChartSettings}
          title="Chart Settings"
          className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors"
        >
          <Settings className="w-4 h-4" />
        </button>

        {/* Watchlist / Trading Panel Toggle */}
        <button
          onClick={onToggleWatchlist}
          title="Toggle Watchlist & Alerts Panel"
          className={`p-1.5 rounded-lg border transition-colors ${
            isWatchlistOpen
              ? 'bg-blue-600/20 border-blue-500/40 text-blue-400'
              : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bookmark className="w-4 h-4" />
        </button>

        {/* Fullscreen */}
        <button
          onClick={onToggleFullscreen}
          title="Fullscreen Chart"
          className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors hidden sm:flex"
        >
          <Maximize2 className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};

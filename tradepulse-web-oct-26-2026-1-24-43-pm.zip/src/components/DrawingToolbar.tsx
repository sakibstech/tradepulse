import React, { useState } from 'react';
import {
  MousePointer,
  Slash,
  ArrowRight,
  Minus,
  Split,
  Layers,
  Square,
  Circle,
  ArrowUpRight,
  ArrowDownRight,
  Ruler,
  Trash2,
  Palette,
  Columns,
  GitBranch,
  MoveUpRight,
  Type,
} from 'lucide-react';
import { DrawingToolType } from '../types/chart';

interface DrawingToolbarProps {
  activeTool: DrawingToolType;
  setActiveTool: (tool: DrawingToolType) => void;
  selectedColor: string;
  setSelectedColor: (color: string) => void;
  selectedLineWidth: number;
  setSelectedLineWidth: (w: number) => void;
  drawingsCount: number;
  onClearAll: () => void;
}

const COLOR_PALETTE = ['#38bdf8', '#22c55e', '#ef4444', '#facc15', '#a855f7', '#ffffff'];

export const DrawingToolbar: React.FC<DrawingToolbarProps> = ({
  activeTool,
  setActiveTool,
  selectedColor,
  setSelectedColor,
  selectedLineWidth,
  setSelectedLineWidth,
  drawingsCount,
  onClearAll,
}) => {
  const [showPalette, setShowPalette] = useState(false);

  const tools: { id: DrawingToolType; label: string; icon: React.ReactNode }[] = [
    { id: 'cursor', label: 'Cursor (Default)', icon: <MousePointer className="w-3.5 h-3.5" /> },
    {
      id: 'trendline',
      label: 'Trendline (2 Points)',
      icon: (
        <svg
          className="w-3.5 h-3.5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <line x1="4" y1="20" x2="20" y2="4" />
          <circle cx="4" cy="20" r="2.5" fill="currentColor" />
          <circle cx="20" cy="4" r="2.5" fill="currentColor" />
        </svg>
      ),
    },
    { id: 'ray', label: 'Extended Ray Line', icon: <ArrowRight className="w-3.5 h-3.5 -rotate-45" /> },
    { id: 'horizontal', label: 'Horizontal Line (Full Level)', icon: <Minus className="w-3.5 h-3.5" /> },
    {
      id: 'horizontal_ray',
      label: 'Horizontal Ray',
      icon: (
        <svg
          className="w-3.5 h-3.5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="5" cy="12" r="2.5" fill="currentColor" />
          <line x1="7.5" y1="12" x2="20" y2="12" />
          <polyline points="16 8 20 12 16 16" />
        </svg>
      ),
    },
    { id: 'vertical', label: 'Vertical Time Line', icon: <Split className="w-3.5 h-3.5 rotate-90" /> },
    { id: 'parallel_channel', label: 'Parallel Price Channel', icon: <Columns className="w-3.5 h-3.5 rotate-45" /> },
    {
      id: 'fibonacci',
      label: 'Fibonacci Retracement (0.236, 0.382, 0.5, 0.618, 0.786)',
      icon: (
        <svg
          className="w-3.5 h-3.5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <line x1="3" y1="4" x2="21" y2="4" />
          <line x1="3" y1="8" x2="21" y2="8" />
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="15.5" x2="21" y2="15.5" />
          <line x1="3" y1="20" x2="21" y2="20" />
          <line x1="5" y1="19" x2="19" y2="5" strokeDasharray="2 2" strokeWidth="1.5" />
        </svg>
      ),
    },
    { id: 'fib_extension', label: 'Fibonacci Extension (Trend-Based)', icon: <GitBranch className="w-3.5 h-3.5" /> },
    { id: 'rectangle', label: 'Rectangle / S&R Zone', icon: <Square className="w-3.5 h-3.5" /> },
    { id: 'circle', label: 'Key Pivot Circle', icon: <Circle className="w-3.5 h-3.5" /> },
    { id: 'arrow', label: 'Arrow Pointer', icon: <MoveUpRight className="w-3.5 h-3.5" /> },
    { id: 'text_note', label: 'Text Callout Annotation', icon: <Type className="w-3.5 h-3.5" /> },
    { id: 'position_long', label: 'Long Position (R:R Calculator)', icon: <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'position_short', label: 'Short Position (R:R Calculator)', icon: <ArrowDownRight className="w-3.5 h-3.5 text-red-400" /> },
    { id: 'measure', label: 'Measure (Price Range & Candle Count)', icon: <Ruler className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="w-11 bg-[#090d16] border-r border-slate-800/80 flex flex-col items-center py-2 z-20 shrink-0 select-none overflow-y-auto">
      <div className="flex flex-col items-center gap-0.5 w-full px-1">
        {tools.map((t) => {
          const isActive = activeTool === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setActiveTool(t.id)}
              title={t.label}
              className={`w-8 h-8 flex items-center justify-center rounded transition-colors group relative ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {t.icon}
              {/* Tooltip */}
              <span className="absolute left-10 bg-slate-900 border border-slate-700 text-slate-200 text-xs px-2 py-1 rounded shadow-lg opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
                {t.label}
              </span>
            </button>
          );
        })}

        <div className="w-5 h-px bg-slate-800 my-1.5" />

        {/* Color / Styling Popover */}
        <div className="relative">
          <button
            onClick={() => setShowPalette(!showPalette)}
            title="Drawing Color & Width"
            className="w-8 h-8 flex items-center justify-center rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 transition-colors relative"
          >
            <Palette className="w-3.5 h-3.5" />
            <div
              className="absolute bottom-1 right-1 w-2 h-2 rounded-full border border-slate-900"
              style={{ backgroundColor: selectedColor }}
            />
          </button>

          {showPalette && (
            <div className="absolute left-10 top-0 bg-slate-900 border border-slate-800 p-2.5 rounded-lg shadow-2xl z-50 w-44">
              <div className="text-[11px] font-medium text-slate-400 mb-1.5">Drawing Color</div>
              <div className="flex items-center gap-1.5 mb-3">
                {COLOR_PALETTE.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      setSelectedColor(c);
                      setShowPalette(false);
                    }}
                    className={`w-5 h-5 rounded-full border transition-transform ${
                      selectedColor === c ? 'scale-125 border-white' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>

              <div className="text-[11px] font-medium text-slate-400 mb-1.5">Line Thickness</div>
              <div className="flex items-center gap-2">
                {[1, 2, 3].map((w) => (
                  <button
                    key={w}
                    onClick={() => {
                      setSelectedLineWidth(w);
                      setShowPalette(false);
                    }}
                    className={`flex-1 py-1 text-xs rounded border transition-colors ${
                      selectedLineWidth === w
                        ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                        : 'border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    {w}px
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Clear All Drawings */}
        {drawingsCount > 0 && (
          <button
            onClick={onClearAll}
            title={`Clear All Drawings (${drawingsCount})`}
            className="w-8 h-8 flex items-center justify-center rounded text-slate-400 hover:text-red-400 hover:bg-red-950/30 transition-colors group relative mt-0.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="absolute left-10 bg-slate-900 border border-slate-700 text-slate-200 text-xs px-2 py-1 rounded shadow-lg opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50">
              Clear All ({drawingsCount})
            </span>
          </button>
        )}
      </div>
    </div>
  );
};

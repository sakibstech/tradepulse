import React, { useState, useMemo } from 'react';
import { Search, X, Check } from 'lucide-react';
import { SUPPORTED_ASSETS } from '../services/marketData';
import { AssetCategory, AssetInfo } from '../types/chart';

interface SymbolSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSymbol: string;
  onSelectSymbol: (symbol: string) => void;
}

const CATEGORIES: ('All' | AssetCategory)[] = [
  'All',
  'Crypto',
  'Forex',
  'Commodities',
  'Stocks',
  'Indices',
];

export const SymbolSearchModal: React.FC<SymbolSearchModalProps> = ({
  isOpen,
  onClose,
  currentSymbol,
  onSelectSymbol,
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | AssetCategory>('All');

  const filteredAssets = useMemo(() => {
    return SUPPORTED_ASSETS.filter((asset) => {
      const matchesCategory =
        selectedCategory === 'All' || asset.category === selectedCategory;
      const q = query.toLowerCase().trim();
      const matchesQuery =
        !q ||
        asset.symbol.toLowerCase().includes(q) ||
        asset.name.toLowerCase().includes(q) ||
        asset.description.toLowerCase().includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [query, selectedCategory]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm select-none p-4">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            placeholder="Search symbol, currency, commodity or stock (e.g. BTC, XAU, AAPL, EUR)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
            className="w-full bg-transparent border-0 text-slate-100 placeholder-slate-500 focus:outline-none text-sm"
          />
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Filter Tabs */}
        <div className="px-4 py-2 border-b border-slate-800/80 bg-slate-900/40 flex items-center gap-1 overflow-x-auto">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Asset List */}
        <div className="p-2 overflow-y-auto divide-y divide-slate-800/40 flex-1">
          {filteredAssets.length === 0 ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              No matching assets found for "{query}".
            </div>
          ) : (
            filteredAssets.map((asset: AssetInfo) => {
              const isSelected = asset.symbol === currentSymbol;
              return (
                <div
                  key={asset.symbol}
                  onClick={() => {
                    onSelectSymbol(asset.symbol);
                    onClose();
                  }}
                  className={`px-3 py-2.5 rounded-lg flex items-center justify-between cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-blue-600/15 border border-blue-500/40'
                      : 'hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-blue-400 font-tabular">
                      {asset.symbol.slice(0, 3)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-100 text-sm">
                          {asset.symbol}
                        </span>
                        <span className="text-[11px] text-slate-400 font-normal">
                          {asset.exchange}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400">{asset.name}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-slate-200 font-medium text-xs font-tabular">
                        ${asset.basePrice.toLocaleString(undefined, {
                          minimumFractionDigits: asset.priceDecimals,
                          maximumFractionDigits: asset.priceDecimals,
                        })}
                      </div>
                      <div className="text-[11px] text-slate-500">{asset.category}</div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-blue-400 shrink-0" />}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

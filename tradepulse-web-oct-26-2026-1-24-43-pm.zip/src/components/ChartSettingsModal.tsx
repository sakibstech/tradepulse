import React from 'react';
import { X, Check, RotateCcw, Volume2, Eye } from 'lucide-react';
import { ChartSettings } from '../types/chart';
import { soundManager } from '../utils/soundAlert';

interface ChartSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ChartSettings;
  onChangeSettings: (settings: ChartSettings) => void;
}

const THEME_PRESETS = [
  { name: 'Midnight (Default)', bg: '#0b0f19', grid: 'rgba(30, 41, 59, 0.45)' },
  { name: 'Pitch Black', bg: '#000000', grid: 'rgba(38, 38, 38, 0.5)' },
  { name: 'Deep Slate', bg: '#0f172a', grid: 'rgba(51, 65, 85, 0.4)' },
  { name: 'Navy Blue', bg: '#070f26', grid: 'rgba(30, 58, 138, 0.3)' },
];

const CANDLE_PRESETS = [
  { name: 'Standard (Green / Red)', up: '#22c55e', down: '#ef4444' },
  { name: 'Neon (Teal / Magenta)', up: '#06b6d4', down: '#f43f5e' },
  { name: 'Pro (Emerald / Amber)', up: '#10b981', down: '#f59e0b' },
  { name: 'Monochrome', up: '#e2e8f0', down: '#475569' },
];

export const ChartSettingsModal: React.FC<ChartSettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onChangeSettings,
}) => {
  if (!isOpen) return null;

  const handleReset = () => {
    onChangeSettings({
      backgroundColor: '#0b0f19',
      showGridVert: true,
      showGridHorz: true,
      gridColor: 'rgba(30, 41, 59, 0.45)',
      upColor: '#22c55e',
      downColor: '#ef4444',
      candleBorder: true,
      soundAlerts: true,
      watermark: true,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm select-none p-4">
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-100">Chart Settings</h2>
            <p className="text-xs text-slate-400">
              Customize chart canvas appearance, gridlines, colors, and audio
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-xs text-slate-300">
          {/* Background Theme */}
          <div>
            <label className="text-slate-200 font-semibold block mb-2">
              Background Color Theme
            </label>
            <div className="grid grid-cols-2 gap-2">
              {THEME_PRESETS.map((t) => {
                const isSelected = settings.backgroundColor === t.bg;
                return (
                  <button
                    key={t.name}
                    onClick={() =>
                      onChangeSettings({
                        ...settings,
                        backgroundColor: t.bg,
                        gridColor: t.grid,
                      })
                    }
                    className={`p-2.5 rounded-lg border flex items-center gap-2.5 transition-colors text-left ${
                      isSelected
                        ? 'border-blue-500 bg-blue-500/10 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div
                      className="w-5 h-5 rounded-md border border-slate-700 shrink-0"
                      style={{ backgroundColor: t.bg }}
                    />
                    <span className="font-medium text-xs">{t.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Candle Colors */}
          <div className="pt-3 border-t border-slate-800">
            <label className="text-slate-200 font-semibold block mb-2">
              Candlestick Color Palette
            </label>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {CANDLE_PRESETS.map((p) => {
                const isSelected = settings.upColor === p.up && settings.downColor === p.down;
                return (
                  <button
                    key={p.name}
                    onClick={() =>
                      onChangeSettings({
                        ...settings,
                        upColor: p.up,
                        downColor: p.down,
                      })
                    }
                    className={`p-2 rounded-lg border flex items-center justify-between transition-colors ${
                      isSelected
                        ? 'border-blue-500 bg-blue-500/10 text-white'
                        : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span className="font-medium text-[11px]">{p.name}</span>
                    <div className="flex items-center gap-1">
                      <div
                        className="w-3.5 h-3.5 rounded-full"
                        style={{ backgroundColor: p.up }}
                      />
                      <div
                        className="w-3.5 h-3.5 rounded-full"
                        style={{ backgroundColor: p.down }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Custom Up/Down Colors */}
            <div className="grid grid-cols-2 gap-3 p-2.5 rounded-lg bg-slate-900/40 border border-slate-800/80">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Bullish (Up) Color</span>
                <input
                  type="color"
                  value={settings.upColor}
                  onChange={(e) =>
                    onChangeSettings({ ...settings, upColor: e.target.value })
                  }
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Bearish (Down) Color</span>
                <input
                  type="color"
                  value={settings.downColor}
                  onChange={(e) =>
                    onChangeSettings({ ...settings, downColor: e.target.value })
                  }
                  className="w-6 h-6 rounded cursor-pointer bg-transparent border-0"
                />
              </div>
            </div>
          </div>

          {/* Grid Lines Controls */}
          <div className="pt-3 border-t border-slate-800">
            <label className="text-slate-200 font-semibold block mb-2">
              Chart Grid Lines
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
                <span className="text-slate-300">Vertical Grid Lines</span>
                <input
                  type="checkbox"
                  checked={settings.showGridVert}
                  onChange={(e) =>
                    onChangeSettings({
                      ...settings,
                      showGridVert: e.target.checked,
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
              </label>
              <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
                <span className="text-slate-300">Horizontal Grid Lines</span>
                <input
                  type="checkbox"
                  checked={settings.showGridHorz}
                  onChange={(e) =>
                    onChangeSettings({
                      ...settings,
                      showGridHorz: e.target.checked,
                    })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* Symbol Watermark & Sound */}
          <div className="pt-3 border-t border-slate-800 space-y-3">
            <label className="text-slate-200 font-semibold block">
              Display & Audio Alerts
            </label>

            <label className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-blue-400" />
                <div>
                  <span className="text-slate-200 block font-medium">Chart Symbol Watermark</span>
                  <span className="text-[11px] text-slate-500">
                    Displays background asset symbol on chart canvas
                  </span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.watermark}
                onChange={(e) =>
                  onChangeSettings({ ...settings, watermark: e.target.checked })
                }
                className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
              />
            </label>

            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-amber-400" />
                <div>
                  <span className="text-slate-200 block font-medium">Audio Notifications</span>
                  <span className="text-[11px] text-slate-500">
                    Play harmonic chime whenever price alerts trigger
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => soundManager.playPriceAlertChime()}
                  className="px-2.5 py-1 text-[11px] bg-slate-800 hover:bg-slate-700 text-amber-300 rounded border border-slate-700 font-medium transition-colors"
                >
                  Test Sound
                </button>
                <input
                  type="checkbox"
                  checked={settings.soundAlerts}
                  onChange={(e) =>
                    onChangeSettings({ ...settings, soundAlerts: e.target.checked })
                  }
                  className="rounded border-slate-700 bg-slate-800 text-blue-500 focus:ring-0 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-900/40 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Defaults</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition-colors flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            Apply Settings
          </button>
        </div>
      </div>
    </div>
  );
};

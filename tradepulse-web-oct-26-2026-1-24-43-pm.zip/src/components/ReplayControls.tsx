import React, { useEffect } from 'react';
import {
  Play,
  Pause,
  StepForward,
  RotateCcw,
  Scissors,
  X,
  TrendingUp,
  TrendingDown,
  Gauge,
  Calendar,
} from 'lucide-react';
import { Candle } from '../types/chart';

interface ReplayControlsProps {
  isReplayMode: boolean;
  onToggleReplayMode: () => void;
  replayIndex: number;
  totalCandles: number;
  currentCandle: Candle | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onStepForward: () => void;
  onStepBackward: () => void;
  onResetReplay: () => void;
  speed: number;
  onSpeedChange: (speed: number) => void;
  isSelectingCutPoint: boolean;
  onToggleSelectCutPoint: () => void;
  onScrub: (index: number) => void;
  onExecutePaperTrade: (type: 'BUY' | 'SELL') => void;
  paperTradePnL: number;
  openPositionCount: number;
  priceDecimals: number;
}

const SPEED_OPTIONS = [0.5, 1, 2, 5, 10];

export const ReplayControls: React.FC<ReplayControlsProps> = ({
  isReplayMode,
  onToggleReplayMode,
  replayIndex,
  totalCandles,
  currentCandle,
  isPlaying,
  onPlayPause,
  onStepForward,
  onResetReplay,
  speed,
  onSpeedChange,
  isSelectingCutPoint,
  onToggleSelectCutPoint,
  onScrub,
  onExecutePaperTrade,
  paperTradePnL,
  openPositionCount,
  priceDecimals,
}) => {
  // Keyboard shortcuts for Replay
  useEffect(() => {
    if (!isReplayMode) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if typing in an input
      if ((e.target as HTMLElement).tagName === 'INPUT') return;
      if (e.code === 'Space') {
        e.preventDefault();
        onPlayPause();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        onStepForward();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isReplayMode, onPlayPause, onStepForward]);

  if (!isReplayMode) return null;

  const formattedDate = currentCandle
    ? new Date(currentCandle.time * 1000).toLocaleString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-2 max-w-[94vw] select-none">
      {/* Cut Point Guidance Banner */}
      {isSelectingCutPoint && (
        <div className="bg-amber-500/90 text-slate-950 font-semibold px-4 py-1.5 rounded-full text-xs shadow-lg flex items-center gap-2 animate-bounce">
          <Scissors className="w-3.5 h-3.5" />
          <span>Click anywhere on the chart or candle to cut history at that bar!</span>
          <button
            onClick={onToggleSelectCutPoint}
            className="hover:bg-amber-600/50 p-0.5 rounded ml-2"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Main Replay Console Bar */}
      <div className="bg-[#0f172a]/95 backdrop-blur-md border border-slate-700/80 rounded-xl px-4 py-2.5 shadow-2xl flex items-center gap-4 text-xs text-slate-200">
        {/* Replay Status Badge */}
        <div className="flex items-center gap-2 pr-3 border-r border-slate-800">
          <span className="w-2 h-2 rounded-full bg-blue-500" />
          <div className="flex flex-col">
            <span className="font-semibold text-slate-100 uppercase tracking-wider text-[10px]">
              Bar Replay
            </span>
            <span className="text-[11px] text-slate-400 font-tabular">
              {replayIndex} / {totalCandles}
            </span>
          </div>
        </div>

        {/* Cut Tool Button */}
        <button
          onClick={onToggleSelectCutPoint}
          title="Jump to Bar (Cut history at candle)"
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-colors ${
            isSelectingCutPoint
              ? 'bg-amber-500/20 border-amber-500 text-amber-300'
              : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
          }`}
        >
          <Scissors className="w-3.5 h-3.5" />
          <span className="hidden sm:inline font-medium">Jump to Bar</span>
        </button>

        {/* Reset to Start */}
        <button
          onClick={onResetReplay}
          title="Reset to Start"
          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        {/* Play / Pause */}
        <button
          onClick={onPlayPause}
          title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
          className="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center transition-transform active:scale-95 shadow-md shadow-blue-500/25"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
        </button>

        {/* Step Forward +1 Candle */}
        <button
          onClick={onStepForward}
          title="Step Forward 1 Candle (Right Arrow)"
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
        >
          <StepForward className="w-3.5 h-3.5" />
          <span className="hidden sm:inline font-medium">+1 Bar</span>
        </button>

        {/* Speed Selector */}
        <div className="flex items-center gap-1 pl-1">
          <Gauge className="w-3.5 h-3.5 text-slate-400 hidden sm:inline" />
          <div className="flex items-center bg-slate-800/90 rounded-lg p-0.5 border border-slate-700">
            {SPEED_OPTIONS.map((s) => (
              <button
                key={s}
                onClick={() => onSpeedChange(s)}
                className={`px-1.5 py-1 rounded text-[11px] font-medium transition-colors ${
                  speed === s
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>

        {/* Scrubber slider */}
        <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-slate-800 w-44">
          <input
            type="range"
            min={15}
            max={totalCandles}
            value={replayIndex}
            onChange={(e) => onScrub(Number(e.target.value))}
            className="w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
        </div>

        {/* Replay Timestamp */}
        {formattedDate && (
          <div className="hidden md:flex items-center gap-1.5 text-slate-300 font-tabular text-[11px] border-l border-slate-800 pl-3">
            <Calendar className="w-3 h-3 text-slate-400" />
            <span>{formattedDate}</span>
          </div>
        )}

        {/* Paper Trading Backtesting Trigger */}
        <div className="flex items-center gap-1.5 border-l border-slate-800 pl-3">
          <button
            onClick={() => onExecutePaperTrade('BUY')}
            className="px-2.5 py-1.5 rounded-md bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white border border-emerald-500/40 font-semibold transition-colors flex items-center gap-1 text-[11px]"
            title="Simulate Market Buy at replay price"
          >
            <TrendingUp className="w-3 h-3" />
            Buy
          </button>
          <button
            onClick={() => onExecutePaperTrade('SELL')}
            className="px-2.5 py-1.5 rounded-md bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white border border-red-500/40 font-semibold transition-colors flex items-center gap-1 text-[11px]"
            title="Simulate Market Sell at replay price"
          >
            <TrendingDown className="w-3 h-3" />
            Sell
          </button>
        </div>

        {/* Simulated PnL Tracker */}
        {openPositionCount > 0 && (
          <div className="hidden xl:flex items-center gap-1.5 pl-2 font-tabular">
            <span className="text-slate-400 text-[10px]">Sim PnL:</span>
            <span
              className={`font-semibold text-xs ${
                paperTradePnL >= 0 ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              {paperTradePnL >= 0 ? '+' : ''}${paperTradePnL.toFixed(priceDecimals)}
            </span>
          </div>
        )}

        {/* Exit Replay Mode */}
        <button
          onClick={onToggleReplayMode}
          title="Exit Replay Mode"
          className="p-1 rounded-md text-slate-400 hover:text-slate-200 hover:bg-slate-800 ml-1 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

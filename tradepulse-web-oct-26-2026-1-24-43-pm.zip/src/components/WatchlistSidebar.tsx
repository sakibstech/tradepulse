import React, { useState } from 'react';
import {
  X,
  TrendingUp,
  TrendingDown,
  Bell,
  Trash2,
  Plus,
  CheckCircle2,
  Clock,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { SUPPORTED_ASSETS } from '../services/marketData';
import { PaperTradePosition, PriceAlert } from '../types/chart';

interface WatchlistSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  positions: PaperTradePosition[];
  onClosePosition: (id: string) => void;
  accountBalance: number;
  totalPnL: number;
  alerts: PriceAlert[];
  onDeleteAlert: (id: string) => void;
  onOpenCreateAlert: () => void;
  currentPrice: number;
}

export const WatchlistSidebar: React.FC<WatchlistSidebarProps> = ({
  isOpen,
  onClose,
  currentSymbol,
  onSelectSymbol,
  positions,
  onClosePosition,
  accountBalance,
  totalPnL,
  alerts,
  onDeleteAlert,
  onOpenCreateAlert,
  currentPrice,
}) => {
  const [activeTab, setActiveTab] = useState<'watchlist' | 'trades' | 'alerts'>('watchlist');

  if (!isOpen) return null;

  const openPositions = positions.filter((p) => p.status === 'OPEN');
  const closedPositions = positions.filter((p) => p.status === 'CLOSED');
  const activeAlerts = alerts.filter((a) => !a.triggered);
  const triggeredAlerts = alerts.filter((a) => a.triggered);

  return (
    <aside className="w-80 bg-[#090d16] border-l border-slate-800/80 flex flex-col z-20 shrink-0 select-none h-full overflow-hidden text-xs">
      {/* Header Tabs */}
      <div className="h-12 border-b border-slate-800 flex items-center justify-between px-2.5 bg-slate-900/40">
        <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded-lg border border-slate-800">
          <button
            onClick={() => setActiveTab('watchlist')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === 'watchlist'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Watchlist
          </button>
          <button
            onClick={() => setActiveTab('trades')}
            className={`px-2 py-1 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'trades'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Trades</span>
            {openPositions.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-bold flex items-center justify-center">
                {openPositions.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('alerts')}
            className={`px-2 py-1 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
              activeTab === 'alerts'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bell className="w-3 h-3" />
            <span>Alerts</span>
            {activeAlerts.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-bold flex items-center justify-center">
                {activeAlerts.length}
              </span>
            )}
          </button>
        </div>

        <button
          onClick={onClose}
          className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Account Balance Summary (on Watchlist & Trades tabs) */}
      {activeTab !== 'alerts' && (
        <div className="px-4 py-2.5 bg-slate-900/60 border-b border-slate-800/60 flex items-center justify-between font-tabular">
          <div>
            <span className="text-[10px] uppercase text-slate-400 font-semibold tracking-wider block">
              Simulated Balance
            </span>
            <span className="text-xs font-bold text-slate-100">
              ${(accountBalance + totalPnL).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] uppercase text-slate-400 font-semibold tracking-wider block">
              Unrealized PnL
            </span>
            <span
              className={`text-xs font-bold ${
                totalPnL >= 0 ? 'text-emerald-400' : 'text-red-400'
              }`}
            >
              {totalPnL >= 0 ? '+' : ''}${totalPnL.toFixed(2)}
            </span>
          </div>
        </div>
      )}

      {/* Tab 1: Watchlist View */}
      {activeTab === 'watchlist' && (
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40 p-1.5">
          {SUPPORTED_ASSETS.map((asset) => {
            const isSelected = asset.symbol === currentSymbol;
            const hasAlert = activeAlerts.some((a) => a.symbol === asset.symbol);
            return (
              <div
                key={asset.symbol}
                onClick={() => onSelectSymbol(asset.symbol)}
                className={`p-2.5 rounded-lg flex items-center justify-between cursor-pointer transition-colors ${
                  isSelected
                    ? 'bg-blue-600/15 border border-blue-500/40'
                    : 'hover:bg-slate-800/50'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-slate-100 text-xs tracking-wide">
                      {asset.symbol}
                    </span>
                    {hasAlert && (
                      <Bell className="w-3 h-3 text-amber-400 fill-amber-400/20" />
                    )}
                    <span className="text-[10px] text-slate-500">{asset.category}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate max-w-[130px]">
                    {asset.name}
                  </div>
                </div>

                <div className="text-right font-tabular">
                  <div className="text-slate-100 font-medium text-xs">
                    ${asset.basePrice.toLocaleString(undefined, {
                      minimumFractionDigits: asset.priceDecimals,
                      maximumFractionDigits: asset.priceDecimals,
                    })}
                  </div>
                  <div className="text-emerald-400 text-[11px] font-medium flex items-center justify-end gap-0.5">
                    <TrendingUp className="w-3 h-3" />
                    <span>+1.24%</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Simulated Positions & Trades View */}
      {activeTab === 'trades' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Open Positions ({openPositions.length})
          </div>

          {openPositions.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              No open positions. Use Buy/Sell during replay to simulate trades.
            </div>
          ) : (
            openPositions.map((pos) => {
              const isProfit = pos.pnl >= 0;
              return (
                <div
                  key={pos.id}
                  className="bg-slate-900/80 border border-slate-800 rounded-lg p-2.5 flex flex-col gap-2 font-tabular"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          pos.type === 'BUY'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}
                      >
                        {pos.type}
                      </span>
                      <span className="font-semibold text-slate-200">{pos.symbol}</span>
                    </div>
                    <button
                      onClick={() => onClosePosition(pos.id)}
                      className="px-2 py-0.5 rounded text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition-colors"
                    >
                      Close
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                    <div>
                      <span>Entry: </span>
                      <span className="text-slate-200 font-medium">${pos.entryPrice.toFixed(2)}</span>
                    </div>
                    <div className="text-right">
                      <span>Cur: </span>
                      <span className="text-slate-200 font-medium">${pos.currentPrice.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="pt-1.5 border-t border-slate-800/80 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500">PnL:</span>
                    <span
                      className={`font-bold text-xs ${
                        isProfit ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {isProfit ? '+' : ''}${pos.pnl.toFixed(2)} ({isProfit ? '+' : ''}
                      {pos.pnlPercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              );
            })
          )}

          {/* Closed Positions History */}
          {closedPositions.length > 0 && (
            <div className="pt-3 border-t border-slate-800">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Trade History ({closedPositions.length})
              </div>
              <div className="space-y-1.5">
                {closedPositions.map((pos) => (
                  <div
                    key={pos.id}
                    className="p-2 rounded bg-slate-900/40 border border-slate-800/60 flex items-center justify-between text-[11px] font-tabular"
                  >
                    <div>
                      <span
                        className={`font-semibold mr-1.5 ${
                          pos.type === 'BUY' ? 'text-emerald-400' : 'text-red-400'
                        }`}
                      >
                        {pos.type}
                      </span>
                      <span className="text-slate-300">{pos.symbol}</span>
                    </div>
                    <div
                      className={`font-bold ${
                        pos.pnl >= 0 ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {pos.pnl >= 0 ? '+' : ''}${pos.pnl.toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Price Alerts View */}
      {activeTab === 'alerts' && (
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {/* Quick Add Alert Button */}
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Active Alerts ({activeAlerts.length})
            </span>
            <button
              onClick={onOpenCreateAlert}
              className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-slate-950 border border-amber-500/40 font-semibold transition-colors text-[11px]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Alert</span>
            </button>
          </div>

          {activeAlerts.length === 0 ? (
            <div className="py-8 text-center text-slate-500 text-xs">
              <Bell className="w-6 h-6 mx-auto mb-2 text-slate-600" />
              <p>No active price alerts set.</p>
              <p className="text-[10px] text-slate-600 mt-1">
                Click "New Alert" or set a level for {currentSymbol}.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {activeAlerts.map((alert) => {
                const isForCurrentAsset = alert.symbol === currentSymbol;
                const priceDiff = alert.targetPrice - (isForCurrentAsset ? currentPrice : alert.createdPrice);
                const pctDiff = ((priceDiff / (isForCurrentAsset ? currentPrice : alert.createdPrice)) * 100).toFixed(2);

                return (
                  <div
                    key={alert.id}
                    className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-colors flex flex-col gap-1.5 font-tabular"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-100 text-xs">
                          {alert.symbol}
                        </span>
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-medium flex items-center gap-0.5 ${
                            alert.condition === 'CROSSES_ABOVE'
                              ? 'bg-emerald-500/15 text-emerald-400'
                              : alert.condition === 'CROSSES_BELOW'
                              ? 'bg-red-500/15 text-red-400'
                              : 'bg-blue-500/15 text-blue-400'
                          }`}
                        >
                          {alert.condition === 'CROSSES_ABOVE' ? (
                            <>
                              <ArrowUp className="w-2.5 h-2.5" /> Above
                            </>
                          ) : alert.condition === 'CROSSES_BELOW' ? (
                            <>
                              <ArrowDown className="w-2.5 h-2.5" /> Below
                            </>
                          ) : (
                            'Cross'
                          )}
                        </span>
                      </div>
                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className="text-slate-500 hover:text-red-400 p-1 rounded transition-colors"
                        title="Delete Alert"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex items-baseline justify-between">
                      <span className="text-base font-bold text-amber-400">
                        ${alert.targetPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                      </span>
                      {isForCurrentAsset && (
                        <span className="text-[11px] text-slate-400">
                          {priceDiff >= 0 ? '+' : ''}{pctDiff}% away
                        </span>
                      )}
                    </div>

                    {alert.note && (
                      <p className="text-[11px] text-slate-400 italic truncate border-t border-slate-800/60 pt-1 mt-0.5">
                        "{alert.note}"
                      </p>
                    )}

                    <div className="flex items-center gap-2 text-[10px] text-slate-500 pt-0.5">
                      {alert.soundEnabled && <span>🔊 Sound</span>}
                      {alert.telegramEnabled && <span className="text-sky-400">✈️ Telegram</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Triggered History */}
          {triggeredAlerts.length > 0 && (
            <div className="pt-3 border-t border-slate-800">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Triggered History ({triggeredAlerts.length})</span>
              </div>
              <div className="space-y-1.5">
                {triggeredAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="p-2 rounded bg-slate-900/40 border border-slate-800/60 flex items-center justify-between text-[11px] font-tabular opacity-75"
                  >
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <div>
                        <span className="font-semibold text-slate-300 mr-1">
                          {alert.symbol}
                        </span>
                        <span className="text-slate-400">
                          ${alert.targetPrice.toFixed(2)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500">
                        {new Date(alert.triggeredAt || alert.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className="text-slate-500 hover:text-red-400 p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </aside>
  );
};

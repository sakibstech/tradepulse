import React, { useState, useEffect } from 'react';
import {
  X,
  Bell,
  Volume2,
  Send,
  CheckCircle2,
  AlertCircle,
  ArrowUp,
  ArrowDown,
  Trash2,
  Eye,
  EyeOff,
  Loader2,
  Clock,
  Sparkles,
} from 'lucide-react';
import { AssetInfo, PriceAlert, TelegramSettings } from '../types/chart';
import { sendTelegramTestMessage } from '../services/telegramService';

interface CreateAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentAsset: AssetInfo;
  currentPrice: number;
  alerts: PriceAlert[];
  onSaveAlert: (alert: Omit<PriceAlert, 'id' | 'createdAt' | 'triggered'>) => void;
  onDeleteAlert: (id: string) => void;
  telegramSettings: TelegramSettings;
  onUpdateTelegramSettings: (settings: TelegramSettings) => void;
}

export const CreateAlertModal: React.FC<CreateAlertModalProps> = ({
  isOpen,
  onClose,
  currentAsset,
  currentPrice,
  alerts,
  onSaveAlert,
  onDeleteAlert,
  telegramSettings,
  onUpdateTelegramSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'active' | 'telegram'>('create');

  // Form State
  const [targetPrice, setTargetPrice] = useState<string>('');
  const [condition, setCondition] = useState<'CROSSES_ABOVE' | 'CROSSES_BELOW' | 'CROSSES'>(
    'CROSSES_ABOVE'
  );
  const [note, setNote] = useState<string>('');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [telegramEnabled, setTelegramEnabled] = useState<boolean>(
    telegramSettings.enabled && Boolean(telegramSettings.botToken && telegramSettings.chatId)
  );

  // Telegram Config Tab State
  const [tgBotToken, setTgBotToken] = useState<string>(telegramSettings.botToken || '');
  const [tgChatId, setTgChatId] = useState<string>(telegramSettings.chatId || '');
  const [tgAutoSend, setTgAutoSend] = useState<boolean>(telegramSettings.autoSendAlerts ?? true);
  const [showToken, setShowToken] = useState<boolean>(false);
  const [isTestingTg, setIsTestingTg] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Initialize target price when modal opens
  useEffect(() => {
    if (isOpen && currentPrice) {
      setTargetPrice(currentPrice.toFixed(currentAsset.priceDecimals));
      setTelegramEnabled(
        telegramSettings.enabled && Boolean(telegramSettings.botToken && telegramSettings.chatId)
      );
      setTgBotToken(telegramSettings.botToken || '');
      setTgChatId(telegramSettings.chatId || '');
      setTgAutoSend(telegramSettings.autoSendAlerts ?? true);
      setTestResult(null);
    }
  }, [isOpen, currentPrice, currentAsset.priceDecimals, telegramSettings]);

  if (!isOpen) return null;

  // Active alerts for current asset & all assets
  const activeAlerts = alerts.filter((a) => !a.triggered);
  const triggeredAlerts = alerts.filter((a) => a.triggered);
  const isTelegramReady = Boolean(
    telegramSettings.enabled &&
    telegramSettings.botToken.trim() &&
    telegramSettings.chatId.trim()
  );

  // Parse numeric target price and calculate offset from market
  const priceNum = parseFloat(targetPrice);
  const isValidPrice = !isNaN(priceNum) && priceNum > 0;
  const priceDiff = isValidPrice ? priceNum - currentPrice : 0;
  const pctDiff = currentPrice > 0 ? (priceDiff / currentPrice) * 100 : 0;

  // Quick Percentage Preset Handlers
  const applyPercentPreset = (pct: number) => {
    const newPrice = currentPrice * (1 + pct / 100);
    setTargetPrice(newPrice.toFixed(currentAsset.priceDecimals));
    if (pct > 0) {
      setCondition('CROSSES_ABOVE');
    } else if (pct < 0) {
      setCondition('CROSSES_BELOW');
    }
  };

  const resetToCurrentPrice = () => {
    setTargetPrice(currentPrice.toFixed(currentAsset.priceDecimals));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidPrice) return;

    onSaveAlert({
      symbol: currentAsset.symbol,
      targetPrice: priceNum,
      condition,
      note: note.trim() || undefined,
      createdPrice: currentPrice,
      soundEnabled,
      telegramEnabled: telegramEnabled && isTelegramReady,
    });
    onClose();
  };

  // Test Telegram connection
  const handleTestTelegram = async () => {
    if (!tgBotToken.trim() || !tgChatId.trim()) {
      setTestResult({
        success: false,
        message: 'Please provide both Bot Token and Chat ID before testing.',
      });
      return;
    }

    setIsTestingTg(true);
    setTestResult(null);

    const res = await sendTelegramTestMessage(tgBotToken.trim(), tgChatId.trim());
    setIsTestingTg(false);

    if (res.success) {
      setTestResult({
        success: true,
        message: 'Test message sent! Check your Telegram app for the verification alert.',
      });
      // Save settings automatically on successful test
      onUpdateTelegramSettings({
        enabled: true,
        botToken: tgBotToken.trim(),
        chatId: tgChatId.trim(),
        autoSendAlerts: tgAutoSend,
        lastTestStatus: 'success',
        lastTestMessage: 'Verified successfully',
      });
      setTelegramEnabled(true);
    } else {
      setTestResult({
        success: false,
        message: res.error || 'Failed to send Telegram message. Check token & chat ID.',
      });
    }
  };

  // Save Telegram Settings
  const handleSaveTelegramConfig = () => {
    const hasData = Boolean(tgBotToken.trim() && tgChatId.trim());
    onUpdateTelegramSettings({
      enabled: hasData,
      botToken: tgBotToken.trim(),
      chatId: tgChatId.trim(),
      autoSendAlerts: tgAutoSend,
    });
    if (hasData) {
      setTelegramEnabled(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs select-none p-4">
      <div className="bg-[#090d16] border border-slate-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Minimal Header */}
        <div className="px-5 py-3.5 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/30">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Bell className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-100 text-sm tracking-tight">
                  Price Alerts
                </span>
                <span className="px-1.5 py-0.2 rounded bg-slate-800 text-blue-400 font-mono text-[10px] font-semibold">
                  {currentAsset.symbol}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-tabular">
                Market: <b className="text-slate-200">${currentPrice.toFixed(currentAsset.priceDecimals)}</b>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Minimal Segmented Tabs */}
        <div className="px-5 pt-3 pb-1 border-b border-slate-800/60 bg-slate-950/40 flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('create')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium transition-all text-center flex items-center justify-center gap-1.5 ${
              activeTab === 'create'
                ? 'bg-slate-800 text-amber-400 shadow-sm border border-slate-700/80 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>Set Alert</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('active')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium transition-all text-center flex items-center justify-center gap-1.5 ${
              activeTab === 'active'
                ? 'bg-slate-800 text-blue-400 shadow-sm border border-slate-700/80 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Active ({activeAlerts.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('telegram')}
            className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-medium transition-all text-center flex items-center justify-center gap-1.5 relative ${
              activeTab === 'telegram'
                ? 'bg-slate-800 text-sky-400 shadow-sm border border-slate-700/80 font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Send className="w-3 h-3" />
            <span>Telegram</span>
            {isTelegramReady && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>

        {/* TAB 1: Minimal Create Alert Form */}
        {activeTab === 'create' && (
          <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
            {/* Quick Percentage Presets */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-medium text-slate-400">Quick Target Presets</span>
                <button
                  type="button"
                  onClick={resetToCurrentPrice}
                  className="text-[10px] text-amber-400 hover:underline font-mono"
                >
                  Reset Current
                </button>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  type="button"
                  onClick={() => applyPercentPreset(0.5)}
                  className="py-1 px-1.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-mono text-[11px] transition-colors"
                >
                  +0.5%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentPreset(1.0)}
                  className="py-1 px-1.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-mono text-[11px] transition-colors"
                >
                  +1.0%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentPreset(2.0)}
                  className="py-1 px-1.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-mono text-[11px] transition-colors"
                >
                  +2.0%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentPreset(5.0)}
                  className="py-1 px-1.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-mono text-[11px] transition-colors"
                >
                  +5.0%
                </button>

                <button
                  type="button"
                  onClick={() => applyPercentPreset(-0.5)}
                  className="py-1 px-1.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-mono text-[11px] transition-colors"
                >
                  -0.5%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentPreset(-1.0)}
                  className="py-1 px-1.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-mono text-[11px] transition-colors"
                >
                  -1.0%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentPreset(-2.0)}
                  className="py-1 px-1.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-mono text-[11px] transition-colors"
                >
                  -2.0%
                </button>
                <button
                  type="button"
                  onClick={() => applyPercentPreset(-5.0)}
                  className="py-1 px-1.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-mono text-[11px] transition-colors"
                >
                  -5.0%
                </button>
              </div>
            </div>

            {/* Target Price Input */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-slate-300 font-medium">Target Level</label>
                {isValidPrice && (
                  <span
                    className={`font-mono text-[10px] ${
                      priceDiff >= 0 ? 'text-emerald-400' : 'text-red-400'
                    }`}
                  >
                    {priceDiff >= 0 ? '▲ +' : '▼ '}
                    {Math.abs(pctDiff).toFixed(2)}% ({priceDiff >= 0 ? '+' : ''}
                    ${priceDiff.toFixed(currentAsset.priceDecimals)})
                  </span>
                )}
              </div>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  required
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(e.target.value)}
                  autoFocus
                  placeholder="Enter target price..."
                  className="w-full bg-[#0c121e] border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono text-sm focus:outline-none focus:border-amber-400 transition-colors shadow-inner"
                />
                <span className="absolute right-3.5 top-3 text-slate-500 font-mono text-xs font-semibold">
                  {currentAsset.currency}
                </span>
              </div>
            </div>

            {/* Trigger Condition Selector */}
            <div>
              <label className="text-slate-300 font-medium block mb-1.5">Condition</label>
              <div className="grid grid-cols-3 gap-1.5">
                <button
                  type="button"
                  onClick={() => setCondition('CROSSES_ABOVE')}
                  className={`py-2 px-1.5 rounded-lg border text-center transition-all font-medium text-[11px] flex items-center justify-center gap-1 ${
                    condition === 'CROSSES_ABOVE'
                      ? 'border-emerald-500/80 bg-emerald-500/15 text-emerald-300 font-semibold shadow-xs'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <ArrowUp className="w-3 h-3 text-emerald-400" />
                  <span>Crosses Above</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCondition('CROSSES_BELOW')}
                  className={`py-2 px-1.5 rounded-lg border text-center transition-all font-medium text-[11px] flex items-center justify-center gap-1 ${
                    condition === 'CROSSES_BELOW'
                      ? 'border-red-500/80 bg-red-500/15 text-red-300 font-semibold shadow-xs'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <ArrowDown className="w-3 h-3 text-red-400" />
                  <span>Crosses Below</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCondition('CROSSES')}
                  className={`py-2 px-1.5 rounded-lg border text-center transition-all font-medium text-[11px] flex items-center justify-center gap-1 ${
                    condition === 'CROSSES'
                      ? 'border-blue-500/80 bg-blue-500/15 text-blue-300 font-semibold shadow-xs'
                      : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span>Either Way ↕</span>
                </button>
              </div>
            </div>

            {/* Note / Memo */}
            <div>
              <label className="text-slate-300 font-medium block mb-1.5">Note (Optional)</label>
              <input
                type="text"
                placeholder="e.g. Resistance breakout, Stop loss, Support bounce"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full bg-[#0c121e] border border-slate-700/80 rounded-xl px-3 py-2 text-slate-200 placeholder-slate-500 text-xs focus:outline-none focus:border-amber-400 transition-colors"
              />
            </div>

            {/* Notification Delivery Channels */}
            <div className="pt-2 border-t border-slate-800/80 space-y-2.5">
              {/* Audio Chime */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-slate-400" />
                  <span className="text-slate-300 text-xs">Play Sound Chime</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={soundEnabled}
                    onChange={(e) => setSoundEnabled(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4.5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              {/* Telegram Delivery Toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Send className="w-3.5 h-3.5 text-sky-400" />
                  <div>
                    <span className="text-slate-300 text-xs">Send to Telegram</span>
                    <div className="text-[10px] text-slate-500">
                      {isTelegramReady ? (
                        <span className="text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-2.5 h-2.5" /> Bot Connected
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setActiveTab('telegram')}
                          className="text-sky-400 hover:underline"
                        >
                          Configure Bot & Chat ID →
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={telegramEnabled}
                    disabled={!isTelegramReady}
                    onChange={(e) => setTelegramEnabled(e.target.checked)}
                    className="sr-only peer disabled:opacity-40"
                  />
                  <div className="w-8 h-4.5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-500"></div>
                </label>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!isValidPrice}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-semibold rounded-xl transition-all shadow-md shadow-amber-500/20 flex items-center gap-1.5"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>Set Alert</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 2: Active Alerts List */}
        {activeTab === 'active' && (
          <div className="p-5 flex-1 max-h-[380px] overflow-y-auto space-y-3 text-xs">
            {activeAlerts.length === 0 ? (
              <div className="py-12 text-center text-slate-500">
                <Bell className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                <p className="font-medium text-slate-400">No Active Alerts</p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Create a new alert above to monitor price targets.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('create')}
                  className="mt-3 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs transition-colors"
                >
                  Create New Alert
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {activeAlerts.map((alert) => {
                  const isCurrent = alert.symbol === currentAsset.symbol;
                  const priceDiff = alert.targetPrice - (isCurrent ? currentPrice : alert.createdPrice);
                  const pct = ((priceDiff / (isCurrent ? currentPrice : alert.createdPrice)) * 100).toFixed(2);

                  return (
                    <div
                      key={alert.id}
                      className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex items-center justify-between gap-3 font-mono hover:border-slate-700 transition-colors"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-100 text-xs">{alert.symbol}</span>
                          <span
                            className={`px-1.5 py-0.2 rounded text-[10px] font-sans font-medium ${
                              alert.condition === 'CROSSES_ABOVE'
                                ? 'bg-emerald-500/15 text-emerald-400'
                                : alert.condition === 'CROSSES_BELOW'
                                ? 'bg-red-500/15 text-red-400'
                                : 'bg-blue-500/15 text-blue-400'
                            }`}
                          >
                            {alert.condition === 'CROSSES_ABOVE'
                              ? 'Crosses Above'
                              : alert.condition === 'CROSSES_BELOW'
                              ? 'Crosses Below'
                              : 'Either Cross'}
                          </span>
                        </div>
                        <div className="flex items-baseline gap-2 mt-1">
                          <span className="text-sm font-bold text-amber-400">
                            ${alert.targetPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </span>
                          <span className="text-[10px] text-slate-400 font-sans">
                            {priceDiff >= 0 ? '+' : ''}{pct}% away
                          </span>
                        </div>
                        {alert.note && (
                          <p className="text-[10px] text-slate-400 italic truncate font-sans mt-0.5">
                            "{alert.note}"
                          </p>
                        )}
                        <div className="flex items-center gap-2 mt-1 text-[9px] font-sans text-slate-500">
                          {alert.soundEnabled && <span>🔊 Sound</span>}
                          {alert.telegramEnabled && <span className="text-sky-400">✈️ Telegram</span>}
                        </div>
                      </div>

                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className="p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                        title="Delete Alert"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Triggered Alerts History */}
            {triggeredAlerts.length > 0 && (
              <div className="pt-3 border-t border-slate-800/80">
                <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                  Recently Triggered ({triggeredAlerts.length})
                </span>
                <div className="space-y-1.5">
                  {triggeredAlerts.slice(0, 3).map((alert) => (
                    <div
                      key={alert.id}
                      className="p-2 rounded-lg bg-slate-900/30 border border-slate-800/50 flex items-center justify-between text-[11px] font-mono text-slate-400"
                    >
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span className="text-slate-300">{alert.symbol}</span>
                        <span>${alert.targetPrice.toFixed(2)}</span>
                      </div>
                      <button
                        onClick={() => onDeleteAlert(alert.id)}
                        className="text-slate-500 hover:text-slate-300"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: Telegram Settings & Test Tab */}
        {activeTab === 'telegram' && (
          <div className="p-5 space-y-4 text-xs">
            {/* Status Header */}
            <div
              className={`p-3 rounded-xl border flex items-start gap-2.5 ${
                isTelegramReady
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-sky-500/10 border-sky-500/20 text-sky-200'
              }`}
            >
              <Send className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-xs text-slate-100">
                  {isTelegramReady ? 'Telegram Alerts Active' : 'Connect Your Telegram Bot'}
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Receive instant alerts on your Telegram message feed whenever price thresholds are breached.
                </p>
              </div>
            </div>

            {/* Bot Token Input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-300 font-medium">Telegram Bot Token</label>
                <span className="text-[10px] text-slate-500">From @BotFather</span>
              </div>
              <div className="relative">
                <input
                  type={showToken ? 'text' : 'password'}
                  placeholder="e.g. 7123456789:AAFl..."
                  value={tgBotToken}
                  onChange={(e) => setTgBotToken(e.target.value)}
                  className="w-full bg-[#0c121e] border border-slate-700/80 rounded-xl pl-3 pr-10 py-2.5 text-slate-100 font-mono text-xs focus:outline-none focus:border-sky-400 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-200"
                >
                  {showToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Chat ID Input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-slate-300 font-medium">Telegram Chat ID</label>
                <span className="text-[10px] text-slate-500">From @userinfobot or @getidsbot</span>
              </div>
              <input
                type="text"
                placeholder="e.g. 123456789 or -100123456789"
                value={tgChatId}
                onChange={(e) => setTgChatId(e.target.value)}
                className="w-full bg-[#0c121e] border border-slate-700/80 rounded-xl px-3 py-2.5 text-slate-100 font-mono text-xs focus:outline-none focus:border-sky-400 transition-colors"
              />
            </div>

            {/* Auto send toggle */}
            <div className="flex items-center justify-between pt-1">
              <span className="text-slate-300 text-xs">Auto-dispatch all triggered alerts</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={tgAutoSend}
                  onChange={(e) => setTgAutoSend(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-8 h-4.5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-3.5 after:w-3.5 after:transition-all peer-checked:bg-sky-500"></div>
              </label>
            </div>

            {/* Test Status Banner */}
            {testResult && (
              <div
                className={`p-2.5 rounded-xl border text-xs flex items-start gap-2 ${
                  testResult.success
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-red-500/10 border-red-500/30 text-red-300'
                }`}
              >
                {testResult.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                )}
                <div className="flex-1 text-[11px] leading-relaxed">{testResult.message}</div>
              </div>
            )}

            {/* Test & Save Buttons */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
              <button
                type="button"
                onClick={handleTestTelegram}
                disabled={isTestingTg || !tgBotToken.trim() || !tgChatId.trim()}
                className="flex-1 py-2 px-3 bg-sky-600 hover:bg-sky-500 disabled:opacity-40 text-white font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-sky-600/20"
              >
                {isTestingTg ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Testing...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Test Message</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  handleSaveTelegramConfig();
                  setActiveTab('create');
                }}
                className="py-2 px-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs transition-colors"
              >
                Save
              </button>
            </div>

            {/* Minimal Quick Setup Guide Accordion */}
            <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-3 text-[11px] text-slate-400 space-y-1.5">
              <span className="font-semibold text-slate-300 block flex items-center gap-1 text-[11px]">
                <Sparkles className="w-3 h-3 text-amber-400" /> 30-Second Telegram Setup:
              </span>
              <p>1. Open Telegram, search <b className="text-sky-300">@BotFather</b> and send <code>/newbot</code></p>
              <p>2. Copy the token provided and start your bot with <code>/start</code></p>
              <p>3. Message <b className="text-sky-300">@userinfobot</b> to view your numeric <b>Chat ID</b></p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
